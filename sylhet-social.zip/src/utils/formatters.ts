import { Language, UserProfile } from '../types/social';

export function formatRelativeTime(isoDate: string, language: Language): string {
  const date = new Date(isoDate);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.max(1, Math.floor(diffMs / 60000));
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (language === 'bn') {
    if (diffMins < 2) return 'এইমাত্র';
    if (diffMins < 60) return `${toBengaliDigits(diffMins)} মিনিট আগে`;
    if (diffHours < 24) return `${toBengaliDigits(diffHours)} ঘণ্টা আগে`;
    if (diffDays < 7) return `${toBengaliDigits(diffDays)} দিন আগে`;
    return date.toLocaleDateString('bn-BD', { month: 'short', day: 'numeric' });
  }

  if (diffMins < 2) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function toBengaliDigits(value: number | string): string {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(value).replace(/\d/g, (digit) => bnDigits[Number(digit)] ?? digit);
}

export function formatCount(count: number, language: Language): string {
  return language === 'bn' ? toBengaliDigits(count) : String(count);
}

export function getDisplayName(user: UserProfile, language: Language): string {
  return language === 'bn' && user.nameBn ? user.nameBn : user.name;
}

export function getDisplayBio(user: UserProfile, language: Language): string {
  return language === 'bn' && user.bioBn ? user.bioBn : user.bio;
}

export function getDisplayLocation(user: UserProfile, language: Language): string {
  return language === 'bn' && user.locationBn ? user.locationBn : user.location;
}

export function getDisplayWork(user: UserProfile, language: Language): string {
  return language === 'bn' && user.workOrStudyBn ? user.workOrStudyBn : user.workOrStudy;
}

export function getInitials(name: string): string {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('');
}

export function formatMessageTime(isoDate: string, language: Language): string {
  const date = new Date(isoDate);
  if (Number.isNaN(date.getTime())) return '';
  const raw = date.toLocaleTimeString(language === 'bn' ? 'bn-BD' : 'en-US', {
    hour: 'numeric',
    minute: '2-digit',
  });
  return language === 'bn' ? toBengaliDigits(raw) : raw;
}

export function formatChatDateDivider(isoDate: string, language: Language): string {
  const date = new Date(isoDate);
  if (Number.isNaN(date.getTime())) return '';
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startOfTarget = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const dayDiff = Math.round((startOfToday - startOfTarget) / 86400000);

  if (dayDiff === 0) return language === 'bn' ? 'আজ' : 'Today';
  if (dayDiff === 1) return language === 'bn' ? 'গতকাল' : 'Yesterday';

  const formatted = date.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
    month: 'short',
    day: 'numeric',
    year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
  });
  return language === 'bn' ? toBengaliDigits(formatted) : formatted;
}

export function formatDuration(seconds: number, language: Language): string {
  const safe = Math.max(0, Math.floor(seconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  const raw = `${mins}:${secs < 10 ? `0${secs}` : secs}`;
  return language === 'bn' ? toBengaliDigits(raw) : raw;
}

export function formatFileSize(bytes: number, language: Language): string {
  if (!bytes || bytes <= 0) return language === 'bn' ? '০ KB' : '0 KB';
  if (bytes < 1024 * 1024) {
    const kb = Math.max(1, Math.round(bytes / 1024));
    return `${formatCount(kb, language)} KB`;
  }
  const mb = (bytes / (1024 * 1024)).toFixed(1);
  return `${language === 'bn' ? toBengaliDigits(mb) : mb} MB`;
}

export function formatLastSeen(isoDate: string | undefined, language: Language): string {
  if (!isoDate) {
    return language === 'bn' ? 'অফলাইন' : 'Offline';
  }
  const rel = formatRelativeTime(isoDate, language);
  return language === 'bn' ? `সর্বশেষ সক্রিয়: ${rel}` : `Last seen ${rel}`;
}

