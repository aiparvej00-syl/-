export async function compressImageToDataUrl(
  file: File,
  maxWidth = 1080,
  quality = 0.78
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image file'));
      img.onload = () => {
        const scale = Math.min(1, maxWidth / img.width);
        const width = Math.max(1, Math.round(img.width * scale));
        const height = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(typeof reader.result === 'string' ? reader.result : '');
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.src = typeof reader.result === 'string' ? reader.result : '';
    };
    reader.readAsDataURL(file);
  });
}

export async function fileToBoundedDataUrl(
  file: File,
  maxBytes = 520000
): Promise<{ ok: boolean; dataUrl?: string }> {
  if (file.size > maxBytes) {
    return { ok: false };
  }
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onerror = () => resolve({ ok: false });
    reader.onload = () => {
      if (typeof reader.result === 'string' && reader.result.length <= 590000) {
        resolve({ ok: true, dataUrl: reader.result });
      } else {
        resolve({ ok: false });
      }
    };
    reader.readAsDataURL(file);
  });
}
