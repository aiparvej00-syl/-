export type Language = 'en' | 'bn';

export type ThemeMode = 'light' | 'dark';

export type NavTab =
  | 'feed'
  | 'explore'
  | 'advertise'
  | 'friends'
  | 'search'
  | 'messages'
  | 'notifications'
  | 'profile'
  | 'admin';

export type PostMediaType = 'text' | 'photo' | 'video';

export type UserRole = 'user' | 'moderator' | 'admin';

export type UserStatus = 'active' | 'suspended';

export type ModerationStatus = 'approved' | 'pending' | 'hidden';

export type ReportReason =
  | 'spam'
  | 'harassment'
  | 'misinformation'
  | 'inappropriate'
  | 'other';

export type ReportStatus = 'pending' | 'reviewed' | 'resolved' | 'dismissed';

export interface UserProfile {
  id: string;
  uid: string;
  name: string;
  nameBn: string;
  username: string;
  email?: string;
  avatarUrl: string;
  coverUrl: string;
  bio: string;
  bioBn: string;
  location: string;
  locationBn: string;
  workOrStudy: string;
  workOrStudyBn: string;
  joinedDate: string;
  role: UserRole;
  status: UserStatus;
  friendsCount: number;
  followersCount: number;
  followingCount: number;
  friends: string[];
  friendRequestsReceived: string[];
  friendRequestsSent: string[];
  followers: string[];
  following: string[];
  isOnline?: boolean;
  lastSeenAt?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface AdminRecord {
  uid: string;
  email: string;
  role: 'admin' | 'moderator';
  grantedBy: string;
  createdAt: string;
}

export interface PostComment {
  id: string;
  postId: string;
  authorId: string;
  text: string;
  createdAt: string;
}

export interface PostItem {
  id: string;
  authorId: string;
  mediaType: PostMediaType;
  text: string;
  textBn?: string;
  photoUrl?: string;
  videoUrl?: string;
  videoThumbnailUrl?: string;
  videoDuration?: string;
  textCardTheme?: 'none' | 'emerald' | 'surma' | 'tea';
  location?: string;
  locationBn?: string;
  moderationStatus: ModerationStatus;
  moderationNote?: string;
  createdAt: string;
  updatedAt?: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  likedByMe?: boolean;
  comments: PostComment[];
  sharedPostId?: string;
}

export type NotificationType =
  | 'like'
  | 'comment'
  | 'share'
  | 'friend_request'
  | 'friend_accept'
  | 'follow'
  | 'admin_broadcast'
  | 'moderation';

export interface NotificationItem {
  id: string;
  type: NotificationType;
  actorId: string;
  targetUserId: string;
  postId?: string;
  title?: string;
  previewText?: string;
  createdAt: string;
  read: boolean;
}

export type MessageMediaType = 'text' | 'image' | 'video' | 'voice';

export interface MessageItem {
  id: string;
  conversationId: string;
  senderId: string;
  messageType: MessageMediaType;
  text: string;
  mediaUrl?: string;
  mediaName?: string;
  mediaSize?: number;
  mediaDurationSec?: number;
  deliveredTo: string[];
  seenBy: string[];
  deliveredAt?: string;
  seenAt?: string;
  createdAt: string;
}

export interface ConversationThread {
  id: string;
  participantIds: [string, string];
  lastMessageText?: string;
  lastMessageType?: MessageMediaType;
  lastMessageSenderId?: string;
  lastMessageAt?: string;
  messages: MessageItem[];
  unreadBy: string[];
  unreadCounts?: Record<string, number>;
  typing?: Record<string, number>;
}

export interface UserBlock {
  id: string;
  blockerId: string;
  blockedId: string;
  createdAt: string;
}

export interface PresenceState {
  isOnline: boolean;
  lastChanged?: string;
}

export interface ReportItem {
  id: string;
  reporterId: string;
  targetType: 'post' | 'user';
  targetPostId?: string;
  targetUserId?: string;
  reason: ReportReason;
  details?: string;
  status: ReportStatus;
  reviewedBy?: string;
  resolutionNote?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AppSettings {
  siteName: string;
  maintenanceMode: boolean;
  allowRegistrations: boolean;
  requirePostReview: boolean;
  maxUploadMb: number;
  featuredBannerEn: string;
  featuredBannerBn: string;
  updatedBy: string;
  updatedAt: string;
}

export interface AuditLogItem {
  id: string;
  adminUid: string;
  adminEmail: string;
  action: string;
  targetType: string;
  targetId: string;
  summary: string;
  createdAt: string;
}

export type LocationLevel = 'division' | 'district' | 'upazila' | 'union' | 'village';

export interface LocationNode {
  id: string;
  level: LocationLevel;
  name: string;
  nameBn: string;
  parentId?: string;
  divisionId?: string;
  districtId?: string;
  upazilaId?: string;
  unionId?: string;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export type AttractionCategory =
  | 'waterfall'
  | 'forest'
  | 'lake'
  | 'haor'
  | 'tea_garden'
  | 'cultural'
  | 'river'
  | 'heritage';

export interface TouristAttraction {
  id: string;
  name: string;
  nameBn: string;
  category: AttractionCategory;
  divisionId?: string;
  districtId: string;
  districtName: string;
  districtNameBn?: string;
  upazilaId: string;
  upazilaName: string;
  upazilaNameBn?: string;
  unionId?: string;
  unionName?: string;
  unionNameBn?: string;
  villageName?: string;
  villageNameBn?: string;
  locationSummary: string;
  locationSummaryBn: string;
  description?: string;
  descriptionBn?: string;
  imageUrl?: string;
  isFeatured: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export type AdConsentStatus =
  | 'unset'
  | 'personalized'
  | 'non_personalized'
  | 'essential_only';

export type AdPlacement = 'feed' | 'sidebar' | 'both';

export type AdCategory =
  | 'restaurant'
  | 'hotel_resort'
  | 'retail'
  | 'education'
  | 'healthcare'
  | 'tech_services'
  | 'tourism'
  | 'real_estate'
  | 'other';

export type AdCtaLabel = 'call_now' | 'whatsapp' | 'visit_website' | 'learn_more';

export type AdStatus = 'pending_review' | 'approved' | 'paused' | 'rejected' | 'expired';

export type AdPaymentStatus = 'unpaid' | 'pending_verification' | 'paid' | 'refunded';

export type AdPaymentMethod =
  | 'manual_bkash'
  | 'manual_nagad'
  | 'bank_transfer'
  | 'cash_office'
  | 'none';

export interface AdPackage {
  id: string;
  name: string;
  nameBn: string;
  description?: string;
  descriptionBn?: string;
  durationDays: number;
  priceBdt: number;
  placement: AdPlacement;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface LocalAd {
  id: string;
  advertiserUid: string;
  businessName: string;
  category: AdCategory;
  title: string;
  titleBn?: string;
  description: string;
  descriptionBn?: string;
  imageUrl?: string;
  contactPhone: string;
  whatsappNumber?: string;
  contactEmail?: string;
  websiteUrl?: string;
  ctaLabel: AdCtaLabel;
  location: string;
  locationBn?: string;
  districtId?: string;
  upazilaId?: string;
  packageId: string;
  packageName: string;
  placement: AdPlacement;
  durationDays: number;
  priceBdt: number;
  status: AdStatus;
  paymentStatus: AdPaymentStatus;
  paymentMethod?: AdPaymentMethod;
  paymentReference?: string;
  paymentConfirmedBy?: string;
  paymentConfirmedAt?: string;
  adminNote?: string;
  startsAt?: string;
  endsAt?: string;
  impressionsCount: number;
  clicksCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface MonetizationConfig {
  admobEnvironment: 'development_test' | 'production_ready';
  admobBannerEnabled: boolean;
  admobNativeEnabled: boolean;
  localAdsEnabled: boolean;
  feedAdInterval: number;
  requireAdConsent: boolean;
  manualPaymentInstructionsEn: string;
  manualPaymentInstructionsBn: string;
  updatedBy: string;
  updatedAt: string;
}

