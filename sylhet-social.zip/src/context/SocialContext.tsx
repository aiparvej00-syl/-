import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  reauthenticateWithPopup,
  signInWithPopup,
  signOut,
} from 'firebase/auth';
import {
  Timestamp,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  increment,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { DEFAULT_AD_PACKAGES, DEFAULT_MONETIZATION_CONFIG } from '../data/adPackagesSeed';
import { ASSET_IMAGES, STARTER_POST_TEMPLATES } from '../data/seedData';
import { OFFICIAL_ATTRACTIONS, OFFICIAL_LOCATIONS } from '../data/sylhetLocations';
import {
  OperationType,
  RtdbPresencePayload,
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  setRtdbTypingState,
  subscribeAllRtdbPresence,
  subscribeRtdbConnectionAndPresence,
  subscribeRtdbTyping,
  uploadChatMediaFile,
} from '../firebase';
import { TranslationSchema, translations } from '../i18n/translations';
import {
  AdCategory,
  AdConsentStatus,
  AdCtaLabel,
  AdPackage,
  AdPaymentMethod,
  AdPaymentStatus,
  AdPlacement,
  AdStatus,
  AdminRecord,
  AppSettings,
  AttractionCategory,
  AuditLogItem,
  ConversationThread,
  Language,
  LocalAd,
  LocationLevel,
  LocationNode,
  MessageItem,
  MessageMediaType,
  ModerationStatus,
  MonetizationConfig,
  NavTab,
  NotificationItem,
  PostComment,
  PostItem,
  PostMediaType,
  ReportItem,
  ReportReason,
  ReportStatus,
  ThemeMode,
  TouristAttraction,
  UserBlock,
  UserProfile,
  UserRole,
  UserStatus,
} from '../types/social';

export const BOOTSTRAPPED_ADMIN_EMAIL = 'aiparvej00@gmail.com';

export interface CreatePostInput {
  mediaType: PostMediaType;
  text: string;
  photoUrl?: string;
  videoUrl?: string;
  videoThumbnailUrl?: string;
  videoDuration?: string;
  textCardTheme?: 'none' | 'emerald' | 'surma' | 'tea';
  location?: string;
  locationBn?: string;
}

export interface SendMediaMessageInput {
  mediaType: 'image' | 'video' | 'voice';
  file: Blob;
  fileName: string;
  caption?: string;
  durationSec?: number;
  onProgress?: (percent: number) => void;
}

export interface ChatAlertBanner {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  avatarUrl: string;
  preview: string;
}

export interface SubmitLocalAdInput {
  businessName: string;
  category: AdCategory;
  title: string;
  titleBn?: string;
  description: string;
  descriptionBn?: string;
  imageUrl?: string;
  contactPhone: string;
  whatsappNumber?: string;
  contactEmail?: string;
  websiteUrl?: string;
  ctaLabel: AdCtaLabel;
  location: string;
  locationBn?: string;
  districtId?: string;
  upazilaId?: string;
  packageId: string;
}

interface SocialContextValue {
  authReady: boolean;
  firebaseUser: FirebaseUser | null;
  authError: string | null;
  isOnlineNetwork: boolean;
  rtdbConnected: boolean;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: TranslationSchema;
  theme: ThemeMode;
  toggleTheme: () => void;
  currentUser: UserProfile | null;
  isAdmin: boolean;
  isBootstrappedAdmin: boolean;
  adminRole: 'admin' | 'moderator' | null;
  adminVerified: boolean;
  verifyAdminSession: () => Promise<boolean>;
  lockAdminConsole: () => void;
  users: UserProfile[];
  privateEmailsByUid: Record<string, string>;
  adminRecords: AdminRecord[];
  posts: PostItem[];
  savedPostIds: string[];
  notifications: NotificationItem[];
  unreadNotificationsCount: number;
  conversations: ConversationThread[];
  unreadMessagesCount: number;
  messagesLoading: boolean;
  messagingError: string | null;
  clearMessagingError: () => void;
  chatAlert: ChatAlertBanner | null;
  dismissChatAlert: () => void;
  browserNotificationPermission: NotificationPermission | 'unsupported';
  requestBrowserNotifications: () => Promise<void>;
  blockedByMeIds: string[];
  blockedMeIds: string[];
  isBlockedBetween: (otherUid: string) => {
    blockedByMe: boolean;
    blockedByOther: boolean;
    anyBlocked: boolean;
  };
  isPartnerTyping: (conversationId: string, partnerId: string) => boolean;
  reports: ReportItem[];
  auditLogs: AuditLogItem[];
  appSettings: AppSettings;
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  viewedProfileId: string;
  openProfile: (userId: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  navigateToSearch: (q: string) => void;
  activeConversationId: string | null;
  setActiveConversationId: (id: string | null) => void;
  openChatWith: (userId: string) => Promise<void>;
  highlightedPostId: string | null;
  setHighlightedPostId: (postId: string | null) => void;
  composerLocationPrefill: { en: string; bn: string } | null;
  prefillComposerWithLocation: (loc: { en: string; bn: string } | null) => void;
  locations: LocationNode[];
  attractions: TouristAttraction[];
  locationsSyncedToFirestore: boolean;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  signInWithGoogle: () => Promise<boolean>;
  logout: () => Promise<void>;
  updateProfile: (
    updates: Partial<
      Pick<
        UserProfile,
        'name' | 'bio' | 'location' | 'locationBn' | 'workOrStudy' | 'avatarUrl' | 'coverUrl'
      >
    >
  ) => Promise<void>;
  createPost: (input: CreatePostInput) => Promise<void>;
  deleteOwnPost: (postId: string) => Promise<void>;
  toggleLike: (postId: string) => Promise<void>;
  addComment: (postId: string, text: string) => Promise<void>;
  sharePost: (postId: string, note?: string) => Promise<void>;
  toggleSavePost: (postId: string) => Promise<void>;
  reportPost: (postId: string, targetUserId: string, reason: ReportReason, details: string) => Promise<void>;
  reportUser: (targetUserId: string, reason: ReportReason, details: string) => Promise<void>;
  blockUser: (targetUserId: string) => Promise<void>;
  unblockUser: (targetUserId: string) => Promise<void>;
  sendFriendRequest: (targetUserId: string) => Promise<void>;
  acceptFriendRequest: (requesterId: string) => Promise<void>;
  declineFriendRequest: (requesterId: string) => Promise<void>;
  removeFriend: (targetUserId: string) => Promise<void>;
  toggleFollow: (targetUserId: string) => Promise<void>;
  markNotificationRead: (notifId: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  sendMessage: (conversationId: string, text: string) => Promise<boolean>;
  sendMediaMessage: (conversationId: string, input: SendMediaMessageInput) => Promise<boolean>;
  setTypingStatus: (conversationId: string, isTyping: boolean) => void;
  markConversationRead: (conversationId: string) => Promise<void>;
  getUserById: (id: string) => UserProfile | undefined;
  // Admin-only operations (guarded by RBAC & Firestore rules)
  adminUpdateUserRole: (targetUid: string, role: UserRole) => Promise<void>;
  adminUpdateUserStatus: (targetUid: string, status: UserStatus) => Promise<void>;
  adminModeratePost: (postId: string, status: ModerationStatus, note?: string) => Promise<void>;
  adminDeletePost: (postId: string) => Promise<void>;
  adminResolveReport: (
    reportId: string,
    status: ReportStatus,
    resolutionNote: string,
    hideTargetPost?: boolean,
    suspendTargetUser?: boolean
  ) => Promise<void>;
  adminSendBroadcast: (title: string, message: string) => Promise<void>;
  adminSaveAppSettings: (next: Omit<AppSettings, 'updatedBy' | 'updatedAt'>) => Promise<void>;
  adminSeedStarterPosts: () => Promise<void>;
  adminSeedLocationsAndAttractions: () => Promise<void>;
  adminSaveLocationNode: (input: {
    id?: string;
    level: LocationLevel;
    name: string;
    nameBn: string;
    parentId?: string;
    divisionId?: string;
    districtId?: string;
    upazilaId?: string;
    unionId?: string;
    isActive: boolean;
    sortOrder: number;
  }) => Promise<void>;
  adminDeleteLocationNode: (locationId: string) => Promise<void>;
  adminSaveAttraction: (input: {
    id?: string;
    name: string;
    nameBn: string;
    category: AttractionCategory;
    divisionId?: string;
    districtId: string;
    districtName: string;
    districtNameBn?: string;
    upazilaId: string;
    upazilaName: string;
    upazilaNameBn?: string;
    unionId?: string;
    unionName?: string;
    unionNameBn?: string;
    villageName?: string;
    villageNameBn?: string;
    locationSummary: string;
    locationSummaryBn: string;
    description?: string;
    descriptionBn?: string;
    imageUrl?: string;
    isFeatured: boolean;
    isActive: boolean;
  }) => Promise<void>;
  adminDeleteAttraction: (attractionId: string) => Promise<void>;
  // Monetization, Local Business Ads & Privacy Consent
  adPackages: AdPackage[];
  adPackagesSyncedToFirestore: boolean;
  localAds: LocalAd[];
  activeLocalAds: LocalAd[];
  myLocalAds: LocalAd[];
  monetizationConfig: MonetizationConfig;
  adConsentStatus: AdConsentStatus;
  updateAdConsent: (status: AdConsentStatus) => Promise<void>;
  adPrivacyModalOpen: boolean;
  setAdPrivacyModalOpen: (open: boolean) => void;
  hiddenAdIds: string[];
  hideAdForSession: (adId: string) => void;
  submitLocalAd: (input: SubmitLocalAdInput) => Promise<boolean>;
  submitAdPaymentReference: (
    adId: string,
    paymentMethod: AdPaymentMethod,
    paymentReference: string
  ) => Promise<boolean>;
  pauseOwnAd: (adId: string) => Promise<void>;
  deleteOwnUnpaidAd: (adId: string) => Promise<void>;
  trackAdImpression: (adId: string) => void;
  trackAdClick: (adId: string) => void;
  adminSeedMonetizationDefaults: () => Promise<void>;
  adminSaveAdPackage: (input: {
    id?: string;
    name: string;
    nameBn: string;
    description?: string;
    descriptionBn?: string;
    durationDays: number;
    priceBdt: number;
    placement: AdPlacement;
    isActive: boolean;
    sortOrder: number;
  }) => Promise<void>;
  adminDeleteAdPackage: (packageId: string) => Promise<void>;
  adminUpdateAdModeration: (
    adId: string,
    nextStatus: AdStatus,
    adminNote?: string
  ) => Promise<void>;
  adminConfirmAdPayment: (
    adId: string,
    paymentStatus: AdPaymentStatus,
    paymentMethod?: AdPaymentMethod,
    adminNote?: string
  ) => Promise<void>;
  adminDeleteLocalAd: (adId: string) => Promise<void>;
  adminSaveMonetizationConfig: (
    next: Omit<MonetizationConfig, 'updatedBy' | 'updatedAt'>
  ) => Promise<void>;
}

const DEFAULT_APP_SETTINGS: AppSettings = {
  siteName: 'Sylhet Social',
  maintenanceMode: false,
  allowRegistrations: true,
  requirePostReview: false,
  maxUploadMb: 5,
  featuredBannerEn: 'Explore Ratargul, Jaflong & Surma stories today',
  featuredBannerBn: 'রাতারগুল, জাফলং ও সুরমা নদীর আজকের গল্প দেখুন',
  updatedBy: 'system',
  updatedAt: new Date().toISOString(),
};

function toIso(value: unknown): string {
  if (value instanceof Timestamp) {
    return value.toDate().toISOString();
  }
  if (typeof value === 'string') {
    return value;
  }
  return new Date().toISOString();
}

function makePairId(a: string, b: string): string {
  return a < b ? `${a}_${b}` : `${b}_${a}`;
}

function sanitizeUsername(raw: string): string {
  const base = raw.toLowerCase().replace(/[^a-z0-9_.-]/g, '').slice(0, 24);
  return base.length >= 2 ? base : `sylhet_${Date.now().toString().slice(-5)}`;
}

function sanitizeDocId(raw: string, fallbackPrefix: string): string {
  const cleaned = raw
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9_-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 64);
  return cleaned.length >= 2
    ? `${fallbackPrefix}_${cleaned}`
    : `${fallbackPrefix}_${Date.now().toString(36)}`;
}

function playChatChime(): void {
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now);
    osc1.frequency.exponentialRampToValueAtTime(880, now + 0.09);
    gain1.gain.setValueAtTime(0.001, now);
    gain1.gain.exponentialRampToValueAtTime(0.06, now + 0.02);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.24);
    osc1.onended = () => {
      ctx.close().catch(() => {});
    };
  } catch {
    // Ignore autoplay restriction errors
  }
}

const SocialContext = createContext<SocialContextValue | null>(null);

export const SocialProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [authReady, setAuthReady] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isOnlineNetwork, setIsOnlineNetwork] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [rtdbConnected, setRtdbConnected] = useState(false);

  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('sylhet_social_lang');
    return saved === 'bn' ? 'bn' : 'en';
  });
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('sylhet_social_theme');
    return saved === 'dark' ? 'dark' : 'light';
  });

  const [rawUsers, setRawUsers] = useState<UserProfile[]>([]);
  const [ownUserDoc, setOwnUserDoc] = useState<UserProfile | null>(null);
  const [rtdbPresenceByUid, setRtdbPresenceByUid] = useState<Record<string, RtdbPresencePayload>>(
    {}
  );
  const [privateEmailsByUid, setPrivateEmailsByUid] = useState<Record<string, string>>({});
  const [adminRecords, setAdminRecords] = useState<AdminRecord[]>([]);
  const [myAdminDoc, setMyAdminDoc] = useState<AdminRecord | null>(null);
  const [adminVerified, setAdminVerified] = useState(false);

  const [rawApprovedPosts, setRawApprovedPosts] = useState<PostItem[]>([]);
  const [rawOwnPosts, setRawOwnPosts] = useState<PostItem[]>([]);
  const [rawAllAdminPosts, setRawAllAdminPosts] = useState<PostItem[]>([]);
  const [likedPostIds, setLikedPostIds] = useState<Record<string, boolean>>({});
  const [commentsByPost, setCommentsByPost] = useState<Record<string, PostComment[]>>({});
  const [savedPostIds, setSavedPostIds] = useState<string[]>([]);

  const [friendships, setFriendships] = useState<
    { id: string; userIds: string[]; requesterId: string; recipientId: string; status: string }[]
  >([]);
  const [followingDocs, setFollowingDocs] = useState<{ followerId: string; followingId: string }[]>([]);
  const [followerDocs, setFollowerDocs] = useState<{ followerId: string; followingId: string }[]>([]);

  const [rawConversations, setRawConversations] = useState<ConversationThread[]>([]);
  const [messagesByConv, setMessagesByConv] = useState<Record<string, MessageItem[]>>({});
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [messagingError, setMessagingError] = useState<string | null>(null);
  const [rtdbPartnerTyping, setRtdbPartnerTyping] = useState(false);
  const [typingTick, setTypingTick] = useState(0);
  const [blocksByMe, setBlocksByMe] = useState<UserBlock[]>([]);
  const [blocksAgainstMe, setBlocksAgainstMe] = useState<UserBlock[]>([]);
  const [chatAlert, setChatAlert] = useState<ChatAlertBanner | null>(null);
  const [browserNotificationPermission, setBrowserNotificationPermission] = useState<
    NotificationPermission | 'unsupported'
  >(() =>
    typeof window !== 'undefined' && 'Notification' in window
      ? Notification.permission
      : 'unsupported'
  );

  const [directNotifications, setDirectNotifications] = useState<NotificationItem[]>([]);
  const [broadcastNotifications, setBroadcastNotifications] = useState<NotificationItem[]>([]);
  const [readBroadcastIds, setReadBroadcastIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem('sylhet_social_read_broadcasts');
      return raw ? (JSON.parse(raw) as string[]) : [];
    } catch {
      return [];
    }
  });

  const [reports, setReports] = useState<ReportItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [appSettings, setAppSettings] = useState<AppSettings>(DEFAULT_APP_SETTINGS);
  const [rawFirestoreLocations, setRawFirestoreLocations] = useState<LocationNode[]>([]);
  const [rawFirestoreAttractions, setRawFirestoreAttractions] = useState<TouristAttraction[]>([]);
  const [rawFirestoreAdPackages, setRawFirestoreAdPackages] = useState<AdPackage[]>([]);
  const [rawLiveLocalAds, setRawLiveLocalAds] = useState<LocalAd[]>([]);
  const [rawMyLocalAds, setRawMyLocalAds] = useState<LocalAd[]>([]);
  const [rawAdminLocalAds, setRawAdminLocalAds] = useState<LocalAd[]>([]);
  const [monetizationConfig, setMonetizationConfig] = useState<MonetizationConfig>(
    DEFAULT_MONETIZATION_CONFIG
  );
  const [adConsentStatus, setAdConsentStatus] = useState<AdConsentStatus>(() => {
    const saved = localStorage.getItem('sylhet_social_ad_consent');
    if (
      saved === 'personalized' ||
      saved === 'non_personalized' ||
      saved === 'essential_only'
    ) {
      return saved;
    }
    return 'unset';
  });
  const [adPrivacyModalOpen, setAdPrivacyModalOpen] = useState(false);
  const [hiddenAdIds, setHiddenAdIds] = useState<string[]>([]);

  const [activeTab, setActiveTabState] = useState<NavTab>('feed');
  const [viewedProfileId, setViewedProfileId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [highlightedPostId, setHighlightedPostId] = useState<string | null>(null);
  const [composerLocationPrefill, setComposerLocationPrefill] = useState<{
    en: string;
    bn: string;
  } | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);

  const initializedConvsRef = useRef<Record<string, boolean>>({});
  const knownMsgIdsRef = useRef<Set<string>>(new Set());
  const trackedAdImpressionsRef = useRef<Set<string>>(new Set());
  const lastTypingFirestoreWriteRef = useRef<Record<string, number>>({});
  const activeTabRef = useRef<NavTab>(activeTab);
  const activeConvIdRef = useRef<string | null>(activeConversationId);
  const usersRef = useRef<UserProfile[]>([]);
  const languageRef = useRef<Language>(language);

  useEffect(() => {
    activeTabRef.current = activeTab;
  }, [activeTab]);

  useEffect(() => {
    activeConvIdRef.current = activeConversationId;
  }, [activeConversationId]);

  useEffect(() => {
    languageRef.current = language;
  }, [language]);

  const t = translations[language];

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3000);
  }, []);

  const clearMessagingError = useCallback(() => {
    setMessagingError(null);
  }, []);

  const dismissChatAlert = useCallback(() => {
    setChatAlert(null);
  }, []);

  // Track browser online/offline network status
  useEffect(() => {
    const handleOnline = () => setIsOnlineNetwork(true);
    const handleOffline = () => setIsOnlineNetwork(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    root.lang = language === 'bn' ? 'bn' : 'en';
    localStorage.setItem('sylhet_social_lang', language);
    localStorage.setItem('sylhet_social_theme', theme);
  }, [theme, language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    if (firebaseUser) {
      updateDoc(doc(db, 'users_private', firebaseUser.uid), {
        language: lang,
        updatedAt: serverTimestamp(),
      }).catch(() => {});
    }
  };

  const toggleTheme = () => {
    const next: ThemeMode = theme === 'light' ? 'dark' : 'light';
    setThemeState(next);
    if (firebaseUser) {
      updateDoc(doc(db, 'users_private', firebaseUser.uid), {
        theme: next,
        updatedAt: serverTimestamp(),
      }).catch(() => {});
    }
  };

  const isBootstrappedAdmin = Boolean(
    firebaseUser?.email === BOOTSTRAPPED_ADMIN_EMAIL && firebaseUser.emailVerified
  );

  const isAdmin = Boolean(isBootstrappedAdmin || myAdminDoc);
  const adminRole: 'admin' | 'moderator' | null = isBootstrappedAdmin
    ? 'admin'
    : myAdminDoc?.role ?? null;

  const setActiveTab = useCallback(
    (tab: NavTab) => {
      if (tab === 'admin' && !isAdmin) {
        setActiveTabState('feed');
        return;
      }
      setActiveTabState(tab);
    },
    [isAdmin]
  );

  // Guard against non-admin reaching admin view
  useEffect(() => {
    if (activeTab === 'admin' && !isAdmin) {
      setActiveTabState('feed');
    }
  }, [activeTab, isAdmin]);

  // Provision or verify user profile on Firebase Auth change
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (!fbUser) {
        setMyAdminDoc(null);
        setAdminVerified(false);
        setRawUsers([]);
        setOwnUserDoc(null);
        setRtdbPresenceByUid({});
        setRtdbConnected(false);
        setPrivateEmailsByUid({});
        setRawApprovedPosts([]);
        setRawOwnPosts([]);
        setRawAllAdminPosts([]);
        setLikedPostIds({});
        setCommentsByPost({});
        setSavedPostIds([]);
        setFriendships([]);
        setFollowingDocs([]);
        setFollowerDocs([]);
        setRawConversations([]);
        setMessagesByConv({});
        setMessagesLoading(false);
        setMessagingError(null);
        setRtdbPartnerTyping(false);
        setBlocksByMe([]);
        setBlocksAgainstMe([]);
        setChatAlert(null);
        initializedConvsRef.current = {};
        knownMsgIdsRef.current.clear();
        lastTypingFirestoreWriteRef.current = {};
        setDirectNotifications([]);
        setBroadcastNotifications([]);
        setReports([]);
        setAuditLogs([]);
        setAdminRecords([]);
        setRawFirestoreLocations([]);
        setRawFirestoreAttractions([]);
        setRawFirestoreAdPackages([]);
        setRawLiveLocalAds([]);
        setRawMyLocalAds([]);
        setRawAdminLocalAds([]);
        setMonetizationConfig(DEFAULT_MONETIZATION_CONFIG);
        trackedAdImpressionsRef.current.clear();
        setAuthReady(true);
        return;
      }

      setViewedProfileId((prev) => prev || fbUser.uid);

      try {
        const publicRef = doc(db, 'users_public', fbUser.uid);
        const privateRef = doc(db, 'users_private', fbUser.uid);
        const adminRef = doc(db, 'admins', fbUser.uid);

        const [pubSnap, adminSnap, settingsSnap] = await Promise.all([
          getDoc(publicRef),
          getDoc(adminRef),
          getDoc(doc(db, 'appSettings', 'global')).catch(() => null),
        ]);

        const bootAdmin =
          fbUser.email === BOOTSTRAPPED_ADMIN_EMAIL && fbUser.emailVerified;

        if (!pubSnap.exists()) {
          const settingsData = settingsSnap?.exists()
            ? (settingsSnap.data() as Partial<AppSettings>)
            : null;
          if (settingsData && settingsData.allowRegistrations === false && !bootAdmin) {
            setAuthError(translations[language].auth.registrationsPaused);
            await signOut(auth);
            setAuthReady(true);
            return;
          }

          const displayName = (fbUser.displayName || 'Sylhet Member').slice(0, 80);
          const uname = sanitizeUsername(
            fbUser.email?.split('@')[0] || fbUser.displayName || fbUser.uid
          );

          await setDoc(publicRef, {
            uid: fbUser.uid,
            name: displayName,
            nameBn: displayName,
            username: uname,
            avatarUrl: (fbUser.photoURL || ASSET_IMAGES.avatarTariq).slice(0, 490000),
            coverUrl: ASSET_IMAGES.teaGardenCover,
            bio: 'Connecting with friends across Sylhet.',
            bioBn: 'সিলেটের বন্ধুদের সাথে যুক্ত আছি।',
            location: 'Zindabazar, Sylhet',
            locationBn: 'জিন্দাবাজার, সিলেট',
            workOrStudy: 'Sylhet Social Member',
            workOrStudyBn: 'Sylhet Social সদস্য',
            joinedDate: new Date().toLocaleDateString('en-US', {
              month: 'short',
              year: 'numeric',
            }),
            role: 'user',
            status: 'active',
            friendsCount: 0,
            followersCount: 0,
            followingCount: 0,
            isOnline: true,
            lastSeenAt: serverTimestamp(),
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });

          await setDoc(privateRef, {
            uid: fbUser.uid,
            email: fbUser.email || `${fbUser.uid}@sylhetsocial.bd`,
            language,
            theme,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } else {
          await updateDoc(publicRef, {
            isOnline: true,
            lastSeenAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          }).catch(() => {});
        }

        if (bootAdmin) {
          if (!adminSnap.exists()) {
            await setDoc(adminRef, {
              uid: fbUser.uid,
              email: fbUser.email || BOOTSTRAPPED_ADMIN_EMAIL,
              role: 'admin',
              grantedBy: fbUser.uid,
              createdAt: serverTimestamp(),
            });
          }
          const latestPub = await getDoc(publicRef);
          if (latestPub.exists() && latestPub.data().role !== 'admin') {
            await updateDoc(publicRef, {
              role: 'admin',
              updatedAt: serverTimestamp(),
            });
          }
          if (settingsSnap && !settingsSnap.exists()) {
            await setDoc(doc(db, 'appSettings', 'global'), {
              siteName: 'Sylhet Social',
              maintenanceMode: false,
              allowRegistrations: true,
              requirePostReview: false,
              maxUploadMb: 5,
              featuredBannerEn: 'Explore Ratargul, Jaflong & Surma stories today',
              featuredBannerBn: 'রাতারগুল, জাফলং ও সুরমা নদীর আজকের গল্প দেখুন',
              updatedBy: fbUser.uid,
              updatedAt: serverTimestamp(),
            });
          }
          // Auto-seed default ad packages & monetization config if empty so local business submissions work immediately
          try {
            const [existingPkgsSnap, existingMonSnap] = await Promise.all([
              getDocs(collection(db, 'adPackages')),
              getDoc(doc(db, 'monetizationConfig', 'global')),
            ]);
            if (existingPkgsSnap.empty) {
              const pkgBatch = writeBatch(db);
              for (const pkg of DEFAULT_AD_PACKAGES) {
                pkgBatch.set(doc(db, 'adPackages', pkg.id), {
                  id: pkg.id,
                  name: pkg.name,
                  nameBn: pkg.nameBn,
                  description: pkg.description || '',
                  descriptionBn: pkg.descriptionBn || '',
                  durationDays: pkg.durationDays,
                  priceBdt: pkg.priceBdt,
                  placement: pkg.placement,
                  isActive: pkg.isActive,
                  sortOrder: pkg.sortOrder,
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp(),
                });
              }
              await pkgBatch.commit();
            }
            if (!existingMonSnap.exists()) {
              await setDoc(doc(db, 'monetizationConfig', 'global'), {
                admobEnvironment: DEFAULT_MONETIZATION_CONFIG.admobEnvironment,
                admobBannerEnabled: DEFAULT_MONETIZATION_CONFIG.admobBannerEnabled,
                admobNativeEnabled: DEFAULT_MONETIZATION_CONFIG.admobNativeEnabled,
                localAdsEnabled: DEFAULT_MONETIZATION_CONFIG.localAdsEnabled,
                feedAdInterval: DEFAULT_MONETIZATION_CONFIG.feedAdInterval,
                requireAdConsent: DEFAULT_MONETIZATION_CONFIG.requireAdConsent,
                manualPaymentInstructionsEn: DEFAULT_MONETIZATION_CONFIG.manualPaymentInstructionsEn,
                manualPaymentInstructionsBn: DEFAULT_MONETIZATION_CONFIG.manualPaymentInstructionsBn,
                updatedBy: fbUser.uid,
                updatedAt: serverTimestamp(),
              });
            }
          } catch {
            // Non-fatal
          }
          setMyAdminDoc({
            uid: fbUser.uid,
            email: fbUser.email || BOOTSTRAPPED_ADMIN_EMAIL,
            role: 'admin',
            grantedBy: fbUser.uid,
            createdAt: new Date().toISOString(),
          });
          setAdminVerified(true);
        } else if (adminSnap.exists()) {
          const data = adminSnap.data();
          setMyAdminDoc({
            uid: data.uid,
            email: data.email,
            role: data.role,
            grantedBy: data.grantedBy,
            createdAt: toIso(data.createdAt),
          });
        } else {
          setMyAdminDoc(null);
          setAdminVerified(false);
        }
      } catch (err) {
        console.error('Auth profile sync error:', err);
      } finally {
        setAuthReady(true);
      }
    });

    return () => unsub();
  }, [language, theme]);

  // Listen to global app settings
  useEffect(() => {
    if (!firebaseUser) return;
    const unsub = onSnapshot(
      doc(db, 'appSettings', 'global'),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data();
          setAppSettings({
            siteName: d.siteName || 'Sylhet Social',
            maintenanceMode: Boolean(d.maintenanceMode),
            allowRegistrations: d.allowRegistrations !== false,
            requirePostReview: Boolean(d.requirePostReview),
            maxUploadMb: typeof d.maxUploadMb === 'number' ? d.maxUploadMb : 5,
            featuredBannerEn: d.featuredBannerEn || DEFAULT_APP_SETTINGS.featuredBannerEn,
            featuredBannerBn: d.featuredBannerBn || DEFAULT_APP_SETTINGS.featuredBannerBn,
            updatedBy: d.updatedBy || 'system',
            updatedAt: toIso(d.updatedAt),
          });
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, 'appSettings/global')
    );
    return () => unsub();
  }, [firebaseUser]);

  // Listen to admin doc for current user
  useEffect(() => {
    if (!firebaseUser) return;
    const unsub = onSnapshot(
      doc(db, 'admins', firebaseUser.uid),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data();
          setMyAdminDoc({
            uid: d.uid,
            email: d.email,
            role: d.role,
            grantedBy: d.grantedBy,
            createdAt: toIso(d.createdAt),
          });
        } else if (!isBootstrappedAdmin) {
          setMyAdminDoc(null);
          setAdminVerified(false);
        }
      },
      () => {
        // Non-admins reading missing admins doc is fine
      }
    );
    return () => unsub();
  }, [firebaseUser, isBootstrappedAdmin]);

  // Real-time presence sync (Firebase Realtime Database + Firestore lifecycle heartbeat)
  useEffect(() => {
    if (!firebaseUser) return;
    const uid = firebaseUser.uid;

    const unsubSelfPresence = subscribeRtdbConnectionAndPresence(uid, setRtdbConnected);
    const unsubAllPresence = subscribeAllRtdbPresence(setRtdbPresenceByUid);

    const setFirestorePresence = (online: boolean) => {
      updateDoc(doc(db, 'users_public', uid), {
        isOnline: online,
        lastSeenAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }).catch(() => {});
    };

    const handleVisibility = () => {
      setFirestorePresence(document.visibilityState === 'visible');
    };
    const handleUnload = () => {
      setFirestorePresence(false);
    };

    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('pagehide', handleUnload);

    const heartbeat = window.setInterval(() => {
      if (document.visibilityState === 'visible' && navigator.onLine) {
        setFirestorePresence(true);
      }
    }, 60000);

    return () => {
      unsubSelfPresence();
      unsubAllPresence();
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('pagehide', handleUnload);
      window.clearInterval(heartbeat);
    };
  }, [firebaseUser]);

  // Listen to own public profile directly (so suspended users still resolve currentUser)
  useEffect(() => {
    if (!firebaseUser) return;
    const unsubOwn = onSnapshot(
      doc(db, 'users_public', firebaseUser.uid),
      (snap) => {
        if (!snap.exists()) {
          setOwnUserDoc(null);
          return;
        }
        const d = snap.data();
        setOwnUserDoc({
          id: d.uid || snap.id,
          uid: d.uid || snap.id,
          name: d.name || 'Sylhet Member',
          nameBn: d.nameBn || d.name || 'Sylhet Member',
          username: d.username || snap.id.slice(0, 8),
          avatarUrl: d.avatarUrl || '',
          coverUrl: d.coverUrl || ASSET_IMAGES.teaGardenCover,
          bio: d.bio || '',
          bioBn: d.bioBn || d.bio || '',
          location: d.location || 'Sylhet',
          locationBn: d.locationBn || d.location || 'সিলেট',
          workOrStudy: d.workOrStudy || '',
          workOrStudyBn: d.workOrStudyBn || d.workOrStudy || '',
          joinedDate: d.joinedDate || '2026',
          role: d.role || 'user',
          status: d.status || 'active',
          friendsCount: typeof d.friendsCount === 'number' ? d.friendsCount : 0,
          followersCount: typeof d.followersCount === 'number' ? d.followersCount : 0,
          followingCount: typeof d.followingCount === 'number' ? d.followingCount : 0,
          friends: [],
          friendRequestsReceived: [],
          friendRequestsSent: [],
          followers: [],
          following: [],
          isOnline: Boolean(d.isOnline),
          lastSeenAt: d.lastSeenAt ? toIso(d.lastSeenAt) : undefined,
          createdAt: toIso(d.createdAt),
          updatedAt: toIso(d.updatedAt),
        });
      },
      (err) => handleFirestoreError(err, OperationType.GET, `users_public/${firebaseUser.uid}`)
    );
    return () => unsubOwn();
  }, [firebaseUser]);

  // Listen to users_public
  useEffect(() => {
    if (!firebaseUser) return;
    const usersQuery =
      isAdmin && adminVerified
        ? collection(db, 'users_public')
        : query(collection(db, 'users_public'), where('status', '==', 'active'));

    const unsub = onSnapshot(
      usersQuery,
      (snap) => {
        const list: UserProfile[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: d.uid || docSnap.id,
            uid: d.uid || docSnap.id,
            name: d.name || 'Sylhet Member',
            nameBn: d.nameBn || d.name || 'Sylhet Member',
            username: d.username || docSnap.id.slice(0, 8),
            avatarUrl: d.avatarUrl || '',
            coverUrl: d.coverUrl || ASSET_IMAGES.teaGardenCover,
            bio: d.bio || '',
            bioBn: d.bioBn || d.bio || '',
            location: d.location || 'Sylhet',
            locationBn: d.locationBn || d.location || 'সিলেট',
            workOrStudy: d.workOrStudy || '',
            workOrStudyBn: d.workOrStudyBn || d.workOrStudy || '',
            joinedDate: d.joinedDate || '2026',
            role: d.role || 'user',
            status: d.status || 'active',
            friendsCount: typeof d.friendsCount === 'number' ? d.friendsCount : 0,
            followersCount: typeof d.followersCount === 'number' ? d.followersCount : 0,
            followingCount: typeof d.followingCount === 'number' ? d.followingCount : 0,
            friends: [],
            friendRequestsReceived: [],
            friendRequestsSent: [],
            followers: [],
            following: [],
            isOnline: Boolean(d.isOnline),
            lastSeenAt: d.lastSeenAt ? toIso(d.lastSeenAt) : undefined,
            createdAt: toIso(d.createdAt),
            updatedAt: toIso(d.updatedAt),
          };
        });
        setRawUsers(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'users_public')
    );
    return () => unsub();
  }, [firebaseUser, isAdmin, adminVerified]);

  // Listen to posts (approved + own posts for regular users; all posts for verified admins)
  useEffect(() => {
    if (!firebaseUser) return;
    if (isAdmin && adminVerified) {
      const unsubAll = onSnapshot(
        collection(db, 'posts'),
        (snap) => {
          const mapped = snap.docs.map((docSnap) => {
            const d = docSnap.data();
            return {
              id: d.id || docSnap.id,
              authorId: d.authorId,
              mediaType: d.mediaType || 'text',
              text: d.text || '',
              textBn: d.textBn,
              photoUrl: d.photoUrl,
              videoUrl: d.videoUrl,
              videoThumbnailUrl: d.videoThumbnailUrl,
              videoDuration: d.videoDuration,
              textCardTheme: d.textCardTheme || 'none',
              location: d.location,
              locationBn: d.locationBn,
              moderationStatus: d.moderationStatus || 'approved',
              moderationNote: d.moderationNote,
              createdAt: toIso(d.createdAt),
              updatedAt: toIso(d.updatedAt),
              likesCount: typeof d.likesCount === 'number' ? d.likesCount : 0,
              commentsCount: typeof d.commentsCount === 'number' ? d.commentsCount : 0,
              sharesCount: typeof d.sharesCount === 'number' ? d.sharesCount : 0,
              comments: [],
              sharedPostId: d.sharedPostId,
            } as PostItem;
          });
          setRawAllAdminPosts(mapped);
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'posts')
      );
      return () => unsubAll();
    }

    const unsubApproved = onSnapshot(
      query(collection(db, 'posts'), where('moderationStatus', '==', 'approved')),
      (snap) => {
        const mapped = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: d.id || docSnap.id,
            authorId: d.authorId,
            mediaType: d.mediaType || 'text',
            text: d.text || '',
            textBn: d.textBn,
            photoUrl: d.photoUrl,
            videoUrl: d.videoUrl,
            videoThumbnailUrl: d.videoThumbnailUrl,
            videoDuration: d.videoDuration,
            textCardTheme: d.textCardTheme || 'none',
            location: d.location,
            locationBn: d.locationBn,
            moderationStatus: d.moderationStatus || 'approved',
            moderationNote: d.moderationNote,
            createdAt: toIso(d.createdAt),
            updatedAt: toIso(d.updatedAt),
            likesCount: typeof d.likesCount === 'number' ? d.likesCount : 0,
            commentsCount: typeof d.commentsCount === 'number' ? d.commentsCount : 0,
            sharesCount: typeof d.sharesCount === 'number' ? d.sharesCount : 0,
            comments: [],
            sharedPostId: d.sharedPostId,
          } as PostItem;
        });
        setRawApprovedPosts(mapped);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'posts')
    );

    const unsubOwn = onSnapshot(
      query(collection(db, 'posts'), where('authorId', '==', firebaseUser.uid)),
      (snap) => {
        const mapped = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: d.id || docSnap.id,
            authorId: d.authorId,
            mediaType: d.mediaType || 'text',
            text: d.text || '',
            textBn: d.textBn,
            photoUrl: d.photoUrl,
            videoUrl: d.videoUrl,
            videoThumbnailUrl: d.videoThumbnailUrl,
            videoDuration: d.videoDuration,
            textCardTheme: d.textCardTheme || 'none',
            location: d.location,
            locationBn: d.locationBn,
            moderationStatus: d.moderationStatus || 'approved',
            moderationNote: d.moderationNote,
            createdAt: toIso(d.createdAt),
            updatedAt: toIso(d.updatedAt),
            likesCount: typeof d.likesCount === 'number' ? d.likesCount : 0,
            commentsCount: typeof d.commentsCount === 'number' ? d.commentsCount : 0,
            sharesCount: typeof d.sharesCount === 'number' ? d.sharesCount : 0,
            comments: [],
            sharedPostId: d.sharedPostId,
          } as PostItem;
        });
        setRawOwnPosts(mapped);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'posts')
    );

    return () => {
      unsubApproved();
      unsubOwn();
    };
  }, [firebaseUser, isAdmin, adminVerified]);

  const basePosts = useMemo(() => {
    const source = isAdmin && adminVerified ? rawAllAdminPosts : [...rawApprovedPosts, ...rawOwnPosts];
    const map = new Map<string, PostItem>();
    for (const p of source) {
      map.set(p.id, p);
    }
    return Array.from(map.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [isAdmin, adminVerified, rawAllAdminPosts, rawApprovedPosts, rawOwnPosts]);

  // Listen to likes & comments on active posts
  useEffect(() => {
    if (!firebaseUser || basePosts.length === 0) return;
    const unsubs: (() => void)[] = [];

    for (const post of basePosts.slice(0, 40)) {
      const unsubLike = onSnapshot(
        doc(db, 'posts', post.id, 'likes', firebaseUser.uid),
        (snap) => {
          setLikedPostIds((prev) => ({ ...prev, [post.id]: snap.exists() }));
        },
        () => {}
      );
      const unsubComments = onSnapshot(
        query(collection(db, 'posts', post.id, 'comments'), where('postId', '==', post.id)),
        (snap) => {
          const list: PostComment[] = snap.docs
            .map((cSnap) => {
              const d = cSnap.data();
              return {
                id: d.id || cSnap.id,
                postId: d.postId,
                authorId: d.authorId,
                text: d.text,
                createdAt: toIso(d.createdAt),
              };
            })
            .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
          setCommentsByPost((prev) => ({ ...prev, [post.id]: list }));
        },
        () => {}
      );
      unsubs.push(unsubLike, unsubComments);
    }

    return () => {
      for (const u of unsubs) u();
    };
  }, [firebaseUser, basePosts]);

  // Saved posts listener
  useEffect(() => {
    if (!firebaseUser) return;
    const unsub = onSnapshot(
      query(
        collection(db, 'users_public', firebaseUser.uid, 'savedPosts'),
        where('userId', '==', firebaseUser.uid)
      ),
      (snap) => {
        setSavedPostIds(snap.docs.map((d) => d.id));
      },
      (err) =>
        handleFirestoreError(err, OperationType.LIST, `users_public/${firebaseUser.uid}/savedPosts`)
    );
    return () => unsub();
  }, [firebaseUser]);

  // Friendships listener
  useEffect(() => {
    if (!firebaseUser) return;
    const unsub = onSnapshot(
      query(collection(db, 'friendships'), where('userIds', 'array-contains', firebaseUser.uid)),
      (snap) => {
        setFriendships(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              userIds: data.userIds || [],
              requesterId: data.requesterId,
              recipientId: data.recipientId,
              status: data.status,
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'friendships')
    );
    return () => unsub();
  }, [firebaseUser]);

  // Follows listeners
  useEffect(() => {
    if (!firebaseUser) return;
    const unsubFollowing = onSnapshot(
      query(collection(db, 'follows'), where('followerId', '==', firebaseUser.uid)),
      (snap) => {
        setFollowingDocs(
          snap.docs.map((d) => ({
            followerId: d.data().followerId,
            followingId: d.data().followingId,
          }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'follows')
    );
    const unsubFollowers = onSnapshot(
      query(collection(db, 'follows'), where('followingId', '==', firebaseUser.uid)),
      (snap) => {
        setFollowerDocs(
          snap.docs.map((d) => ({
            followerId: d.data().followerId,
            followingId: d.data().followingId,
          }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'follows')
    );
    return () => {
      unsubFollowing();
      unsubFollowers();
    };
  }, [firebaseUser]);

  // User blocks listeners (both directions for safe chat isolation)
  useEffect(() => {
    if (!firebaseUser) return;
    const unsubByMe = onSnapshot(
      query(collection(db, 'userBlocks'), where('blockerId', '==', firebaseUser.uid)),
      (snap) => {
        setBlocksByMe(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: data.id || d.id,
              blockerId: data.blockerId,
              blockedId: data.blockedId,
              createdAt: toIso(data.createdAt),
            };
          })
        );
      },
      () => {
        // Non-fatal
      }
    );

    const unsubAgainstMe = onSnapshot(
      query(collection(db, 'userBlocks'), where('blockedId', '==', firebaseUser.uid)),
      (snap) => {
        setBlocksAgainstMe(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: data.id || d.id,
              blockerId: data.blockerId,
              blockedId: data.blockedId,
              createdAt: toIso(data.createdAt),
            };
          })
        );
      },
      () => {
        // Non-fatal
      }
    );

    return () => {
      unsubByMe();
      unsubAgainstMe();
    };
  }, [firebaseUser]);

  // Conversations listener
  useEffect(() => {
    if (!firebaseUser) return;
    setMessagesLoading(true);
    const unsub = onSnapshot(
      query(
        collection(db, 'conversations'),
        where('participantIds', 'array-contains', firebaseUser.uid)
      ),
      (snap) => {
        const list: ConversationThread[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: d.id,
              participantIds: data.participantIds as [string, string],
              lastMessageText: data.lastMessageText || '',
              lastMessageType: (data.lastMessageType as MessageMediaType) || 'text',
              lastMessageSenderId: data.lastMessageSenderId || undefined,
              lastMessageAt: data.lastMessageAt ? toIso(data.lastMessageAt) : undefined,
              unreadBy: Array.isArray(data.unreadBy) ? data.unreadBy : [],
              unreadCounts:
                data.unreadCounts && typeof data.unreadCounts === 'object'
                  ? (data.unreadCounts as Record<string, number>)
                  : undefined,
              typing:
                data.typing && typeof data.typing === 'object'
                  ? (data.typing as Record<string, number>)
                  : undefined,
              messages: [],
            };
          })
          .sort(
            (a, b) =>
              new Date(b.lastMessageAt || 0).getTime() - new Date(a.lastMessageAt || 0).getTime()
          );
        setRawConversations(list);
        setMessagingError(null);
        if (list.length === 0) {
          setMessagesLoading(false);
        }
      },
      (err) => {
        console.error('Conversations listener error:', err);
        setMessagesLoading(false);
        setMessagingError(
          languageRef.current === 'bn'
            ? 'কথোপকথন লোড করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।'
            : 'Could not load conversations. Check permissions or network connection.'
        );
      }
    );
    return () => unsub();
  }, [firebaseUser]);

  // RTDB typing listener for active conversation partner + auto-expiry tick
  useEffect(() => {
    if (!firebaseUser || !activeConversationId) {
      setRtdbPartnerTyping(false);
      return;
    }
    const conv = rawConversations.find((c) => c.id === activeConversationId);
    const partnerId = conv?.participantIds.find((id) => id !== firebaseUser.uid);
    if (!partnerId) {
      setRtdbPartnerTyping(false);
      return;
    }
    const unsub = subscribeRtdbTyping(activeConversationId, partnerId, setRtdbPartnerTyping);
    return () => {
      unsub();
      setRtdbPartnerTyping(false);
    };
  }, [firebaseUser, activeConversationId, rawConversations]);

  useEffect(() => {
    const hasActiveTyping = rawConversations.some(
      (c) => c.typing && Object.values(c.typing).some((ts) => typeof ts === 'number' && ts > 0)
    );
    if (!hasActiveTyping && !rtdbPartnerTyping) return;
    const timer = window.setInterval(() => {
      setTypingTick((prev) => (prev + 1) % 10000);
    }, 1500);
    return () => window.clearInterval(timer);
  }, [rawConversations, rtdbPartnerTyping]);

  // Real-time messages listener per conversation (with automatic Delivered / Seen receipts & alerts)
  useEffect(() => {
    if (!firebaseUser || rawConversations.length === 0) return;
    const uid = firebaseUser.uid;
    const unsubs: (() => void)[] = [];

    for (const conv of rawConversations) {
      const unsub = onSnapshot(
        query(
          collection(db, 'conversations', conv.id, 'messages'),
          where('participantIds', 'array-contains', uid)
        ),
        (snap) => {
          const msgs: MessageItem[] = snap.docs
            .map((m) => {
              const d = m.data();
              return {
                id: d.id || m.id,
                conversationId: d.conversationId,
                senderId: d.senderId,
                messageType: (d.messageType as MessageMediaType) || 'text',
                text: typeof d.text === 'string' ? d.text : '',
                mediaUrl: d.mediaUrl,
                mediaName: d.mediaName,
                mediaSize: typeof d.mediaSize === 'number' ? d.mediaSize : undefined,
                mediaDurationSec:
                  typeof d.mediaDurationSec === 'number' ? d.mediaDurationSec : undefined,
                deliveredTo: Array.isArray(d.deliveredTo) ? d.deliveredTo : [d.senderId],
                seenBy: Array.isArray(d.seenBy) ? d.seenBy : [d.senderId],
                deliveredAt: d.deliveredAt ? toIso(d.deliveredAt) : undefined,
                seenAt: d.seenAt ? toIso(d.seenAt) : undefined,
                createdAt: toIso(d.createdAt),
              };
            })
            .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

          setMessagesByConv((prev) => ({ ...prev, [conv.id]: msgs }));
          setMessagesLoading(false);

          const isActivelyViewing =
            activeTabRef.current === 'messages' &&
            activeConvIdRef.current === conv.id &&
            document.visibilityState === 'visible';

          // Detect newly arrived messages after initial snapshot hydration
          const alreadyInit = Boolean(initializedConvsRef.current[conv.id]);
          if (!alreadyInit) {
            for (const m of msgs) {
              knownMsgIdsRef.current.add(m.id);
            }
            initializedConvsRef.current[conv.id] = true;
          } else {
            const incomingNew = msgs.filter(
              (m) => m.senderId !== uid && !knownMsgIdsRef.current.has(m.id)
            );
            for (const m of msgs) {
              knownMsgIdsRef.current.add(m.id);
            }

            if (incomingNew.length > 0 && !isActivelyViewing) {
              const latest = incomingNew[incomingNew.length - 1];
              const sender = usersRef.current.find((u) => u.uid === latest.senderId);
              const lang = languageRef.current;
              const senderName = sender
                ? lang === 'bn' && sender.nameBn
                  ? sender.nameBn
                  : sender.name
                : translations[lang].messagesPage.sylhetMember;
              const fallbackLabel =
                latest.messageType === 'image'
                  ? translations[lang].messagesPage.photoLabel
                  : latest.messageType === 'video'
                  ? translations[lang].messagesPage.videoLabel
                  : latest.messageType === 'voice'
                  ? translations[lang].messagesPage.voiceMessage
                  : '';
              const preview = latest.text || fallbackLabel;

              playChatChime();
              setChatAlert({
                id: latest.id,
                conversationId: conv.id,
                senderId: latest.senderId,
                senderName,
                avatarUrl: sender?.avatarUrl || '',
                preview,
              });
              window.setTimeout(() => {
                setChatAlert((prev) => (prev?.id === latest.id ? null : prev));
              }, 6000);

              if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
                try {
                  const n = new Notification(senderName, {
                    body: preview,
                    tag: conv.id,
                  });
                  n.onclick = () => {
                    window.focus();
                    setActiveConversationId(conv.id);
                    setActiveTabState('messages');
                    n.close();
                  };
                } catch {
                  // Ignore browser notification errors
                }
              }
            }
          }

          // Automatically acknowledge delivery (and seen if user is actively viewing)
          const pendingDeliveryOrSeen = msgs.filter(
            (m) =>
              m.senderId !== uid &&
              (!m.deliveredTo.includes(uid) || (isActivelyViewing && !m.seenBy.includes(uid)))
          );

          if (pendingDeliveryOrSeen.length > 0) {
            const batch = writeBatch(db);
            for (const m of pendingDeliveryOrSeen.slice(-25)) {
              const updatePayload: Record<string, unknown> = {
                deliveredTo: arrayUnion(uid),
              };
              if (!m.deliveredAt) {
                updatePayload.deliveredAt = serverTimestamp();
              }
              if (isActivelyViewing) {
                updatePayload.seenBy = arrayUnion(uid);
                if (!m.seenAt) {
                  updatePayload.seenAt = serverTimestamp();
                }
              }
              batch.update(doc(db, 'conversations', conv.id, 'messages', m.id), updatePayload);
            }
            if (isActivelyViewing && (conv.unreadBy.includes(uid) || (conv.unreadCounts?.[uid] ?? 0) > 0)) {
              const nextCounts: Record<string, number> = { ...(conv.unreadCounts || {}), [uid]: 0 };
              batch.update(doc(db, 'conversations', conv.id), {
                unreadBy: conv.unreadBy.filter((id) => id !== uid),
                unreadCounts: nextCounts,
                updatedAt: serverTimestamp(),
              });
            }
            batch.commit().catch(() => {
              // Receipt sync failure is non-blocking
            });
          }
        },
        (err) => {
          console.error(`Messages listener error (${conv.id}):`, err);
          setMessagesLoading(false);
          setMessagingError(
            languageRef.current === 'bn'
              ? 'বার্তাগুলো লোড করতে অনুমতি বা নেটওয়ার্ক সমস্যা হয়েছে।'
              : 'Unable to load messages for this chat. Please check connection or permissions.'
          );
        }
      );
      unsubs.push(unsub);
    }
    return () => {
      for (const u of unsubs) u();
    };
  }, [firebaseUser, rawConversations]);

  // Notifications listener (direct + broadcasts)
  useEffect(() => {
    if (!firebaseUser) return;
    const unsubDirect = onSnapshot(
      query(collection(db, 'notifications'), where('targetUserId', '==', firebaseUser.uid)),
      (snap) => {
        setDirectNotifications(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              type: data.type,
              actorId: data.actorId,
              targetUserId: data.targetUserId,
              postId: data.postId,
              title: data.title,
              previewText: data.previewText,
              read: Boolean(data.read),
              createdAt: toIso(data.createdAt),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'notifications')
    );

    const unsubBroadcasts = onSnapshot(
      query(collection(db, 'notifications'), where('targetUserId', '==', 'all')),
      (snap) => {
        setBroadcastNotifications(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              type: data.type,
              actorId: data.actorId,
              targetUserId: data.targetUserId,
              postId: data.postId,
              title: data.title,
              previewText: data.previewText,
              read: false,
              createdAt: toIso(data.createdAt),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'notifications')
    );

    return () => {
      unsubDirect();
      unsubBroadcasts();
    };
  }, [firebaseUser]);

  // Admin-only listeners (NEVER attached for regular users!)
  useEffect(() => {
    if (!firebaseUser || !isAdmin || !adminVerified) {
      setReports([]);
      setAuditLogs([]);
      setAdminRecords([]);
      setPrivateEmailsByUid({});
      return;
    }

    const unsubReports = onSnapshot(
      collection(db, 'reports'),
      (snap) => {
        const list: ReportItem[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: data.id || d.id,
              reporterId: data.reporterId,
              targetType: data.targetType,
              targetPostId: data.targetPostId,
              targetUserId: data.targetUserId,
              reason: data.reason,
              details: data.details,
              status: data.status,
              reviewedBy: data.reviewedBy,
              resolutionNote: data.resolutionNote,
              createdAt: toIso(data.createdAt),
              updatedAt: toIso(data.updatedAt),
            };
          })
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setReports(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'reports')
    );

    const unsubAudit = onSnapshot(
      collection(db, 'auditLogs'),
      (snap) => {
        const list: AuditLogItem[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: data.id || d.id,
              adminUid: data.adminUid,
              adminEmail: data.adminEmail,
              action: data.action,
              targetType: data.targetType,
              targetId: data.targetId,
              summary: data.summary,
              createdAt: toIso(data.createdAt),
            };
          })
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setAuditLogs(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'auditLogs')
    );

    const unsubAdmins = onSnapshot(
      collection(db, 'admins'),
      (snap) => {
        setAdminRecords(
          snap.docs.map((d) => {
            const data = d.data();
            return {
              uid: data.uid || d.id,
              email: data.email,
              role: data.role,
              grantedBy: data.grantedBy,
              createdAt: toIso(data.createdAt),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'admins')
    );

    const unsubPrivate = onSnapshot(
      collection(db, 'users_private'),
      (snap) => {
        const emailMap: Record<string, string> = {};
        for (const d of snap.docs) {
          const email = d.data().email;
          if (typeof email === 'string') {
            emailMap[d.id] = email;
          }
        }
        setPrivateEmailsByUid(emailMap);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'users_private')
    );

    return () => {
      unsubReports();
      unsubAudit();
      unsubAdmins();
      unsubPrivate();
    };
  }, [firebaseUser, isAdmin, adminVerified]);

  // Real-time listeners for Hierarchical Locations & Tourist Attractions
  useEffect(() => {
    if (!firebaseUser) return;

    const locationsQuery =
      isAdmin && adminVerified
        ? collection(db, 'locations')
        : query(collection(db, 'locations'), where('isActive', '==', true));

    const attractionsQuery =
      isAdmin && adminVerified
        ? collection(db, 'attractions')
        : query(collection(db, 'attractions'), where('isActive', '==', true));

    const unsubLocations = onSnapshot(
      locationsQuery,
      (snap) => {
        const mapped: LocationNode[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: data.id || d.id,
              level: data.level as LocationLevel,
              name: data.name || '',
              nameBn: data.nameBn || data.name || '',
              parentId: data.parentId || '',
              divisionId: data.divisionId || '',
              districtId: data.districtId || '',
              upazilaId: data.upazilaId || '',
              unionId: data.unionId || '',
              isActive: data.isActive !== false,
              sortOrder: typeof data.sortOrder === 'number' ? data.sortOrder : 100,
              createdAt: toIso(data.createdAt),
              updatedAt: toIso(data.updatedAt),
            };
          })
          .sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name));
        setRawFirestoreLocations(mapped);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'locations')
    );

    const unsubAttractions = onSnapshot(
      attractionsQuery,
      (snap) => {
        const mapped: TouristAttraction[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: data.id || d.id,
              name: data.name || '',
              nameBn: data.nameBn || data.name || '',
              category: (data.category as AttractionCategory) || 'heritage',
              divisionId: data.divisionId || '',
              districtId: data.districtId || '',
              districtName: data.districtName || '',
              districtNameBn: data.districtNameBn || data.districtName || '',
              upazilaId: data.upazilaId || '',
              upazilaName: data.upazilaName || '',
              upazilaNameBn: data.upazilaNameBn || data.upazilaName || '',
              unionId: data.unionId || '',
              unionName: data.unionName || '',
              unionNameBn: data.unionNameBn || '',
              villageName: data.villageName || '',
              villageNameBn: data.villageNameBn || '',
              locationSummary: data.locationSummary || '',
              locationSummaryBn: data.locationSummaryBn || data.locationSummary || '',
              description: data.description || '',
              descriptionBn: data.descriptionBn || '',
              imageUrl: data.imageUrl || '',
              isFeatured: Boolean(data.isFeatured),
              isActive: data.isActive !== false,
              createdAt: toIso(data.createdAt),
              updatedAt: toIso(data.updatedAt),
            };
          })
          .sort(
            (a, b) =>
              Number(b.isFeatured) - Number(a.isFeatured) || a.name.localeCompare(b.name)
          );
        setRawFirestoreAttractions(mapped);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'attractions')
    );

    return () => {
      unsubLocations();
      unsubAttractions();
    };
  }, [firebaseUser, isAdmin, adminVerified]);

  // Real-time listeners for Ad Consent, Ad Packages, Local Business Ads & Monetization Config
  useEffect(() => {
    if (!firebaseUser) return;

    const unsubPrivateConsent = onSnapshot(
      doc(db, 'users_private', firebaseUser.uid),
      (snap) => {
        if (snap.exists()) {
          const val = snap.data().adConsentStatus;
          if (
            val === 'personalized' ||
            val === 'non_personalized' ||
            val === 'essential_only' ||
            val === 'unset'
          ) {
            setAdConsentStatus(val);
            if (val !== 'unset') {
              localStorage.setItem('sylhet_social_ad_consent', val);
            }
          }
        }
      },
      () => {}
    );

    const unsubMonConfig = onSnapshot(
      doc(db, 'monetizationConfig', 'global'),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data();
          setMonetizationConfig({
            admobEnvironment:
              d.admobEnvironment === 'production_ready' ? 'production_ready' : 'development_test',
            admobBannerEnabled: d.admobBannerEnabled !== false,
            admobNativeEnabled: d.admobNativeEnabled !== false,
            localAdsEnabled: d.localAdsEnabled !== false,
            feedAdInterval:
              typeof d.feedAdInterval === 'number' && d.feedAdInterval >= 2
                ? d.feedAdInterval
                : 4,
            requireAdConsent: d.requireAdConsent !== false,
            manualPaymentInstructionsEn:
              d.manualPaymentInstructionsEn ||
              DEFAULT_MONETIZATION_CONFIG.manualPaymentInstructionsEn,
            manualPaymentInstructionsBn:
              d.manualPaymentInstructionsBn ||
              DEFAULT_MONETIZATION_CONFIG.manualPaymentInstructionsBn,
            updatedBy: d.updatedBy || 'system',
            updatedAt: toIso(d.updatedAt),
          });
        }
      },
      () => {}
    );

    const packagesQuery =
      isAdmin && adminVerified
        ? collection(db, 'adPackages')
        : query(collection(db, 'adPackages'), where('isActive', '==', true));

    const unsubPackages = onSnapshot(
      packagesQuery,
      (snap) => {
        const mapped: AdPackage[] = snap.docs
          .map((d) => {
            const data = d.data();
            return {
              id: data.id || d.id,
              name: data.name || '',
              nameBn: data.nameBn || data.name || '',
              description: data.description || '',
              descriptionBn: data.descriptionBn || '',
              durationDays: typeof data.durationDays === 'number' ? data.durationDays : 7,
              priceBdt: typeof data.priceBdt === 'number' ? data.priceBdt : 500,
              placement: (data.placement as AdPlacement) || 'feed',
              isActive: data.isActive !== false,
              sortOrder: typeof data.sortOrder === 'number' ? data.sortOrder : 10,
              createdAt: toIso(data.createdAt),
              updatedAt: toIso(data.updatedAt),
            };
          })
          .sort((a, b) => a.sortOrder - b.sortOrder || a.priceBdt - b.priceBdt);
        setRawFirestoreAdPackages(mapped);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'adPackages')
    );

    const mapLocalAd = (docId: string, d: Record<string, unknown>): LocalAd => ({
      id: (d.id as string) || docId,
      advertiserUid: (d.advertiserUid as string) || '',
      businessName: (d.businessName as string) || '',
      category: (d.category as AdCategory) || 'other',
      title: (d.title as string) || '',
      titleBn: (d.titleBn as string) || undefined,
      description: (d.description as string) || '',
      descriptionBn: (d.descriptionBn as string) || undefined,
      imageUrl: (d.imageUrl as string) || undefined,
      contactPhone: (d.contactPhone as string) || '',
      whatsappNumber: (d.whatsappNumber as string) || undefined,
      contactEmail: (d.contactEmail as string) || undefined,
      websiteUrl: (d.websiteUrl as string) || undefined,
      ctaLabel: (d.ctaLabel as AdCtaLabel) || 'call_now',
      location: (d.location as string) || '',
      locationBn: (d.locationBn as string) || undefined,
      districtId: (d.districtId as string) || undefined,
      upazilaId: (d.upazilaId as string) || undefined,
      packageId: (d.packageId as string) || '',
      packageName: (d.packageName as string) || '',
      placement: (d.placement as AdPlacement) || 'feed',
      durationDays: typeof d.durationDays === 'number' ? d.durationDays : 7,
      priceBdt: typeof d.priceBdt === 'number' ? d.priceBdt : 0,
      status: (d.status as AdStatus) || 'pending_review',
      paymentStatus: (d.paymentStatus as AdPaymentStatus) || 'unpaid',
      paymentMethod: (d.paymentMethod as AdPaymentMethod) || 'none',
      paymentReference: (d.paymentReference as string) || undefined,
      paymentConfirmedBy: (d.paymentConfirmedBy as string) || undefined,
      paymentConfirmedAt: d.paymentConfirmedAt ? toIso(d.paymentConfirmedAt) : undefined,
      adminNote: (d.adminNote as string) || undefined,
      startsAt: d.startsAt ? toIso(d.startsAt) : undefined,
      endsAt: d.endsAt ? toIso(d.endsAt) : undefined,
      impressionsCount: typeof d.impressionsCount === 'number' ? d.impressionsCount : 0,
      clicksCount: typeof d.clicksCount === 'number' ? d.clicksCount : 0,
      createdAt: toIso(d.createdAt),
      updatedAt: toIso(d.updatedAt),
    });

    if (isAdmin && adminVerified) {
      const unsubAdminAds = onSnapshot(
        collection(db, 'localAds'),
        (snap) => {
          setRawAdminLocalAds(snap.docs.map((d) => mapLocalAd(d.id, d.data())));
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'localAds')
      );
      return () => {
        unsubPrivateConsent();
        unsubMonConfig();
        unsubPackages();
        unsubAdminAds();
      };
    }

    const unsubLiveAds = onSnapshot(
      query(
        collection(db, 'localAds'),
        where('status', '==', 'approved'),
        where('paymentStatus', '==', 'paid')
      ),
      (snap) => {
        setRawLiveLocalAds(snap.docs.map((d) => mapLocalAd(d.id, d.data())));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'localAds')
    );

    const unsubMyAds = onSnapshot(
      query(collection(db, 'localAds'), where('advertiserUid', '==', firebaseUser.uid)),
      (snap) => {
        setRawMyLocalAds(snap.docs.map((d) => mapLocalAd(d.id, d.data())));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'localAds')
    );

    return () => {
      unsubPrivateConsent();
      unsubMonConfig();
      unsubPackages();
      unsubLiveAds();
      unsubMyAds();
    };
  }, [firebaseUser, isAdmin, adminVerified]);

  // Merge user relationships & RTDB presence cleanly into UserProfile[]
  const users = useMemo(() => {
    if (!firebaseUser) return rawUsers;
    const myFriends: string[] = [];
    const myReqSent: string[] = [];
    const myReqReceived: string[] = [];

    for (const f of friendships) {
      const other = f.userIds.find((id) => id !== firebaseUser.uid);
      if (!other) continue;
      if (f.status === 'accepted') myFriends.push(other);
      if (f.status === 'pending' && f.requesterId === firebaseUser.uid) myReqSent.push(other);
      if (f.status === 'pending' && f.recipientId === firebaseUser.uid) myReqReceived.push(other);
    }

    const myFollowing = followingDocs.map((f) => f.followingId);
    const myFollowers = followerDocs.map((f) => f.followerId);

    const combined =
      ownUserDoc && !rawUsers.some((u) => u.uid === ownUserDoc.uid)
        ? [ownUserDoc, ...rawUsers]
        : rawUsers;

    return combined.map((u) => {
      const rtdbEntry = rtdbPresenceByUid[u.uid];
      const mergedOnline = rtdbEntry ? rtdbEntry.state === 'online' : Boolean(u.isOnline);
      const mergedLastSeen =
        rtdbEntry && rtdbEntry.lastChanged
          ? new Date(rtdbEntry.lastChanged).toISOString()
          : u.lastSeenAt;

      if (u.uid === firebaseUser.uid) {
        return {
          ...u,
          isOnline: mergedOnline,
          lastSeenAt: mergedLastSeen,
          email: firebaseUser.email || privateEmailsByUid[u.uid],
          friends: myFriends,
          friendRequestsSent: myReqSent,
          friendRequestsReceived: myReqReceived,
          following: myFollowing,
          followers: myFollowers,
        };
      }
      return {
        ...u,
        isOnline: mergedOnline,
        lastSeenAt: mergedLastSeen,
        email: privateEmailsByUid[u.uid],
      };
    });
  }, [
    rawUsers,
    ownUserDoc,
    firebaseUser,
    friendships,
    followingDocs,
    followerDocs,
    privateEmailsByUid,
    rtdbPresenceByUid,
  ]);

  useEffect(() => {
    usersRef.current = users;
  }, [users]);

  const currentUser = useMemo(
    () => (firebaseUser ? users.find((u) => u.uid === firebaseUser.uid) ?? null : null),
    [users, firebaseUser]
  );

  const posts = useMemo(
    () =>
      basePosts.map((p) => ({
        ...p,
        likedByMe: Boolean(likedPostIds[p.id]),
        comments: commentsByPost[p.id] ?? [],
      })),
    [basePosts, likedPostIds, commentsByPost]
  );

  const locations = useMemo(
    () => (rawFirestoreLocations.length > 0 ? rawFirestoreLocations : OFFICIAL_LOCATIONS),
    [rawFirestoreLocations]
  );

  const attractions = useMemo(
    () => (rawFirestoreAttractions.length > 0 ? rawFirestoreAttractions : OFFICIAL_ATTRACTIONS),
    [rawFirestoreAttractions]
  );

  const locationsSyncedToFirestore =
    rawFirestoreLocations.length > 0 && rawFirestoreAttractions.length > 0;

  const adPackages = useMemo(
    () => (rawFirestoreAdPackages.length > 0 ? rawFirestoreAdPackages : DEFAULT_AD_PACKAGES),
    [rawFirestoreAdPackages]
  );

  const adPackagesSyncedToFirestore = rawFirestoreAdPackages.length > 0;

  const localAds = useMemo(() => {
    const source =
      isAdmin && adminVerified ? rawAdminLocalAds : [...rawLiveLocalAds, ...rawMyLocalAds];
    const map = new Map<string, LocalAd>();
    for (const ad of source) {
      map.set(ad.id, ad);
    }
    return Array.from(map.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [isAdmin, adminVerified, rawAdminLocalAds, rawLiveLocalAds, rawMyLocalAds]);

  const activeLocalAds = useMemo(() => {
    if (!monetizationConfig.localAdsEnabled) return [];
    const nowMs = Date.now();
    return localAds.filter((ad) => {
      if (ad.status !== 'approved' || ad.paymentStatus !== 'paid') return false;
      if (hiddenAdIds.includes(ad.id)) return false;
      if (ad.endsAt && new Date(ad.endsAt).getTime() < nowMs) return false;
      return true;
    });
  }, [localAds, monetizationConfig.localAdsEnabled, hiddenAdIds]);

  const myLocalAds = useMemo(
    () =>
      firebaseUser
        ? localAds.filter((ad) => ad.advertiserUid === firebaseUser.uid)
        : [],
    [localAds, firebaseUser]
  );

  const conversations = useMemo(
    () =>
      rawConversations.map((c) => ({
        ...c,
        messages: messagesByConv[c.id] ?? [],
      })),
    [rawConversations, messagesByConv]
  );

  const blockedByMeIds = useMemo(() => blocksByMe.map((b) => b.blockedId), [blocksByMe]);
  const blockedMeIds = useMemo(() => blocksAgainstMe.map((b) => b.blockerId), [blocksAgainstMe]);

  const isBlockedBetween = useCallback(
    (otherUid: string) => {
      const blockedByMe = blockedByMeIds.includes(otherUid);
      const blockedByOther = blockedMeIds.includes(otherUid);
      return {
        blockedByMe,
        blockedByOther,
        anyBlocked: blockedByMe || blockedByOther,
      };
    },
    [blockedByMeIds, blockedMeIds]
  );

  const isPartnerTyping = useCallback(
    (conversationId: string, partnerId: string) => {
      void typingTick;
      if (activeConvIdRef.current === conversationId && rtdbPartnerTyping) {
        return true;
      }
      const conv = rawConversations.find((c) => c.id === conversationId);
      const ts = conv?.typing?.[partnerId];
      return typeof ts === 'number' && ts > 0 && Date.now() - ts < 7000;
    },
    [rawConversations, rtdbPartnerTyping, typingTick]
  );

  const notifications = useMemo(() => {
    const merged = [
      ...directNotifications,
      ...broadcastNotifications.map((b) => ({
        ...b,
        read: readBroadcastIds.includes(b.id),
      })),
    ];
    return merged.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [directNotifications, broadcastNotifications, readBroadcastIds]);

  const unreadNotificationsCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications]
  );

  const unreadMessagesCount = useMemo(() => {
    if (!firebaseUser) return 0;
    return conversations.reduce((sum, conv) => {
      const count = conv.unreadCounts?.[firebaseUser.uid];
      if (typeof count === 'number' && count >= 0) return sum + count;
      return sum + (conv.unreadBy.includes(firebaseUser.uid) ? 1 : 0);
    }, 0);
  }, [conversations, firebaseUser]);

  // Reflect unread messages count in document title
  useEffect(() => {
    const total = unreadMessagesCount;
    document.title = total > 0 ? `(${total}) Sylhet Social` : 'Sylhet Social';
  }, [unreadMessagesCount]);

  const getUserById = useCallback(
    (id: string) => users.find((u) => u.uid === id || u.id === id),
    [users]
  );

  const openProfile = (userId: string) => {
    setViewedProfileId(userId);
    setActiveTab('profile');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToSearch = (q: string) => {
    setSearchQuery(q);
    setActiveTab('search');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const prefillComposerWithLocation = (loc: { en: string; bn: string } | null) => {
    setComposerLocationPrefill(loc);
    if (loc) {
      setActiveTab('feed');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const signInWithGoogle = async (): Promise<boolean> => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
      setAuthModalOpen(false);
      return true;
    } catch (err) {
      console.error('Google Sign-In error:', err);
      setAuthError(t.auth.authError);
      return false;
    }
  };

  const verifyAdminSession = async (): Promise<boolean> => {
    if (!auth.currentUser || !isAdmin) return false;
    try {
      await reauthenticateWithPopup(auth.currentUser, googleProvider);
      setAdminVerified(true);
      return true;
    } catch (err) {
      console.error('Admin re-authentication error:', err);
      return false;
    }
  };

  const lockAdminConsole = () => {
    setAdminVerified(false);
    setActiveTab('feed');
  };

  const logout = async () => {
    if (firebaseUser) {
      await updateDoc(doc(db, 'users_public', firebaseUser.uid), {
        isOnline: false,
        lastSeenAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }).catch(() => {});
    }
    await signOut(auth);
    setActiveConversationId(null);
    setActiveTabState('feed');
  };

  const updateProfile = async (
    updates: Partial<
      Pick<
        UserProfile,
        'name' | 'bio' | 'location' | 'locationBn' | 'workOrStudy' | 'avatarUrl' | 'coverUrl'
      >
    >
  ) => {
    if (!firebaseUser) return;
    const path = `users_public/${firebaseUser.uid}`;
    try {
      const payload: Record<string, unknown> = { updatedAt: serverTimestamp() };
      if (updates.name !== undefined) {
        const clean = updates.name.trim().slice(0, 80) || 'Sylhet Member';
        payload.name = clean;
        payload.nameBn = clean;
      }
      if (updates.bio !== undefined) {
        const clean = updates.bio.trim().slice(0, 400);
        payload.bio = clean;
        payload.bioBn = clean;
      }
      if (updates.location !== undefined) {
        const clean = updates.location.trim().slice(0, 120);
        payload.location = clean;
        payload.locationBn = updates.locationBn
          ? updates.locationBn.trim().slice(0, 120)
          : clean;
      }
      if (updates.workOrStudy !== undefined) {
        const clean = updates.workOrStudy.trim().slice(0, 140);
        payload.workOrStudy = clean;
        payload.workOrStudyBn = clean;
      }
      if (updates.avatarUrl !== undefined) {
        payload.avatarUrl = updates.avatarUrl.slice(0, 495000);
      }
      if (updates.coverUrl !== undefined) {
        payload.coverUrl = updates.coverUrl.slice(0, 495000);
      }
      await updateDoc(doc(db, 'users_public', firebaseUser.uid), payload);
      showToast(language === 'bn' ? 'প্রোফাইল আপডেট হয়েছে' : 'Profile updated');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  const createPost = async (input: CreatePostInput) => {
    if (!firebaseUser || !currentUser) {
      setAuthModalOpen(true);
      return;
    }
    if (currentUser.status === 'suspended') {
      showToast(t.feed.suspendedNotice);
      return;
    }
    if (appSettings.maintenanceMode && !isAdmin) {
      showToast(t.feed.maintenanceNotice);
      return;
    }

    const postId = `post_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const status: ModerationStatus =
      appSettings.requirePostReview && !isAdmin ? 'pending' : 'approved';
    const cleanText = input.text.trim().slice(0, 4000);

    const payload: Record<string, unknown> = {
      id: postId,
      authorId: firebaseUser.uid,
      mediaType: input.mediaType,
      text: cleanText,
      textBn: cleanText,
      moderationStatus: status,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    if (input.photoUrl) payload.photoUrl = input.photoUrl.slice(0, 595000);
    if (input.videoUrl) payload.videoUrl = input.videoUrl.slice(0, 595000);
    if (input.videoThumbnailUrl) payload.videoThumbnailUrl = input.videoThumbnailUrl.slice(0, 595000);
    if (input.videoDuration) payload.videoDuration = input.videoDuration.slice(0, 16);
    if (input.textCardTheme) payload.textCardTheme = input.textCardTheme;
    if (input.location) payload.location = input.location.slice(0, 120);
    if (input.locationBn) payload.locationBn = input.locationBn.slice(0, 120);

    try {
      await setDoc(doc(db, 'posts', postId), payload);
      showToast(
        status === 'pending'
          ? language === 'bn'
            ? 'পোস্টটি অ্যাডমিন অনুমোদনের জন্য পাঠানো হয়েছে'
            : 'Post submitted for admin review'
          : language === 'bn'
          ? 'পোস্ট প্রকাশিত হয়েছে'
          : 'Post published'
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `posts/${postId}`);
    }
  };

  const deleteOwnPost = async (postId: string) => {
    if (!firebaseUser) return;
    try {
      await deleteDoc(doc(db, 'posts', postId));
      showToast(language === 'bn' ? 'পোস্ট মুছে ফেলা হয়েছে' : 'Post deleted');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `posts/${postId}`);
    }
  };

  const toggleLike = async (postId: string) => {
    if (!firebaseUser) {
      setAuthModalOpen(true);
      return;
    }
    const post = posts.find((p) => p.id === postId);
    if (!post) return;
    const alreadyLiked = Boolean(post.likedByMe);

    try {
      const batch = writeBatch(db);
      const likeRef = doc(db, 'posts', postId, 'likes', firebaseUser.uid);
      const postRef = doc(db, 'posts', postId);

      if (alreadyLiked) {
        batch.delete(likeRef);
        batch.update(postRef, {
          likesCount: Math.max(0, post.likesCount - 1),
          updatedAt: serverTimestamp(),
        });
      } else {
        batch.set(likeRef, {
          userId: firebaseUser.uid,
          postId,
          createdAt: serverTimestamp(),
        });
        batch.update(postRef, {
          likesCount: post.likesCount + 1,
          updatedAt: serverTimestamp(),
        });
        if (post.authorId !== firebaseUser.uid) {
          const notifId = `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
          batch.set(doc(db, 'notifications', notifId), {
            id: notifId,
            type: 'like',
            actorId: firebaseUser.uid,
            targetUserId: post.authorId,
            postId,
            read: false,
            createdAt: serverTimestamp(),
          });
        }
      }
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `posts/${postId}/likes`);
    }
  };

  const addComment = async (postId: string, text: string) => {
    if (!firebaseUser) {
      setAuthModalOpen(true);
      return;
    }
    const clean = text.trim().slice(0, 1000);
    if (!clean) return;
    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    const commentId = `cmt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'posts', postId, 'comments', commentId), {
        id: commentId,
        postId,
        authorId: firebaseUser.uid,
        text: clean,
        createdAt: serverTimestamp(),
      });
      batch.update(doc(db, 'posts', postId), {
        commentsCount: post.commentsCount + 1,
        updatedAt: serverTimestamp(),
      });
      if (post.authorId !== firebaseUser.uid) {
        const notifId = `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
        batch.set(doc(db, 'notifications', notifId), {
          id: notifId,
          type: 'comment',
          actorId: firebaseUser.uid,
          targetUserId: post.authorId,
          postId,
          previewText: clean.slice(0, 80),
          read: false,
          createdAt: serverTimestamp(),
        });
      }
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `posts/${postId}/comments`);
    }
  };

  const sharePost = async (postId: string, note?: string) => {
    if (!firebaseUser) {
      setAuthModalOpen(true);
      return;
    }
    const original = posts.find((p) => p.id === postId);
    if (!original) return;
    const rootPostId = original.sharedPostId ?? original.id;
    const newPostId = `post_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const cleanNote = (note || '').trim().slice(0, 4000);

    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'posts', newPostId), {
        id: newPostId,
        authorId: firebaseUser.uid,
        mediaType: 'text',
        text: cleanNote,
        textBn: cleanNote,
        moderationStatus: appSettings.requirePostReview && !isAdmin ? 'pending' : 'approved',
        likesCount: 0,
        commentsCount: 0,
        sharesCount: 0,
        sharedPostId: rootPostId,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.update(doc(db, 'posts', original.id), {
        sharesCount: original.sharesCount + 1,
        updatedAt: serverTimestamp(),
      });
      if (original.authorId !== firebaseUser.uid) {
        const notifId = `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
        batch.set(doc(db, 'notifications', notifId), {
          id: notifId,
          type: 'share',
          actorId: firebaseUser.uid,
          targetUserId: original.authorId,
          postId: rootPostId,
          read: false,
          createdAt: serverTimestamp(),
        });
      }
      await batch.commit();
      showToast(language === 'bn' ? 'আপনার ফিডে শেয়ার করা হয়েছে' : 'Shared to your feed');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `posts/${newPostId}`);
    }
  };

  const toggleSavePost = async (postId: string) => {
    if (!firebaseUser) return;
    const exists = savedPostIds.includes(postId);
    const ref = doc(db, 'users_public', firebaseUser.uid, 'savedPosts', postId);
    try {
      if (exists) {
        await deleteDoc(ref);
      } else {
        await setDoc(ref, {
          postId,
          userId: firebaseUser.uid,
          createdAt: serverTimestamp(),
        });
      }
      showToast(exists ? t.actions.save : t.actions.saved);
    } catch (err) {
      handleFirestoreError(
        err,
        OperationType.WRITE,
        `users_public/${firebaseUser.uid}/savedPosts/${postId}`
      );
    }
  };

  const reportPost = async (
    postId: string,
    targetUserId: string,
    reason: ReportReason,
    details: string
  ) => {
    if (!firebaseUser) return;
    const reportId = `rep_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    try {
      await setDoc(doc(db, 'reports', reportId), {
        id: reportId,
        reporterId: firebaseUser.uid,
        targetType: 'post',
        targetPostId: postId,
        targetUserId,
        reason,
        details: details.trim().slice(0, 600),
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      showToast(t.reportModal.submitted);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `reports/${reportId}`);
    }
  };

  const reportUser = async (targetUserId: string, reason: ReportReason, details: string) => {
    if (!firebaseUser || targetUserId === firebaseUser.uid) return;
    const reportId = `rep_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    try {
      await setDoc(doc(db, 'reports', reportId), {
        id: reportId,
        reporterId: firebaseUser.uid,
        targetType: 'user',
        targetUserId,
        reason,
        details: details.trim().slice(0, 600),
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      showToast(t.reportModal.submitted);
    } catch (err) {
      console.error('Report user error:', err);
      showToast(
        language === 'bn' ? 'রিপোর্ট পাঠানো যায়নি, আবার চেষ্টা করুন' : 'Could not submit report.'
      );
    }
  };

  const blockUser = async (targetUserId: string) => {
    if (!firebaseUser || targetUserId === firebaseUser.uid) return;
    const blockId = `${firebaseUser.uid}_${targetUserId}`;
    try {
      await setDoc(doc(db, 'userBlocks', blockId), {
        id: blockId,
        blockerId: firebaseUser.uid,
        blockedId: targetUserId,
        createdAt: serverTimestamp(),
      });
      showToast(t.messagesPage.userBlockedToast);
    } catch (err) {
      console.error('Block user error:', err);
      setMessagingError(
        language === 'bn' ? 'ব্যবহারকারীকে ব্লক করা যায়নি।' : 'Failed to block user.'
      );
    }
  };

  const unblockUser = async (targetUserId: string) => {
    if (!firebaseUser || targetUserId === firebaseUser.uid) return;
    const blockId = `${firebaseUser.uid}_${targetUserId}`;
    try {
      await deleteDoc(doc(db, 'userBlocks', blockId));
      showToast(t.messagesPage.userUnblockedToast);
    } catch (err) {
      console.error('Unblock user error:', err);
      setMessagingError(
        language === 'bn' ? 'আনব্লক করা যায়নি।' : 'Failed to unblock user.'
      );
    }
  };

  const sendFriendRequest = async (targetUserId: string) => {
    if (!firebaseUser || targetUserId === firebaseUser.uid) return;
    const fId = makePairId(firebaseUser.uid, targetUserId);
    const sortedPair =
      firebaseUser.uid < targetUserId
        ? [firebaseUser.uid, targetUserId]
        : [targetUserId, firebaseUser.uid];
    const notifId = `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'friendships', fId), {
        id: fId,
        userIds: sortedPair,
        requesterId: firebaseUser.uid,
        recipientId: targetUserId,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(db, 'notifications', notifId), {
        id: notifId,
        type: 'friend_request',
        actorId: firebaseUser.uid,
        targetUserId,
        read: false,
        createdAt: serverTimestamp(),
      });
      await batch.commit();
      showToast(language === 'bn' ? 'বন্ধুত্বের অনুরোধ পাঠানো হয়েছে' : 'Friend request sent');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `friendships/${fId}`);
    }
  };

  const acceptFriendRequest = async (requesterId: string) => {
    if (!firebaseUser) return;
    const fId = makePairId(firebaseUser.uid, requesterId);
    const requester = getUserById(requesterId);
    const me = currentUser;
    const notifId = `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'friendships', fId), {
        status: 'accepted',
        updatedAt: serverTimestamp(),
      });
      if (me) {
        batch.update(doc(db, 'users_public', me.uid), {
          friendsCount: me.friendsCount + 1,
          updatedAt: serverTimestamp(),
        });
      }
      if (requester) {
        batch.update(doc(db, 'users_public', requester.uid), {
          friendsCount: requester.friendsCount + 1,
          updatedAt: serverTimestamp(),
        });
      }
      batch.set(doc(db, 'notifications', notifId), {
        id: notifId,
        type: 'friend_accept',
        actorId: firebaseUser.uid,
        targetUserId: requesterId,
        read: false,
        createdAt: serverTimestamp(),
      });
      await batch.commit();
      showToast(language === 'bn' ? 'বন্ধুত্বের অনুরোধ গৃহীত হয়েছে' : 'Friend request accepted');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `friendships/${fId}`);
    }
  };

  const declineFriendRequest = async (requesterId: string) => {
    if (!firebaseUser) return;
    const fId = makePairId(firebaseUser.uid, requesterId);
    try {
      await deleteDoc(doc(db, 'friendships', fId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `friendships/${fId}`);
    }
  };

  const removeFriend = async (targetUserId: string) => {
    if (!firebaseUser) return;
    const fId = makePairId(firebaseUser.uid, targetUserId);
    const target = getUserById(targetUserId);
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'friendships', fId));
      if (currentUser) {
        batch.update(doc(db, 'users_public', currentUser.uid), {
          friendsCount: Math.max(0, currentUser.friendsCount - 1),
          updatedAt: serverTimestamp(),
        });
      }
      if (target) {
        batch.update(doc(db, 'users_public', target.uid), {
          friendsCount: Math.max(0, target.friendsCount - 1),
          updatedAt: serverTimestamp(),
        });
      }
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `friendships/${fId}`);
    }
  };

  const toggleFollow = async (targetUserId: string) => {
    if (!firebaseUser || targetUserId === firebaseUser.uid) return;
    const followId = `${firebaseUser.uid}_${targetUserId}`;
    const isFollowing = followingDocs.some((f) => f.followingId === targetUserId);
    const target = getUserById(targetUserId);

    try {
      const batch = writeBatch(db);
      if (isFollowing) {
        batch.delete(doc(db, 'follows', followId));
        if (currentUser) {
          batch.update(doc(db, 'users_public', currentUser.uid), {
            followingCount: Math.max(0, currentUser.followingCount - 1),
            updatedAt: serverTimestamp(),
          });
        }
        if (target) {
          batch.update(doc(db, 'users_public', target.uid), {
            followersCount: Math.max(0, target.followersCount - 1),
            updatedAt: serverTimestamp(),
          });
        }
      } else {
        batch.set(doc(db, 'follows', followId), {
          id: followId,
          followerId: firebaseUser.uid,
          followingId: targetUserId,
          createdAt: serverTimestamp(),
        });
        if (currentUser) {
          batch.update(doc(db, 'users_public', currentUser.uid), {
            followingCount: currentUser.followingCount + 1,
            updatedAt: serverTimestamp(),
          });
        }
        if (target) {
          batch.update(doc(db, 'users_public', target.uid), {
            followersCount: target.followersCount + 1,
            updatedAt: serverTimestamp(),
          });
        }
        const notifId = `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
        batch.set(doc(db, 'notifications', notifId), {
          id: notifId,
          type: 'follow',
          actorId: firebaseUser.uid,
          targetUserId,
          read: false,
          createdAt: serverTimestamp(),
        });
      }
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `follows/${followId}`);
    }
  };

  const markNotificationRead = async (notifId: string) => {
    const target = notifications.find((n) => n.id === notifId);
    if (!target) return;
    if (target.targetUserId === 'all') {
      if (!readBroadcastIds.includes(notifId)) {
        const next = [...readBroadcastIds, notifId];
        setReadBroadcastIds(next);
        localStorage.setItem('sylhet_social_read_broadcasts', JSON.stringify(next));
      }
      return;
    }
    try {
      await updateDoc(doc(db, 'notifications', notifId), { read: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `notifications/${notifId}`);
    }
  };

  const markAllNotificationsRead = async () => {
    const unreadDirect = directNotifications.filter((n) => !n.read);
    const unreadBroadcasts = broadcastNotifications
      .filter((b) => !readBroadcastIds.includes(b.id))
      .map((b) => b.id);

    if (unreadBroadcasts.length > 0) {
      const next = Array.from(new Set([...readBroadcastIds, ...unreadBroadcasts]));
      setReadBroadcastIds(next);
      localStorage.setItem('sylhet_social_read_broadcasts', JSON.stringify(next));
    }

    if (unreadDirect.length === 0) return;
    try {
      const batch = writeBatch(db);
      for (const n of unreadDirect) {
        batch.update(doc(db, 'notifications', n.id), { read: true });
      }
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'notifications');
    }
  };

  const requestBrowserNotifications = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setBrowserNotificationPermission('unsupported');
      return;
    }
    try {
      const perm = await Notification.requestPermission();
      setBrowserNotificationPermission(perm);
    } catch {
      // Ignore permission prompt error
    }
  };

  const setTypingStatus = useCallback(
    (conversationId: string, isTyping: boolean) => {
      if (!firebaseUser) return;
      const uid = firebaseUser.uid;
      setRtdbTypingState(conversationId, uid, isTyping);

      const conv = rawConversations.find((c) => c.id === conversationId);
      if (!conv) return;

      const now = Date.now();
      const lastWrite = lastTypingFirestoreWriteRef.current[conversationId] ?? 0;

      if (isTyping) {
        if (now - lastWrite < 3000) return;
        lastTypingFirestoreWriteRef.current[conversationId] = now;
        updateDoc(doc(db, 'conversations', conversationId), {
          typing: { ...(conv.typing || {}), [uid]: now },
          updatedAt: serverTimestamp(),
        }).catch(() => {});
      } else if ((conv.typing?.[uid] ?? 0) > 0 || now - lastWrite < 10000) {
        lastTypingFirestoreWriteRef.current[conversationId] = 0;
        updateDoc(doc(db, 'conversations', conversationId), {
          typing: { ...(conv.typing || {}), [uid]: 0 },
          updatedAt: serverTimestamp(),
        }).catch(() => {});
      }
    },
    [firebaseUser, rawConversations]
  );

  const markConversationRead = useCallback(
    async (conversationId: string) => {
      if (!firebaseUser) return;
      const uid = firebaseUser.uid;
      const conv = rawConversations.find((c) => c.id === conversationId);
      const msgs = messagesByConv[conversationId] ?? [];
      const unseenMsgs = msgs.filter((m) => m.senderId !== uid && !m.seenBy.includes(uid));
      const needsConvReset =
        Boolean(conv) &&
        (conv!.unreadBy.includes(uid) || (conv!.unreadCounts?.[uid] ?? 0) > 0);

      if (unseenMsgs.length === 0 && !needsConvReset) return;

      try {
        const batch = writeBatch(db);
        if (conv && needsConvReset) {
          const nextCounts: Record<string, number> = { ...(conv.unreadCounts || {}), [uid]: 0 };
          batch.update(doc(db, 'conversations', conversationId), {
            unreadBy: conv.unreadBy.filter((id) => id !== uid),
            unreadCounts: nextCounts,
            updatedAt: serverTimestamp(),
          });
        }
        for (const m of unseenMsgs.slice(-25)) {
          const payload: Record<string, unknown> = {
            deliveredTo: arrayUnion(uid),
            seenBy: arrayUnion(uid),
          };
          if (!m.deliveredAt) payload.deliveredAt = serverTimestamp();
          if (!m.seenAt) payload.seenAt = serverTimestamp();
          batch.update(doc(db, 'conversations', conversationId, 'messages', m.id), payload);
        }
        await batch.commit();
      } catch (err) {
        console.warn('Mark read error:', err);
      }
    },
    [firebaseUser, rawConversations, messagesByConv]
  );

  const openChatWith = async (targetUserId: string) => {
    if (!firebaseUser || targetUserId === firebaseUser.uid) return;
    const convId = makePairId(firebaseUser.uid, targetUserId);
    const existing = rawConversations.find((c) => c.id === convId);
    const blockState = isBlockedBetween(targetUserId);

    if (existing) {
      setActiveConversationId(convId);
      setActiveTab('messages');
      await markConversationRead(convId);
      return;
    }

    if (blockState.anyBlocked) {
      showToast(
        blockState.blockedByMe
          ? t.messagesPage.blockedByYouBanner
          : t.messagesPage.blockedByOtherBanner
      );
      return;
    }

    const sortedPair =
      firebaseUser.uid < targetUserId
        ? [firebaseUser.uid, targetUserId]
        : [targetUserId, firebaseUser.uid];
    try {
      await setDoc(doc(db, 'conversations', convId), {
        id: convId,
        participantIds: sortedPair,
        lastMessageText: '',
        unreadBy: [],
        unreadCounts: { [firebaseUser.uid]: 0, [targetUserId]: 0 },
        typing: { [firebaseUser.uid]: 0, [targetUserId]: 0 },
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setActiveConversationId(convId);
      setActiveTab('messages');
      setMessagingError(null);
    } catch (err) {
      console.error('Open chat error:', err);
      setMessagingError(
        language === 'bn'
          ? 'নতুন কথোপকথন শুরু করা যায়নি।'
          : 'Unable to start conversation. Please check permissions.'
      );
    }
  };

  const sendMessage = async (conversationId: string, text: string): Promise<boolean> => {
    if (!firebaseUser) return false;
    if (currentUser?.status === 'suspended') {
      showToast(t.feed.suspendedNotice);
      return false;
    }
    const clean = text.trim().slice(0, 2000);
    if (!clean) return false;
    const conv = rawConversations.find((c) => c.id === conversationId);
    if (!conv) return false;
    const otherId = conv.participantIds.find((id) => id !== firebaseUser.uid) ?? firebaseUser.uid;
    const blockState = isBlockedBetween(otherId);
    if (blockState.anyBlocked) {
      showToast(
        blockState.blockedByMe
          ? t.messagesPage.blockedByYouBanner
          : t.messagesPage.blockedByOtherBanner
      );
      return false;
    }

    const msgId = `msg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const prevOtherUnread = conv.unreadCounts?.[otherId] ?? 0;

    try {
      setRtdbTypingState(conversationId, firebaseUser.uid, false);
      lastTypingFirestoreWriteRef.current[conversationId] = 0;

      const batch = writeBatch(db);
      batch.set(doc(db, 'conversations', conversationId, 'messages', msgId), {
        id: msgId,
        conversationId,
        participantIds: conv.participantIds,
        senderId: firebaseUser.uid,
        messageType: 'text',
        text: clean,
        deliveredTo: [firebaseUser.uid],
        seenBy: [firebaseUser.uid],
        createdAt: serverTimestamp(),
      });
      batch.update(doc(db, 'conversations', conversationId), {
        lastMessageText: clean.slice(0, 1000),
        lastMessageType: 'text',
        lastMessageSenderId: firebaseUser.uid,
        lastMessageAt: serverTimestamp(),
        unreadBy: otherId !== firebaseUser.uid ? [otherId] : [],
        unreadCounts: {
          [firebaseUser.uid]: 0,
          ...(otherId !== firebaseUser.uid ? { [otherId]: prevOtherUnread + 1 } : {}),
        },
        typing: {
          ...(conv.typing || {}),
          [firebaseUser.uid]: 0,
        },
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
      setMessagingError(null);
      return true;
    } catch (err) {
      console.error('Send message error:', err);
      const errMsg = err instanceof Error ? err.message : '';
      const isPerm = errMsg.toLowerCase().includes('permission');
      setMessagingError(
        isPerm
          ? language === 'bn'
            ? 'বার্তা পাঠানোর অনুমতি নেই (ব্লক বা সাসপেন্ড অবস্থা পরীক্ষা করুন)।'
            : 'Permission denied sending this message.'
          : language === 'bn'
          ? 'বার্তা পাঠানো যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করুন।'
          : 'Failed to send message. Please check your connection and try again.'
      );
      return false;
    }
  };

  const sendMediaMessage = async (
    conversationId: string,
    input: SendMediaMessageInput
  ): Promise<boolean> => {
    if (!firebaseUser) return false;
    if (currentUser?.status === 'suspended') {
      showToast(t.feed.suspendedNotice);
      return false;
    }
    const conv = rawConversations.find((c) => c.id === conversationId);
    if (!conv) return false;
    const otherId = conv.participantIds.find((id) => id !== firebaseUser.uid) ?? firebaseUser.uid;
    const blockState = isBlockedBetween(otherId);
    if (blockState.anyBlocked) {
      showToast(
        blockState.blockedByMe
          ? t.messagesPage.blockedByYouBanner
          : t.messagesPage.blockedByOtherBanner
      );
      return false;
    }

    const maxBytes = Math.min(25, Math.max(appSettings.maxUploadMb, 10)) * 1024 * 1024;
    if (input.file.size > maxBytes) {
      setMessagingError(t.messagesPage.fileTooLarge);
      showToast(t.messagesPage.fileTooLarge);
      return false;
    }

    const msgId = `msg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const cleanCaption = (input.caption || '').trim().slice(0, 2000);
    const previewFallback =
      input.mediaType === 'image'
        ? t.messagesPage.photoLabel
        : input.mediaType === 'video'
        ? t.messagesPage.videoLabel
        : t.messagesPage.voiceMessage;
    const prevOtherUnread = conv.unreadCounts?.[otherId] ?? 0;

    try {
      const uploaded = await uploadChatMediaFile(
        conversationId,
        msgId,
        input.file,
        input.fileName,
        input.onProgress
      );

      setRtdbTypingState(conversationId, firebaseUser.uid, false);
      lastTypingFirestoreWriteRef.current[conversationId] = 0;

      const msgPayload: Record<string, unknown> = {
        id: msgId,
        conversationId,
        participantIds: conv.participantIds,
        senderId: firebaseUser.uid,
        messageType: input.mediaType,
        text: cleanCaption,
        mediaUrl: uploaded.url,
        mediaName: uploaded.name,
        mediaSize: uploaded.size,
        deliveredTo: [firebaseUser.uid],
        seenBy: [firebaseUser.uid],
        createdAt: serverTimestamp(),
      };
      if (typeof input.durationSec === 'number' && Number.isFinite(input.durationSec)) {
        msgPayload.mediaDurationSec = Math.max(0, Math.min(3600, Math.round(input.durationSec)));
      }

      const batch = writeBatch(db);
      batch.set(doc(db, 'conversations', conversationId, 'messages', msgId), msgPayload);
      batch.update(doc(db, 'conversations', conversationId), {
        lastMessageText: (cleanCaption || previewFallback).slice(0, 1000),
        lastMessageType: input.mediaType,
        lastMessageSenderId: firebaseUser.uid,
        lastMessageAt: serverTimestamp(),
        unreadBy: otherId !== firebaseUser.uid ? [otherId] : [],
        unreadCounts: {
          [firebaseUser.uid]: 0,
          ...(otherId !== firebaseUser.uid ? { [otherId]: prevOtherUnread + 1 } : {}),
        },
        typing: {
          ...(conv.typing || {}),
          [firebaseUser.uid]: 0,
        },
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
      setMessagingError(null);
      return true;
    } catch (err) {
      console.error('Media message upload/send error:', err);
      setMessagingError(t.messagesPage.uploadFailed);
      showToast(t.messagesPage.uploadFailed);
      return false;
    }
  };

  // -------------------------------------------------------------------------
  // Admin Operations (Strictly Protected by RBAC & Firestore Rules)
  // -------------------------------------------------------------------------
  const writeAuditLog = async (
    action: string,
    targetType: string,
    targetId: string,
    summary: string
  ) => {
    if (!firebaseUser || !isAdmin) return;
    const logId = `log_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    await setDoc(doc(db, 'auditLogs', logId), {
      id: logId,
      adminUid: firebaseUser.uid,
      adminEmail: firebaseUser.email || 'admin@sylhetsocial.bd',
      action: action.slice(0, 80),
      targetType: targetType.slice(0, 40),
      targetId: targetId.slice(0, 260),
      summary: summary.slice(0, 300),
      createdAt: serverTimestamp(),
    });
  };

  const adminUpdateUserRole = async (targetUid: string, role: UserRole) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      await updateDoc(doc(db, 'users_public', targetUid), {
        role,
        updatedAt: serverTimestamp(),
      });
      if (isBootstrappedAdmin) {
        const adminRef = doc(db, 'admins', targetUid);
        if (role === 'admin' || role === 'moderator') {
          const existingAdmin = await getDoc(adminRef);
          if (existingAdmin.exists()) {
            await updateDoc(adminRef, {
              role,
              grantedBy: firebaseUser.uid,
            });
          } else {
            await setDoc(adminRef, {
              uid: targetUid,
              email: privateEmailsByUid[targetUid] || `${targetUid}@sylhetsocial.bd`,
              role,
              grantedBy: firebaseUser.uid,
              createdAt: serverTimestamp(),
            });
          }
        } else if (targetUid !== firebaseUser.uid) {
          await deleteDoc(adminRef).catch(() => {});
        }
      }
      await writeAuditLog('update_user_role', 'user', targetUid, `Set role to ${role}`);
      showToast(`Role updated to ${role}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users_public/${targetUid}`);
    }
  };

  const adminUpdateUserStatus = async (targetUid: string, status: UserStatus) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      await updateDoc(doc(db, 'users_public', targetUid), {
        status,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('update_user_status', 'user', targetUid, `Set account status to ${status}`);
      showToast(`User ${status}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users_public/${targetUid}`);
    }
  };

  const adminModeratePost = async (postId: string, status: ModerationStatus, note?: string) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    const post = posts.find((p) => p.id === postId);
    try {
      const payload: Record<string, unknown> = {
        moderationStatus: status,
        updatedAt: serverTimestamp(),
      };
      if (note !== undefined) {
        payload.moderationNote = note.trim().slice(0, 300);
      }
      await updateDoc(doc(db, 'posts', postId), payload);
      if (post && post.authorId !== firebaseUser.uid && status === 'hidden') {
        const notifId = `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
        await setDoc(doc(db, 'notifications', notifId), {
          id: notifId,
          type: 'moderation',
          actorId: firebaseUser.uid,
          targetUserId: post.authorId,
          postId,
          previewText: (note || 'Your post was hidden by a moderator.').slice(0, 300),
          read: false,
          createdAt: serverTimestamp(),
        });
      }
      await writeAuditLog('moderate_post', 'post', postId, `Marked post as ${status}`);
      showToast(`Post ${status}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `posts/${postId}`);
    }
  };

  const adminDeletePost = async (postId: string) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      await deleteDoc(doc(db, 'posts', postId));
      await writeAuditLog('delete_post', 'post', postId, 'Permanently deleted post');
      showToast('Post deleted');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `posts/${postId}`);
    }
  };

  const adminResolveReport = async (
    reportId: string,
    status: ReportStatus,
    resolutionNote: string,
    hideTargetPost = false,
    suspendTargetUser = false
  ) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    const report = reports.find((r) => r.id === reportId);
    try {
      await updateDoc(doc(db, 'reports', reportId), {
        status,
        reviewedBy: firebaseUser.uid,
        resolutionNote: resolutionNote.trim().slice(0, 400),
        updatedAt: serverTimestamp(),
      });
      if (hideTargetPost && report?.targetPostId) {
        await updateDoc(doc(db, 'posts', report.targetPostId), {
          moderationStatus: 'hidden',
          moderationNote: resolutionNote.trim().slice(0, 300) || 'Hidden after report review',
          updatedAt: serverTimestamp(),
        });
      }
      if (suspendTargetUser && report?.targetUserId && report.targetUserId !== firebaseUser.uid) {
        await updateDoc(doc(db, 'users_public', report.targetUserId), {
          status: 'suspended',
          updatedAt: serverTimestamp(),
        });
      }
      await writeAuditLog(
        'resolve_report',
        'report',
        reportId,
        `Report marked ${status}${hideTargetPost ? ' (target post hidden)' : ''}${
          suspendTargetUser ? ' (target user suspended)' : ''
        }`
      );
      showToast(`Report ${status}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `reports/${reportId}`);
    }
  };

  const adminSendBroadcast = async (title: string, message: string) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    const notifId = `bcast_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    try {
      await setDoc(doc(db, 'notifications', notifId), {
        id: notifId,
        type: 'admin_broadcast',
        actorId: firebaseUser.uid,
        targetUserId: 'all',
        title: title.trim().slice(0, 160),
        previewText: message.trim().slice(0, 300),
        read: false,
        createdAt: serverTimestamp(),
      });
      await writeAuditLog('send_broadcast', 'notification', notifId, title.trim().slice(0, 120));
      showToast(t.admin.broadcast.sentSuccess);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `notifications/${notifId}`);
    }
  };

  const adminSaveAppSettings = async (
    next: Omit<AppSettings, 'updatedBy' | 'updatedAt'>
  ) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      await setDoc(doc(db, 'appSettings', 'global'), {
        siteName: next.siteName.trim().slice(0, 60) || 'Sylhet Social',
        maintenanceMode: Boolean(next.maintenanceMode),
        allowRegistrations: Boolean(next.allowRegistrations),
        requirePostReview: Boolean(next.requirePostReview),
        maxUploadMb: Math.min(100, Math.max(1, Number(next.maxUploadMb) || 5)),
        featuredBannerEn: next.featuredBannerEn.trim().slice(0, 240),
        featuredBannerBn: next.featuredBannerBn.trim().slice(0, 240),
        updatedBy: firebaseUser.uid,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog(
        'update_app_settings',
        'appSettings',
        'global',
        `Maintenance=${next.maintenanceMode}, PostReview=${next.requirePostReview}`
      );
      showToast(language === 'bn' ? 'অ্যাপ সেটিংস সংরক্ষিত হয়েছে' : 'App settings saved');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'appSettings/global');
    }
  };

  const adminSeedStarterPosts = async () => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      const batch = writeBatch(db);
      for (let i = 0; i < STARTER_POST_TEMPLATES.length; i += 1) {
        const tpl = STARTER_POST_TEMPLATES[i];
        const postId = `starter_${Date.now()}_${i}`;
        const payload: Record<string, unknown> = {
          id: postId,
          authorId: firebaseUser.uid,
          mediaType: tpl.mediaType,
          text: tpl.text,
          textBn: tpl.textBn,
          location: tpl.location,
          locationBn: tpl.locationBn,
          moderationStatus: 'approved',
          likesCount: 0,
          commentsCount: 0,
          sharesCount: 0,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        };
        if (tpl.photoUrl) payload.photoUrl = tpl.photoUrl;
        if (tpl.videoThumbnailUrl) payload.videoThumbnailUrl = tpl.videoThumbnailUrl;
        if (tpl.videoDuration) payload.videoDuration = tpl.videoDuration;
        if (tpl.textCardTheme) payload.textCardTheme = tpl.textCardTheme;
        batch.set(doc(db, 'posts', postId), payload);
      }
      await batch.commit();
      await writeAuditLog('seed_starter_posts', 'posts', 'batch', 'Published 4 Sylhet showcase posts');
      showToast(language === 'bn' ? 'স্টার্টার পোস্ট প্রকাশিত হয়েছে' : 'Sylhet starter posts published');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'posts');
    }
  };

  const buildLocationPayload = (node: {
    id: string;
    level: LocationLevel;
    name: string;
    nameBn: string;
    parentId?: string;
    divisionId?: string;
    districtId?: string;
    upazilaId?: string;
    unionId?: string;
    isActive: boolean;
    sortOrder: number;
  }) => ({
    id: node.id,
    level: node.level,
    name: node.name.trim().slice(0, 100),
    nameBn: (node.nameBn.trim() || node.name.trim()).slice(0, 120),
    parentId: (node.parentId || '').slice(0, 128),
    divisionId: (node.divisionId || '').slice(0, 128),
    districtId: (node.districtId || '').slice(0, 128),
    upazilaId: (node.upazilaId || '').slice(0, 128),
    unionId: (node.unionId || '').slice(0, 128),
    isActive: Boolean(node.isActive),
    sortOrder: Math.max(0, Math.min(100000, Number(node.sortOrder) || 0)),
  });

  const buildAttractionPayload = (item: {
    id: string;
    name: string;
    nameBn: string;
    category: AttractionCategory;
    divisionId?: string;
    districtId: string;
    districtName: string;
    districtNameBn?: string;
    upazilaId: string;
    upazilaName: string;
    upazilaNameBn?: string;
    unionId?: string;
    unionName?: string;
    unionNameBn?: string;
    villageName?: string;
    villageNameBn?: string;
    locationSummary: string;
    locationSummaryBn: string;
    description?: string;
    descriptionBn?: string;
    imageUrl?: string;
    isFeatured: boolean;
    isActive: boolean;
  }) => ({
    id: item.id,
    name: item.name.trim().slice(0, 120),
    nameBn: (item.nameBn.trim() || item.name.trim()).slice(0, 140),
    category: item.category,
    divisionId: (item.divisionId || 'div_sylhet').slice(0, 128),
    districtId: item.districtId.slice(0, 128),
    districtName: item.districtName.trim().slice(0, 100),
    districtNameBn: (item.districtNameBn || item.districtName).trim().slice(0, 120),
    upazilaId: item.upazilaId.slice(0, 128),
    upazilaName: item.upazilaName.trim().slice(0, 100),
    upazilaNameBn: (item.upazilaNameBn || item.upazilaName).trim().slice(0, 120),
    unionId: (item.unionId || '').slice(0, 128),
    unionName: (item.unionName || '').trim().slice(0, 100),
    unionNameBn: (item.unionNameBn || '').trim().slice(0, 120),
    villageName: (item.villageName || '').trim().slice(0, 120),
    villageNameBn: (item.villageNameBn || '').trim().slice(0, 120),
    locationSummary: item.locationSummary.trim().slice(0, 160),
    locationSummaryBn: (item.locationSummaryBn.trim() || item.locationSummary.trim()).slice(0, 160),
    description: (item.description || '').trim().slice(0, 600),
    descriptionBn: (item.descriptionBn || '').trim().slice(0, 600),
    imageUrl: (item.imageUrl || '').slice(0, 495000),
    isFeatured: Boolean(item.isFeatured),
    isActive: Boolean(item.isActive),
  });

  const seedOfficialDirectory = async (
    excludeLocationId?: string,
    excludeAttractionId?: string
  ) => {
    const items: Array<{ col: 'locations' | 'attractions'; id: string; data: Record<string, unknown> }> = [
      ...OFFICIAL_LOCATIONS.filter((l) => l.id !== excludeLocationId).map((l) => ({
        col: 'locations' as const,
        id: l.id,
        data: {
          ...buildLocationPayload(l),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        },
      })),
      ...OFFICIAL_ATTRACTIONS.filter((a) => a.id !== excludeAttractionId).map((a) => ({
        col: 'attractions' as const,
        id: a.id,
        data: {
          ...buildAttractionPayload(a),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        },
      })),
    ];

    for (let i = 0; i < items.length; i += 350) {
      const batch = writeBatch(db);
      for (const entry of items.slice(i, i + 350)) {
        batch.set(doc(db, entry.col, entry.id), entry.data);
      }
      await batch.commit();
    }
  };

  const adminSeedLocationsAndAttractions = async () => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      await seedOfficialDirectory();
      await writeAuditLog(
        'seed_locations_attractions',
        'locations',
        'moulvibazar_official',
        'Synced all 7 Moulvibazar upazilas, unions, villages & 10 attractions'
      );
      showToast(t.admin.locations.seededToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'locations');
    }
  };

  const adminSaveLocationNode = async (input: {
    id?: string;
    level: LocationLevel;
    name: string;
    nameBn: string;
    parentId?: string;
    divisionId?: string;
    districtId?: string;
    upazilaId?: string;
    unionId?: string;
    isActive: boolean;
    sortOrder: number;
  }) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    if (!input.name.trim()) return;
    if (rawFirestoreLocations.length === 0) {
      await seedOfficialDirectory();
    }
    const prefixMap: Record<LocationLevel, string> = {
      division: 'div',
      district: 'dist',
      upazila: 'upa',
      union: 'uni',
      village: 'vil',
    };
    const locId = input.id || sanitizeDocId(input.name, prefixMap[input.level]);
    try {
      const ref = doc(db, 'locations', locId);
      const existingSnap = await getDoc(ref);
      const payload = buildLocationPayload({ ...input, id: locId });
      if (existingSnap.exists()) {
        await updateDoc(ref, {
          ...payload,
          updatedAt: serverTimestamp(),
        });
        await writeAuditLog('update_location', 'location', locId, `Updated ${input.level}: ${input.name}`);
      } else {
        await setDoc(ref, {
          ...payload,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        await writeAuditLog('create_location', 'location', locId, `Created ${input.level}: ${input.name}`);
      }
      showToast(t.admin.locations.savedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `locations/${locId}`);
    }
  };

  const adminDeleteLocationNode = async (locationId: string) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      if (rawFirestoreLocations.length === 0) {
        await seedOfficialDirectory(locationId, undefined);
      } else {
        await deleteDoc(doc(db, 'locations', locationId));
      }
      await writeAuditLog('delete_location', 'location', locationId, `Deleted location node ${locationId}`);
      showToast(t.admin.locations.deletedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `locations/${locationId}`);
    }
  };

  const adminSaveAttraction = async (input: {
    id?: string;
    name: string;
    nameBn: string;
    category: AttractionCategory;
    divisionId?: string;
    districtId: string;
    districtName: string;
    districtNameBn?: string;
    upazilaId: string;
    upazilaName: string;
    upazilaNameBn?: string;
    unionId?: string;
    unionName?: string;
    unionNameBn?: string;
    villageName?: string;
    villageNameBn?: string;
    locationSummary: string;
    locationSummaryBn: string;
    description?: string;
    descriptionBn?: string;
    imageUrl?: string;
    isFeatured: boolean;
    isActive: boolean;
  }) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    if (!input.name.trim() || !input.districtId || !input.upazilaId) return;
    if (rawFirestoreAttractions.length === 0) {
      await seedOfficialDirectory();
    }
    const attrId = input.id || sanitizeDocId(input.name, 'attr');
    try {
      const ref = doc(db, 'attractions', attrId);
      const existingSnap = await getDoc(ref);
      const payload = buildAttractionPayload({ ...input, id: attrId });
      if (existingSnap.exists()) {
        await updateDoc(ref, {
          ...payload,
          updatedAt: serverTimestamp(),
        });
        await writeAuditLog('update_attraction', 'attraction', attrId, `Updated attraction: ${input.name}`);
      } else {
        await setDoc(ref, {
          ...payload,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        await writeAuditLog('create_attraction', 'attraction', attrId, `Created attraction: ${input.name}`);
      }
      showToast(t.admin.locations.savedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `attractions/${attrId}`);
    }
  };

  const adminDeleteAttraction = async (attractionId: string) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      if (rawFirestoreAttractions.length === 0) {
        await seedOfficialDirectory(undefined, attractionId);
      } else {
        await deleteDoc(doc(db, 'attractions', attractionId));
      }
      await writeAuditLog('delete_attraction', 'attraction', attractionId, `Deleted attraction ${attractionId}`);
      showToast(t.admin.locations.deletedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `attractions/${attractionId}`);
    }
  };

  // -------------------------------------------------------------------------
  // Monetization, Local Business Ads & Privacy Consent Actions
  // -------------------------------------------------------------------------
  const updateAdConsent = async (status: AdConsentStatus) => {
    setAdConsentStatus(status);
    if (status === 'unset') {
      localStorage.removeItem('sylhet_social_ad_consent');
    } else {
      localStorage.setItem('sylhet_social_ad_consent', status);
    }
    window.SylhetSocialAdMob?.syncConsentStatus?.(status);
    if (firebaseUser) {
      try {
        await updateDoc(doc(db, 'users_private', firebaseUser.uid), {
          adConsentStatus: status,
          adConsentUpdatedAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch {
        // Fallback already persisted in localStorage
      }
    }
    showToast(t.consent.savedToast);
  };

  const hideAdForSession = (adId: string) => {
    setHiddenAdIds((prev) => (prev.includes(adId) ? prev : [...prev, adId]));
    showToast(t.sponsoredCard.adHiddenToast);
  };

  const submitLocalAd = async (input: SubmitLocalAdInput): Promise<boolean> => {
    if (!firebaseUser || !currentUser) {
      setAuthModalOpen(true);
      return false;
    }
    if (currentUser.status === 'suspended') {
      showToast(t.feed.suspendedNotice);
      return false;
    }
    const chosenPackage = rawFirestoreAdPackages.find(
      (p) => p.id === input.packageId && p.isActive
    );
    if (!chosenPackage) {
      showToast(
        language === 'bn'
          ? 'বিজ্ঞাপন প্যাকেজ ডাটাবেসে সক্রিয় করা হয়নি। অনুগ্রহ করে অ্যাডমিন প্যানেল থেকে প্যাকেজ সিঙ্ক করুন।'
          : 'Selected package is not synced in Firestore yet. Ask an admin to sync ad packages.'
      );
      return false;
    }

    const adId = `ad_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const payload: Record<string, unknown> = {
      id: adId,
      advertiserUid: firebaseUser.uid,
      businessName: input.businessName.trim().slice(0, 100),
      category: input.category,
      title: input.title.trim().slice(0, 140),
      description: input.description.trim().slice(0, 600),
      contactPhone: input.contactPhone.trim().slice(0, 40),
      ctaLabel: input.ctaLabel,
      location: input.location.trim().slice(0, 120),
      packageId: chosenPackage.id,
      packageName: chosenPackage.name.slice(0, 100),
      placement: chosenPackage.placement,
      durationDays: chosenPackage.durationDays,
      priceBdt: chosenPackage.priceBdt,
      status: 'pending_review',
      paymentStatus: 'unpaid',
      paymentMethod: 'none',
      impressionsCount: 0,
      clicksCount: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    if (input.titleBn?.trim()) payload.titleBn = input.titleBn.trim().slice(0, 160);
    if (input.descriptionBn?.trim()) payload.descriptionBn = input.descriptionBn.trim().slice(0, 600);
    if (input.imageUrl?.trim()) payload.imageUrl = input.imageUrl.trim().slice(0, 540000);
    if (input.whatsappNumber?.trim()) payload.whatsappNumber = input.whatsappNumber.trim().slice(0, 40);
    if (input.contactEmail?.trim()) payload.contactEmail = input.contactEmail.trim().slice(0, 160);
    if (input.websiteUrl?.trim()) payload.websiteUrl = input.websiteUrl.trim().slice(0, 300);
    if (input.locationBn?.trim()) payload.locationBn = input.locationBn.trim().slice(0, 120);
    if (input.districtId?.trim()) payload.districtId = input.districtId.trim().slice(0, 128);
    if (input.upazilaId?.trim()) payload.upazilaId = input.upazilaId.trim().slice(0, 128);

    try {
      await setDoc(doc(db, 'localAds', adId), payload);
      showToast(t.ads.submittedToast);
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `localAds/${adId}`);
      return false;
    }
  };

  const submitAdPaymentReference = async (
    adId: string,
    paymentMethod: AdPaymentMethod,
    paymentReference: string
  ): Promise<boolean> => {
    if (!firebaseUser) return false;
    const cleanRef = paymentReference.trim().slice(0, 120);
    if (cleanRef.length < 3) return false;
    try {
      await updateDoc(doc(db, 'localAds', adId), {
        paymentMethod,
        paymentReference: cleanRef,
        paymentStatus: 'pending_verification',
        updatedAt: serverTimestamp(),
      });
      showToast(t.ads.proofSubmittedToast);
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `localAds/${adId}`);
      return false;
    }
  };

  const pauseOwnAd = async (adId: string) => {
    if (!firebaseUser) return;
    try {
      await updateDoc(doc(db, 'localAds', adId), {
        status: 'paused',
        updatedAt: serverTimestamp(),
      });
      showToast(t.admin.monetization.statusUpdatedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `localAds/${adId}`);
    }
  };

  const deleteOwnUnpaidAd = async (adId: string) => {
    if (!firebaseUser) return;
    try {
      await deleteDoc(doc(db, 'localAds', adId));
      showToast(language === 'bn' ? 'বিজ্ঞাপনটি সরানো হয়েছে' : 'Ad request removed');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `localAds/${adId}`);
    }
  };

  const trackAdImpression = (adId: string) => {
    if (!firebaseUser || trackedAdImpressionsRef.current.has(adId)) return;
    trackedAdImpressionsRef.current.add(adId);
    updateDoc(doc(db, 'localAds', adId), {
      impressionsCount: increment(1),
      updatedAt: serverTimestamp(),
    }).catch(() => {});
  };

  const trackAdClick = (adId: string) => {
    if (!firebaseUser) return;
    updateDoc(doc(db, 'localAds', adId), {
      clicksCount: increment(1),
      updatedAt: serverTimestamp(),
    }).catch(() => {});
  };

  const adminSeedMonetizationDefaults = async () => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      const batch = writeBatch(db);
      for (const pkg of DEFAULT_AD_PACKAGES) {
        batch.set(doc(db, 'adPackages', pkg.id), {
          id: pkg.id,
          name: pkg.name,
          nameBn: pkg.nameBn,
          description: pkg.description || '',
          descriptionBn: pkg.descriptionBn || '',
          durationDays: pkg.durationDays,
          priceBdt: pkg.priceBdt,
          placement: pkg.placement,
          isActive: pkg.isActive,
          sortOrder: pkg.sortOrder,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      batch.set(doc(db, 'monetizationConfig', 'global'), {
        admobEnvironment: monetizationConfig.admobEnvironment,
        admobBannerEnabled: monetizationConfig.admobBannerEnabled,
        admobNativeEnabled: monetizationConfig.admobNativeEnabled,
        localAdsEnabled: monetizationConfig.localAdsEnabled,
        feedAdInterval: monetizationConfig.feedAdInterval,
        requireAdConsent: monetizationConfig.requireAdConsent,
        manualPaymentInstructionsEn: monetizationConfig.manualPaymentInstructionsEn,
        manualPaymentInstructionsBn: monetizationConfig.manualPaymentInstructionsBn,
        updatedBy: firebaseUser.uid,
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
      await writeAuditLog(
        'seed_monetization_defaults',
        'adPackages',
        'default_tiers',
        'Synced default Sylhet local ad pricing packages and AdMob test configuration'
      );
      showToast(t.admin.monetization.configSavedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'adPackages');
    }
  };

  const adminSaveAdPackage = async (input: {
    id?: string;
    name: string;
    nameBn: string;
    description?: string;
    descriptionBn?: string;
    durationDays: number;
    priceBdt: number;
    placement: AdPlacement;
    isActive: boolean;
    sortOrder: number;
  }) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    const pkgId = input.id || sanitizeDocId(input.name, 'pkg');
    try {
      const ref = doc(db, 'adPackages', pkgId);
      const snap = await getDoc(ref);
      const payload = {
        id: pkgId,
        name: input.name.trim().slice(0, 80),
        nameBn: (input.nameBn.trim() || input.name.trim()).slice(0, 100),
        description: (input.description || '').trim().slice(0, 300),
        descriptionBn: (input.descriptionBn || '').trim().slice(0, 300),
        durationDays: Math.min(365, Math.max(1, Number(input.durationDays) || 7)),
        priceBdt: Math.min(500000, Math.max(0, Number(input.priceBdt) || 0)),
        placement: input.placement,
        isActive: Boolean(input.isActive),
        sortOrder: Math.min(1000, Math.max(0, Number(input.sortOrder) || 1)),
        updatedAt: serverTimestamp(),
      };
      if (snap.exists()) {
        await updateDoc(ref, payload);
        await writeAuditLog('update_ad_package', 'adPackage', pkgId, `Updated package ${payload.name} (BDT ${payload.priceBdt})`);
      } else {
        await setDoc(ref, { ...payload, createdAt: serverTimestamp() });
        await writeAuditLog('create_ad_package', 'adPackage', pkgId, `Created package ${payload.name} (BDT ${payload.priceBdt})`);
      }
      showToast(t.admin.locations.savedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `adPackages/${pkgId}`);
    }
  };

  const adminDeleteAdPackage = async (packageId: string) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      await deleteDoc(doc(db, 'adPackages', packageId));
      await writeAuditLog('delete_ad_package', 'adPackage', packageId, `Deleted ad package ${packageId}`);
      showToast(t.admin.locations.deletedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `adPackages/${packageId}`);
    }
  };

  const adminUpdateAdModeration = async (
    adId: string,
    nextStatus: AdStatus,
    adminNote?: string
  ) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    const targetAd = localAds.find((a) => a.id === adId);
    try {
      const payload: Record<string, unknown> = {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      };
      if (adminNote !== undefined) {
        payload.adminNote = adminNote.trim().slice(0, 400);
      }
      if (nextStatus === 'approved' && targetAd && !targetAd.startsAt) {
        const start = new Date();
        const end = new Date(start.getTime() + targetAd.durationDays * 86400000);
        payload.startsAt = Timestamp.fromDate(start);
        payload.endsAt = Timestamp.fromDate(end);
      }
      await updateDoc(doc(db, 'localAds', adId), payload);
      await writeAuditLog(
        'moderate_local_ad',
        'localAd',
        adId,
        `Updated ad status for "${targetAd?.businessName || adId}" to ${nextStatus}`
      );
      showToast(t.admin.monetization.statusUpdatedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `localAds/${adId}`);
    }
  };

  const adminConfirmAdPayment = async (
    adId: string,
    paymentStatus: AdPaymentStatus,
    paymentMethod?: AdPaymentMethod,
    adminNote?: string
  ) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    const targetAd = localAds.find((a) => a.id === adId);
    try {
      const payload: Record<string, unknown> = {
        paymentStatus,
        updatedAt: serverTimestamp(),
      };
      if (paymentMethod) {
        payload.paymentMethod = paymentMethod;
      }
      if (adminNote !== undefined && adminNote.trim()) {
        payload.adminNote = adminNote.trim().slice(0, 400);
      }
      if (paymentStatus === 'paid') {
        payload.paymentConfirmedBy = firebaseUser.uid;
        payload.paymentConfirmedAt = serverTimestamp();
      }
      await updateDoc(doc(db, 'localAds', adId), payload);
      await writeAuditLog(
        'confirm_ad_payment',
        'localAd',
        adId,
        `Marked manual payment for "${targetAd?.businessName || adId}" (BDT ${targetAd?.priceBdt ?? 0}) as ${paymentStatus}`
      );
      showToast(t.admin.monetization.paymentConfirmedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `localAds/${adId}`);
    }
  };

  const adminDeleteLocalAd = async (adId: string) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      await deleteDoc(doc(db, 'localAds', adId));
      await writeAuditLog('delete_local_ad', 'localAd', adId, `Deleted local ad ${adId}`);
      showToast(t.admin.locations.deletedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `localAds/${adId}`);
    }
  };

  const adminSaveMonetizationConfig = async (
    next: Omit<MonetizationConfig, 'updatedBy' | 'updatedAt'>
  ) => {
    if (!firebaseUser || !isAdmin || !adminVerified) return;
    try {
      await setDoc(doc(db, 'monetizationConfig', 'global'), {
        admobEnvironment: next.admobEnvironment,
        admobBannerEnabled: Boolean(next.admobBannerEnabled),
        admobNativeEnabled: Boolean(next.admobNativeEnabled),
        localAdsEnabled: Boolean(next.localAdsEnabled),
        feedAdInterval: Math.min(20, Math.max(2, Number(next.feedAdInterval) || 4)),
        requireAdConsent: Boolean(next.requireAdConsent),
        manualPaymentInstructionsEn: next.manualPaymentInstructionsEn.trim().slice(0, 500),
        manualPaymentInstructionsBn: next.manualPaymentInstructionsBn.trim().slice(0, 500),
        updatedBy: firebaseUser.uid,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog(
        'update_monetization_config',
        'monetizationConfig',
        'global',
        `Updated AdMob (${next.admobEnvironment}) & feed interval (${next.feedAdInterval})`
      );
      showToast(t.admin.monetization.configSavedToast);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'monetizationConfig/global');
    }
  };

  return (
    <SocialContext.Provider
      value={{
        authReady,
        firebaseUser,
        authError,
        isOnlineNetwork,
        rtdbConnected,
        language,
        setLanguage,
        t,
        theme,
        toggleTheme,
        currentUser,
        isAdmin,
        isBootstrappedAdmin,
        adminRole,
        adminVerified,
        verifyAdminSession,
        lockAdminConsole,
        users,
        privateEmailsByUid,
        adminRecords,
        posts,
        savedPostIds,
        notifications,
        unreadNotificationsCount,
        conversations,
        unreadMessagesCount,
        messagesLoading,
        messagingError,
        clearMessagingError,
        chatAlert,
        dismissChatAlert,
        browserNotificationPermission,
        requestBrowserNotifications,
        blockedByMeIds,
        blockedMeIds,
        isBlockedBetween,
        isPartnerTyping,
        reports,
        auditLogs,
        appSettings,
        activeTab,
        setActiveTab,
        viewedProfileId,
        openProfile,
        searchQuery,
        setSearchQuery,
        navigateToSearch,
        activeConversationId,
        setActiveConversationId,
        openChatWith,
        highlightedPostId,
        setHighlightedPostId,
        composerLocationPrefill,
        prefillComposerWithLocation,
        locations,
        attractions,
        locationsSyncedToFirestore,
        toastMessage,
        showToast,
        authModalOpen,
        setAuthModalOpen,
        signInWithGoogle,
        logout,
        updateProfile,
        createPost,
        deleteOwnPost,
        toggleLike,
        addComment,
        sharePost,
        toggleSavePost,
        reportPost,
        reportUser,
        blockUser,
        unblockUser,
        sendFriendRequest,
        acceptFriendRequest,
        declineFriendRequest,
        removeFriend,
        toggleFollow,
        markNotificationRead,
        markAllNotificationsRead,
        sendMessage,
        sendMediaMessage,
        setTypingStatus,
        markConversationRead,
        getUserById,
        adminUpdateUserRole,
        adminUpdateUserStatus,
        adminModeratePost,
        adminDeletePost,
        adminResolveReport,
        adminSendBroadcast,
        adminSaveAppSettings,
        adminSeedStarterPosts,
        adminSeedLocationsAndAttractions,
        adminSaveLocationNode,
        adminDeleteLocationNode,
        adminSaveAttraction,
        adminDeleteAttraction,
        adPackages,
        adPackagesSyncedToFirestore,
        localAds,
        activeLocalAds,
        myLocalAds,
        monetizationConfig,
        adConsentStatus,
        updateAdConsent,
        adPrivacyModalOpen,
        setAdPrivacyModalOpen,
        hiddenAdIds,
        hideAdForSession,
        submitLocalAd,
        submitAdPaymentReference,
        pauseOwnAd,
        deleteOwnUnpaidAd,
        trackAdImpression,
        trackAdClick,
        adminSeedMonetizationDefaults,
        adminSaveAdPackage,
        adminDeleteAdPackage,
        adminUpdateAdModeration,
        adminConfirmAdPayment,
        adminDeleteLocalAd,
        adminSaveMonetizationConfig,
      }}
    >
      {children}
    </SocialContext.Provider>
  );
};

export function useSocial(): SocialContextValue {
  const ctx = useContext(SocialContext);
  if (!ctx) {
    throw new Error('useSocial must be used inside SocialProvider');
  }
  return ctx;
}
