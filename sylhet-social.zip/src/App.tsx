import React from 'react';
import { MessageCircle, X } from 'lucide-react';
import { AdConsentBanner, AdPrivacyModal } from './components/AdPrivacyModal';
import { AdminDashboardView } from './components/AdminDashboardView';
import { AuthView } from './components/AuthView';
import { Avatar } from './components/Avatar';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ExploreLocationsView } from './components/ExploreLocationsView';
import { FriendsView } from './components/FriendsView';
import { LeftRail } from './components/LeftRail';
import { LocalAdsPortalView } from './components/LocalAdsPortalView';
import { MessagesView } from './components/MessagesView';
import { MobileBottomNav } from './components/MobileBottomNav';
import { NewsFeedView } from './components/NewsFeedView';
import { NotificationsView } from './components/NotificationsView';
import { ProfileView } from './components/ProfileView';
import { RightRail } from './components/RightRail';
import { SearchView } from './components/SearchView';
import { TopNav } from './components/TopNav';
import { SocialProvider, useSocial } from './context/SocialContext';

const SylhetSocialShell: React.FC = () => {
  const {
    authReady,
    currentUser,
    isAdmin,
    appSettings,
    activeTab,
    setActiveTab,
    setActiveConversationId,
    chatAlert,
    dismissChatAlert,
    authModalOpen,
    setAuthModalOpen,
    toastMessage,
    t,
  } = useSocial();

  if (!authReady) {
    return (
      <div className="min-h-screen bg-[#F3F5F4] dark:bg-[#0D1512] flex items-center justify-center p-6">
        <div className="flex flex-col items-center gap-3">
          <svg
            aria-hidden="true"
            viewBox="0 0 36 36"
            className="w-10 h-10"
            fill="none"
          >
            <rect width="36" height="36" rx="10" fill="#0B6E4F" />
            <path
              d="M11 24C11 16.5 16.2 11 25 10C24 18.5 19.2 24 11 24Z"
              fill="#D1FAE5"
            />
          </svg>
          <p className="font-display text-lg font-bold text-slate-900 dark:text-white">
            Sylhet Social
          </p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <AuthView />;
  }

  const isWideWorkspace =
    activeTab === 'messages' || (activeTab === 'admin' && isAdmin);

  return (
    <div className="min-h-screen bg-[#F3F5F4] dark:bg-[#0D1512] text-slate-900 dark:text-slate-100">
      <TopNav />

      <main className="max-w-[1280px] mx-auto px-3 sm:px-5 pt-4 pb-24 md:pb-10">
        {currentUser.status === 'suspended' && (
          <div className="mb-4 rounded-2xl border border-rose-300 dark:border-rose-800/50 bg-rose-50 dark:bg-rose-950/30 px-4 py-3 text-xs sm:text-sm font-medium text-rose-800 dark:text-rose-200">
            {t.feed.suspendedNotice}
          </div>
        )}

        {appSettings.maintenanceMode && !isAdmin && (
          <div className="mb-4 rounded-2xl border border-amber-300 dark:border-amber-800/50 bg-amber-50 dark:bg-amber-950/30 px-4 py-3 text-xs sm:text-sm font-medium text-amber-800 dark:text-amber-200">
            {t.feed.maintenanceNotice}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          <LeftRail />

          <div
            className={
              isWideWorkspace
                ? 'lg:col-span-9 xl:col-span-9 min-w-0'
                : 'lg:col-span-9 xl:col-span-6 min-w-0'
            }
          >
            {activeTab === 'feed' && <NewsFeedView />}
            {activeTab === 'explore' && <ExploreLocationsView />}
            {activeTab === 'advertise' && <LocalAdsPortalView />}
            {activeTab === 'friends' && <FriendsView />}
            {activeTab === 'search' && <SearchView />}
            {activeTab === 'messages' && <MessagesView />}
            {activeTab === 'notifications' && <NotificationsView />}
            {activeTab === 'profile' && <ProfileView />}
            {activeTab === 'admin' && isAdmin && <AdminDashboardView />}
          </div>

          {!isWideWorkspace && <RightRail />}
        </div>
      </main>

      <MobileBottomNav />
      <AdConsentBanner />
      <AdPrivacyModal />

      {authModalOpen && (
        <AuthView isModal onClose={() => setAuthModalOpen(false)} />
      )}

      {chatAlert && (
        <div
          role="status"
          aria-live="polite"
          className="fixed top-18 right-3 sm:right-5 z-50 w-[calc(100%-1.5rem)] max-w-xs bg-white dark:bg-[#14201B] border border-emerald-700/25 dark:border-emerald-400/25 rounded-2xl shadow-xl p-3 flex items-center gap-3"
        >
          <button
            type="button"
            onClick={() => {
              setActiveConversationId(chatAlert.conversationId);
              setActiveTab('messages');
              dismissChatAlert();
            }}
            className="flex-1 min-w-0 flex items-center gap-2.5 text-left cursor-pointer"
          >
            <Avatar src={chatAlert.avatarUrl} name={chatAlert.senderName} size="sm" />
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-semibold text-[#0B6E4F] dark:text-emerald-400 flex items-center gap-1">
                <MessageCircle className="w-3 h-3 shrink-0" />
                <span className="truncate">{t.messagesPage.newMessageFrom}</span>
              </p>
              <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                {chatAlert.senderName}
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 truncate">
                {chatAlert.preview}
              </p>
            </div>
          </button>
          <button
            type="button"
            onClick={dismissChatAlert}
            aria-label={t.actions.cancel}
            className="min-w-[32px] min-h-[32px] rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 flex items-center justify-center shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-emerald-900 text-white text-xs sm:text-sm font-medium shadow-lg pointer-events-none whitespace-nowrap"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <SocialProvider>
        <SylhetSocialShell />
      </SocialProvider>
    </ErrorBoundary>
  );
}
