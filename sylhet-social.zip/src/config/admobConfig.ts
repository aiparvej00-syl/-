import { AdConsentStatus } from '../types/social';

export type AdMobEnvironment = 'development_test' | 'production_ready';

export interface AdMobUnitSet {
  appId: string;
  bannerUnitId: string;
  nativeUnitId: string;
  interstitialUnitId: string;
  rewardedUnitId: string;
}

/**
 * OFFICIAL GOOGLE ADMOB TEST IDS ONLY
 * Source: Google Mobile Ads SDK documentation (safe for development & QA).
 * Never replace with real/live AdMob IDs until explicit release approval.
 */
export const GOOGLE_ADMOB_TEST_UNITS: Readonly<AdMobUnitSet> = {
  appId: 'ca-app-pub-3940256099942544~3347511713',
  bannerUnitId: 'ca-app-pub-3940256099942544/6300978111',
  nativeUnitId: 'ca-app-pub-3940256099942544/2247696110',
  interstitialUnitId: 'ca-app-pub-3940256099942544/1033173712',
  rewardedUnitId: 'ca-app-pub-3940256099942544/5224354917',
};

/**
 * CLEARLY MARKED PLACEHOLDERS FOR FUTURE ANDROID PRODUCTION RELEASE
 * Replace these constants only when building the signed Android release bundle
 * in Google Play Console after AdMob policy review & owner approval.
 */
export const PRODUCTION_ADMOB_PLACEHOLDERS: Readonly<AdMobUnitSet> = {
  appId: 'REPLACE_WITH_PRODUCTION_ADMOB_APP_ID',
  bannerUnitId: 'REPLACE_WITH_PRODUCTION_ADMOB_BANNER_ID',
  nativeUnitId: 'REPLACE_WITH_PRODUCTION_ADMOB_NATIVE_ID',
  interstitialUnitId: 'REPLACE_WITH_PRODUCTION_ADMOB_INTERSTITIAL_ID',
  rewardedUnitId: 'REPLACE_WITH_PRODUCTION_ADMOB_REWARDED_ID',
};

export interface AdMobRequestOptions {
  environment: AdMobEnvironment;
  unitSet: AdMobUnitSet;
  isTestMode: boolean;
  nonPersonalizedAds: boolean;
  canShowAds: boolean;
  consentStatus: AdConsentStatus;
}

export interface SylhetSocialAdMobBridge {
  isAndroidNativeHost?: () => boolean;
  requestBannerAd?: (unitId: string, nonPersonalized: boolean) => void;
  requestNativeAd?: (unitId: string, nonPersonalized: boolean) => void;
  showInterstitialAd?: (unitId: string, nonPersonalized: boolean) => void;
  syncConsentStatus?: (status: AdConsentStatus) => void;
}

declare global {
  interface Window {
    SylhetSocialAdMob?: SylhetSocialAdMobBridge;
  }
}

export function isProductionPlaceholder(value: string): boolean {
  return value.startsWith('REPLACE_WITH_PRODUCTION_');
}

export function getActiveAdMobUnits(environment: AdMobEnvironment): {
  units: AdMobUnitSet;
  isTestMode: boolean;
} {
  // Force official Google Test Units whenever production placeholders have not been configured
  // or when development_test mode is selected.
  if (
    environment === 'development_test' ||
    isProductionPlaceholder(PRODUCTION_ADMOB_PLACEHOLDERS.appId) ||
    isProductionPlaceholder(PRODUCTION_ADMOB_PLACEHOLDERS.bannerUnitId)
  ) {
    return {
      units: GOOGLE_ADMOB_TEST_UNITS,
      isTestMode: true,
    };
  }
  return {
    units: PRODUCTION_ADMOB_PLACEHOLDERS,
    isTestMode: false,
  };
}

export function buildAdMobRequestOptions(
  environment: AdMobEnvironment,
  consentStatus: AdConsentStatus
): AdMobRequestOptions {
  const { units, isTestMode } = getActiveAdMobUnits(environment);
  const canShowAds = consentStatus === 'personalized' || consentStatus === 'non_personalized';
  const nonPersonalizedAds = consentStatus !== 'personalized';

  return {
    environment,
    unitSet: units,
    isTestMode,
    nonPersonalizedAds,
    canShowAds,
    consentStatus,
  };
}

export function dispatchAndroidAdMobBridge(
  slot: 'banner' | 'native',
  environment: AdMobEnvironment,
  consentStatus: AdConsentStatus
): boolean {
  if (typeof window === 'undefined' || !window.SylhetSocialAdMob) {
    return false;
  }
  const req = buildAdMobRequestOptions(environment, consentStatus);
  if (!req.canShowAds) return false;

  try {
    window.SylhetSocialAdMob.syncConsentStatus?.(consentStatus);
    if (slot === 'banner') {
      window.SylhetSocialAdMob.requestBannerAd?.(req.unitSet.bannerUnitId, req.nonPersonalizedAds);
      return true;
    }
    window.SylhetSocialAdMob.requestNativeAd?.(req.unitSet.nativeUnitId, req.nonPersonalizedAds);
    return true;
  } catch {
    return false;
  }
}
