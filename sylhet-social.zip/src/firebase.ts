import { initializeApp } from 'firebase/app';
import { GoogleAuthProvider, getAuth } from 'firebase/auth';
import {
  Database,
  getDatabase,
  onDisconnect,
  onValue,
  ref as rtdbRef,
  serverTimestamp as rtdbServerTimestamp,
  set as rtdbSet,
} from 'firebase/database';
import { doc, getDocFromServer, getFirestore } from 'firebase/firestore';
import { getDownloadURL, getStorage, ref as storageRef, uploadBytesResumable } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

let cachedRtdb: Database | null | undefined;

export function getRealtimeDb(): Database | null {
  if (cachedRtdb !== undefined) {
    return cachedRtdb;
  }
  try {
    const configWithUrl = firebaseConfig as Record<string, unknown>;
    const explicitUrl =
      typeof configWithUrl.databaseURL === 'string' && configWithUrl.databaseURL
        ? configWithUrl.databaseURL
        : `https://${firebaseConfig.projectId}-default-rtdb.firebaseio.com`;
    cachedRtdb = getDatabase(app, explicitUrl);
    return cachedRtdb;
  } catch (err) {
    console.warn('Realtime Database unavailable, using Firestore presence fallback:', err);
    cachedRtdb = null;
    return null;
  }
}

export interface RtdbPresencePayload {
  state: 'online' | 'offline';
  lastChanged: number;
}

export function subscribeRtdbConnectionAndPresence(
  uid: string,
  onConnectedChange?: (connected: boolean) => void
): () => void {
  const rtdb = getRealtimeDb();
  if (!rtdb) return () => {};

  const connectedRef = rtdbRef(rtdb, '.info/connected');
  const userStatusRef = rtdbRef(rtdb, `status/${uid}`);

  const unsub = onValue(
    connectedRef,
    (snap) => {
      const isConnected = snap.val() === true;
      onConnectedChange?.(isConnected);
      if (!isConnected) return;

      onDisconnect(userStatusRef)
        .set({
          state: 'offline',
          lastChanged: rtdbServerTimestamp(),
        })
        .then(() =>
          rtdbSet(userStatusRef, {
            state: 'online',
            lastChanged: rtdbServerTimestamp(),
          })
        )
        .catch(() => {
          // Non-fatal if RTDB is not yet provisioned in console
        });
    },
    () => {
      onConnectedChange?.(false);
    }
  );

  return () => {
    rtdbSet(userStatusRef, {
      state: 'offline',
      lastChanged: rtdbServerTimestamp(),
    }).catch(() => {});
    unsub();
  };
}

export function subscribeAllRtdbPresence(
  onUpdate: (presenceMap: Record<string, RtdbPresencePayload>) => void
): () => void {
  const rtdb = getRealtimeDb();
  if (!rtdb) return () => {};

  const statusRoot = rtdbRef(rtdb, 'status');
  const unsub = onValue(
    statusRoot,
    (snap) => {
      const val = snap.val();
      if (!val || typeof val !== 'object') {
        onUpdate({});
        return;
      }
      const next: Record<string, RtdbPresencePayload> = {};
      for (const [uid, entry] of Object.entries(val as Record<string, unknown>)) {
        if (entry && typeof entry === 'object') {
          const rec = entry as Record<string, unknown>;
          next[uid] = {
            state: rec.state === 'online' ? 'online' : 'offline',
            lastChanged: typeof rec.lastChanged === 'number' ? rec.lastChanged : Date.now(),
          };
        }
      }
      onUpdate(next);
    },
    () => {
      // Non-fatal fallback to Firestore presence
    }
  );
  return () => unsub();
}

export function setRtdbTypingState(conversationId: string, uid: string, isTyping: boolean): void {
  const rtdb = getRealtimeDb();
  if (!rtdb) return;
  const typingRef = rtdbRef(rtdb, `typing/${conversationId}/${uid}`);
  if (isTyping) {
    onDisconnect(typingRef)
      .set({ isTyping: false, updatedAt: rtdbServerTimestamp() })
      .catch(() => {});
  }
  rtdbSet(typingRef, {
    isTyping,
    updatedAt: rtdbServerTimestamp(),
  }).catch(() => {});
}

export function subscribeRtdbTyping(
  conversationId: string,
  otherUid: string,
  onTypingChange: (isTyping: boolean) => void
): () => void {
  const rtdb = getRealtimeDb();
  if (!rtdb) return () => {};
  const typingRef = rtdbRef(rtdb, `typing/${conversationId}/${otherUid}`);
  const unsub = onValue(
    typingRef,
    (snap) => {
      const val = snap.val() as { isTyping?: boolean; updatedAt?: number } | null;
      if (!val || !val.isTyping) {
        onTypingChange(false);
        return;
      }
      const fresh = typeof val.updatedAt !== 'number' || Date.now() - val.updatedAt < 8000;
      onTypingChange(Boolean(val.isTyping && fresh));
    },
    () => {
      onTypingChange(false);
    }
  );
  return () => unsub();
}

export interface UploadedMediaResult {
  url: string;
  name: string;
  size: number;
}

export function uploadChatMediaFile(
  conversationId: string,
  messageId: string,
  file: Blob,
  fileName: string,
  onProgress?: (percent: number) => void
): Promise<UploadedMediaResult> {
  return new Promise((resolve, reject) => {
    const cleanName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80) || 'media';
    const path = `chat_media/${conversationId}/${messageId}_${cleanName}`;
    const fileRef = storageRef(storage, path);
    const task = uploadBytesResumable(fileRef, file, {
      contentType: file.type || 'application/octet-stream',
    });

    task.on(
      'state_changed',
      (snapshot) => {
        if (snapshot.totalBytes > 0 && onProgress) {
          onProgress(Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100));
        }
      },
      (error) => {
        reject(error);
      },
      async () => {
        try {
          const url = await getDownloadURL(task.snapshot.ref);
          resolve({
            url,
            name: cleanName,
            size: file.size,
          });
        } catch (err) {
          reject(err);
        }
      }
    );
  });
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid ?? null,
      email: auth.currentUser?.email ?? null,
      emailVerified: auth.currentUser?.emailVerified ?? null,
      isAnonymous: auth.currentUser?.isAnonymous ?? null,
      tenantId: auth.currentUser?.tenantId ?? null,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function testConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

void testConnection();
