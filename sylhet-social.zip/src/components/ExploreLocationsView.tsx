import React, { useMemo, useState } from 'react';
import {
  ChevronRight,
  Compass,
  MapPin,
  Search as SearchIcon,
  Sparkles,
  X,
} from 'lucide-react';
import { ASSET_IMAGES } from '../data/seedData';
import { useSocial } from '../context/SocialContext';
import { AttractionCategory, LocationNode } from '../types/social';
import { formatCount } from '../utils/formatters';

const CATEGORIES: AttractionCategory[] = [
  'waterfall',
  'forest',
  'lake',
  'haor',
  'tea_garden',
  'cultural',
  'river',
  'heritage',
];

export const ExploreLocationsView: React.FC = () => {
  const {
    t,
    language,
    locations,
    attractions,
    navigateToSearch,
    prefillComposerWithLocation,
  } = useSocial();

  const [queryText, setQueryText] = useState('');
  const [selectedDistrictId, setSelectedDistrictId] = useState<string>('all');
  const [selectedUpazilaId, setSelectedUpazilaId] = useState<string>('all');
  const [selectedUnionId, setSelectedUnionId] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<AttractionCategory | 'all'>('all');

  const activeLocations = useMemo(
    () =>
      locations
        .filter((l) => l.isActive)
        .sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name)),
    [locations]
  );

  const activeAttractions = useMemo(
    () =>
      attractions
        .filter((a) => a.isActive)
        .sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured) || a.name.localeCompare(b.name)),
    [attractions]
  );

  const divisionNode = useMemo(
    () => activeLocations.find((l) => l.level === 'division'),
    [activeLocations]
  );

  const districts = useMemo(
    () => activeLocations.filter((l) => l.level === 'district'),
    [activeLocations]
  );

  const allUpazilas = useMemo(
    () => activeLocations.filter((l) => l.level === 'upazila'),
    [activeLocations]
  );

  const filteredUpazilasForSelect = useMemo(
    () =>
      selectedDistrictId === 'all'
        ? allUpazilas
        : allUpazilas.filter((u) => u.districtId === selectedDistrictId || u.parentId === selectedDistrictId),
    [allUpazilas, selectedDistrictId]
  );

  const moulvibazarUpazilas = useMemo(
    () =>
      allUpazilas.filter(
        (u) => u.districtId === 'dist_moulvibazar' || u.parentId === 'dist_moulvibazar'
      ),
    [allUpazilas]
  );

  const unionsForSelectedUpazila = useMemo(() => {
    if (selectedUpazilaId === 'all') return [];
    return activeLocations.filter(
      (l) => l.level === 'union' && (l.upazilaId === selectedUpazilaId || l.parentId === selectedUpazilaId)
    );
  }, [activeLocations, selectedUpazilaId]);

  const villagesForSelection = useMemo(() => {
    if (selectedUnionId !== 'all') {
      return activeLocations.filter(
        (l) => l.level === 'village' && (l.unionId === selectedUnionId || l.parentId === selectedUnionId)
      );
    }
    if (selectedUpazilaId !== 'all') {
      return activeLocations.filter(
        (l) => l.level === 'village' && l.upazilaId === selectedUpazilaId
      );
    }
    return [];
  }, [activeLocations, selectedUnionId, selectedUpazilaId]);

  const trimmed = queryText.trim().toLowerCase();

  const matchingLocations = useMemo(() => {
    return activeLocations.filter((node) => {
      if (selectedDistrictId !== 'all' && node.districtId !== selectedDistrictId && node.id !== selectedDistrictId) {
        return false;
      }
      if (selectedUpazilaId !== 'all' && node.upazilaId !== selectedUpazilaId && node.id !== selectedUpazilaId) {
        return false;
      }
      if (!trimmed) return true;
      return (
        node.name.toLowerCase().includes(trimmed) ||
        node.nameBn.toLowerCase().includes(trimmed)
      );
    });
  }, [activeLocations, selectedDistrictId, selectedUpazilaId, trimmed]);

  const filteredAttractions = useMemo(() => {
    return activeAttractions.filter((attr) => {
      if (selectedDistrictId !== 'all' && attr.districtId !== selectedDistrictId) {
        return false;
      }
      if (selectedUpazilaId !== 'all' && attr.upazilaId !== selectedUpazilaId) {
        return false;
      }
      if (selectedCategory !== 'all' && attr.category !== selectedCategory) {
        return false;
      }
      if (!trimmed) return true;
      return (
        attr.name.toLowerCase().includes(trimmed) ||
        attr.nameBn.toLowerCase().includes(trimmed) ||
        attr.upazilaName.toLowerCase().includes(trimmed) ||
        (attr.upazilaNameBn && attr.upazilaNameBn.toLowerCase().includes(trimmed)) ||
        attr.districtName.toLowerCase().includes(trimmed) ||
        (attr.unionName && attr.unionName.toLowerCase().includes(trimmed)) ||
        (attr.villageName && attr.villageName.toLowerCase().includes(trimmed)) ||
        attr.locationSummary.toLowerCase().includes(trimmed) ||
        attr.locationSummaryBn.toLowerCase().includes(trimmed) ||
        (attr.description && attr.description.toLowerCase().includes(trimmed))
      );
    });
  }, [activeAttractions, selectedDistrictId, selectedUpazilaId, selectedCategory, trimmed]);

  const activeDistrictObj = districts.find((d) => d.id === selectedDistrictId);
  const activeUpazilaObj = allUpazilas.find((u) => u.id === selectedUpazilaId);
  const activeUnionObj = activeLocations.find((u) => u.id === selectedUnionId);

  const handleDistrictFilter = (nextDistId: string) => {
    setSelectedDistrictId(nextDistId);
    setSelectedUpazilaId('all');
    setSelectedUnionId('all');
  };

  const handleUpazilaCardClick = (upazila: LocationNode) => {
    setSelectedDistrictId(upazila.districtId || 'dist_moulvibazar');
    setSelectedUpazilaId(upazila.id);
    setSelectedUnionId('all');
  };

  const clearAllFilters = () => {
    setQueryText('');
    setSelectedDistrictId('all');
    setSelectedUpazilaId('all');
    setSelectedUnionId('all');
    setSelectedCategory('all');
  };

  const getCategoryLabel = (cat: AttractionCategory) => t.locationsPage.categories[cat] || cat;

  const getLocationName = (node?: LocationNode) =>
    node ? (language === 'bn' ? node.nameBn || node.name : node.name) : '';

  const buildNodeTag = (node: LocationNode) => {
    const dist = activeLocations.find((l) => l.id === node.districtId);
    const upa = activeLocations.find((l) => l.id === node.upazilaId);
    const uni = activeLocations.find((l) => l.id === node.unionId);
    const enParts: string[] = [];
    const bnParts: string[] = [];

    if (node.level === 'village') {
      enParts.push(node.name);
      bnParts.push(node.nameBn || node.name);
      if (uni) {
        enParts.push(uni.name);
        bnParts.push(uni.nameBn || uni.name);
      }
      if (upa) {
        enParts.push(upa.name);
        bnParts.push(upa.nameBn || upa.name);
      }
      if (dist) {
        enParts.push(dist.name);
        bnParts.push(dist.nameBn || dist.name);
      }
    } else if (node.level === 'union') {
      enParts.push(node.name);
      bnParts.push(node.nameBn || node.name);
      if (upa) {
        enParts.push(upa.name);
        bnParts.push(upa.nameBn || upa.name);
      }
      if (dist) {
        enParts.push(dist.name);
        bnParts.push(dist.nameBn || dist.name);
      }
    } else if (node.level === 'upazila') {
      enParts.push(node.name);
      bnParts.push(node.nameBn || node.name);
      if (dist) {
        enParts.push(dist.name);
        bnParts.push(dist.nameBn || dist.name);
      }
    } else {
      enParts.push(node.name);
      bnParts.push(node.nameBn || node.name);
    }

    return {
      en: enParts.join(', ').slice(0, 118),
      bn: bnParts.join(', ').slice(0, 118),
    };
  };

  const hasFiltersActive =
    Boolean(trimmed) ||
    selectedDistrictId !== 'all' ||
    selectedUpazilaId !== 'all' ||
    selectedUnionId !== 'all' ||
    selectedCategory !== 'all';

  return (
    <div className="space-y-4">
      {/* Header & Search/Filter Controls */}
      <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
          <div>
            <h1 className="font-display text-lg sm:text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Compass className="w-5 h-5 text-[#0B6E4F] dark:text-emerald-400 shrink-0" />
              <span>{t.locationsPage.title}</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1">
              {t.locationsPage.subtitle}
            </p>
          </div>
          {hasFiltersActive && (
            <button
              type="button"
              onClick={clearAllFilters}
              className="min-h-[38px] px-3 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 shrink-0 cursor-pointer"
            >
              {t.locationsPage.clearFilters}
            </button>
          )}
        </div>

        {/* Search Input */}
        <div className="relative">
          <SearchIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={queryText}
            onChange={(e) => setQueryText(e.target.value)}
            placeholder={t.locationsPage.searchPlaceholder}
            className="w-full min-h-[44px] pl-10 pr-10 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          />
          {queryText && (
            <button
              type="button"
              onClick={() => setQueryText('')}
              aria-label="Clear search"
              className="absolute right-2 top-1/2 -translate-y-1/2 min-w-[34px] min-h-[34px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* District & Upazila Dropdowns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <select
            value={selectedDistrictId}
            onChange={(e) => handleDistrictFilter(e.target.value)}
            aria-label={t.locationsPage.districtLabel}
            className="w-full min-h-[42px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm font-medium text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          >
            <option value="all">{t.locationsPage.allDistricts}</option>
            {districts.map((dist) => (
              <option key={dist.id} value={dist.id}>
                {language === 'bn' ? dist.nameBn : dist.name}
              </option>
            ))}
          </select>

          <select
            value={selectedUpazilaId}
            onChange={(e) => {
              setSelectedUpazilaId(e.target.value);
              setSelectedUnionId('all');
            }}
            aria-label={t.locationsPage.upazilaLabel}
            className="w-full min-h-[42px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm font-medium text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          >
            <option value="all">{t.locationsPage.allUpazilas}</option>
            {filteredUpazilasForSelect.map((upa) => (
              <option key={upa.id} value={upa.id}>
                {language === 'bn' ? upa.nameBn : upa.name}
              </option>
            ))}
          </select>
        </div>

        {/* Category Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-1">
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-[#0B6E4F] text-white'
                : 'bg-[#F4F6F4] dark:bg-[#0D1512] text-slate-600 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-white/5'
            }`}
          >
            {t.locationsPage.allCategories}
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#0B6E4F] text-white'
                  : 'bg-[#F4F6F4] dark:bg-[#0D1512] text-slate-600 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-white/5'
              }`}
            >
              {getCategoryLabel(cat)}
            </button>
          ))}
        </div>
      </section>

      {/* Section 1: Hierarchical Directory & 7 Official Upazilas of Moulvibazar */}
      <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
            {t.locationsPage.moulvibazarUpazilasTitle}
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {formatCount(moulvibazarUpazilas.length, language)} {t.locationsPage.upazilaLabel}
          </span>
        </div>

        {/* Hierarchical Breadcrumb Path */}
        <nav
          aria-label={t.locationsPage.hierarchyTitle}
          className="flex flex-wrap items-center gap-1.5 text-xs bg-[#F6F8F6] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 rounded-xl px-3 py-2.5"
        >
          <button
            type="button"
            onClick={() => {
              setSelectedDistrictId('all');
              setSelectedUpazilaId('all');
              setSelectedUnionId('all');
            }}
            className="font-semibold text-[#0B6E4F] dark:text-emerald-300 hover:underline cursor-pointer"
          >
            {getLocationName(divisionNode) || (language === 'bn' ? 'সিলেট বিভাগ' : 'Sylhet Division')}
          </button>

          {activeDistrictObj && (
            <>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <button
                type="button"
                onClick={() => {
                  setSelectedUpazilaId('all');
                  setSelectedUnionId('all');
                }}
                className="font-semibold text-slate-800 dark:text-slate-100 hover:underline cursor-pointer"
              >
                {getLocationName(activeDistrictObj)}
              </button>
            </>
          )}

          {activeUpazilaObj && (
            <>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <button
                type="button"
                onClick={() => setSelectedUnionId('all')}
                className="font-semibold text-slate-800 dark:text-slate-100 hover:underline cursor-pointer"
              >
                {getLocationName(activeUpazilaObj)}
              </button>
            </>
          )}

          {activeUnionObj && (
            <>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="font-semibold text-emerald-700 dark:text-emerald-300">
                {getLocationName(activeUnionObj)}
              </span>
            </>
          )}
        </nav>

        {/* All 7 Moulvibazar Upazilas Quick Selector */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {moulvibazarUpazilas.map((upa) => {
            const isSelected = selectedUpazilaId === upa.id;
            const unionCount = activeLocations.filter(
              (l) => l.level === 'union' && l.upazilaId === upa.id
            ).length;
            const attrCount = activeAttractions.filter((a) => a.upazilaId === upa.id).length;

            return (
              <button
                key={upa.id}
                type="button"
                onClick={() =>
                  isSelected ? setSelectedUpazilaId('all') : handleUpazilaCardClick(upa)
                }
                className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                  isSelected
                    ? 'bg-[#0B6E4F] border-[#0B6E4F] text-white'
                    : 'bg-[#F8FAF8] dark:bg-[#0D1512] border-emerald-950/10 dark:border-emerald-200/10 hover:border-emerald-700/40 text-slate-900 dark:text-white'
                }`}
              >
                <p className="text-xs sm:text-sm font-bold truncate">
                  {language === 'bn' ? upa.nameBn : upa.name}
                </p>
                <p
                  className={`text-[11px] mt-1 tabular-nums ${
                    isSelected ? 'text-emerald-100' : 'text-slate-500 dark:text-slate-400'
                  }`}
                >
                  {formatCount(unionCount, language)} {t.locationsPage.unionLabel} ·{' '}
                  {formatCount(attrCount, language)} {language === 'bn' ? 'স্থান' : 'spots'}
                </p>
              </button>
            );
          })}
        </div>

        {/* Drilldown: Unions & Villages inside Selected Upazila */}
        {activeUpazilaObj && (
          <div className="pt-3 border-t border-emerald-950/10 dark:border-emerald-200/10 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                {getLocationName(activeUpazilaObj)} — {t.locationsPage.unionLabel} &{' '}
                {t.locationsPage.villageLabel}
              </p>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => navigateToSearch(getLocationName(activeUpazilaObj))}
                  className="text-xs font-semibold text-[#0B6E4F] dark:text-emerald-300 hover:underline cursor-pointer"
                >
                  {t.locationsPage.explorePosts}
                </button>
                <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>
                <button
                  type="button"
                  onClick={() => prefillComposerWithLocation(buildNodeTag(activeUpazilaObj))}
                  className="text-xs font-semibold text-[#0B6E4F] dark:text-emerald-300 hover:underline cursor-pointer"
                >
                  {t.locationsPage.tagInPost}
                </button>
              </div>
            </div>

            {unionsForSelectedUpazila.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {unionsForSelectedUpazila.map((uni) => {
                  const active = selectedUnionId === uni.id;
                  return (
                    <button
                      key={uni.id}
                      type="button"
                      onClick={() => setSelectedUnionId(active ? 'all' : uni.id)}
                      className={`min-h-[36px] px-3 py-1 rounded-lg text-xs font-medium border cursor-pointer ${
                        active
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-700 text-emerald-900 dark:text-emerald-200 font-semibold'
                          : 'bg-white dark:bg-[#14201B] border-emerald-950/10 dark:border-emerald-200/10 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5'
                      }`}
                    >
                      {language === 'bn' ? uni.nameBn : uni.name}
                    </button>
                  );
                })}
              </div>
            )}

            {villagesForSelection.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {villagesForSelection.map((vil) => {
                  const tag = buildNodeTag(vil);
                  return (
                    <div
                      key={vil.id}
                      className="p-3 rounded-xl border border-emerald-950/10 dark:border-emerald-200/10 bg-[#F8FAF8] dark:bg-[#0D1512] flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <p className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white truncate">
                          {language === 'bn' ? vil.nameBn : vil.name}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {language === 'bn' ? tag.bn : tag.en}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => prefillComposerWithLocation(tag)}
                        className="min-h-[34px] px-2.5 py-1 rounded-lg bg-[#0B6E4F] hover:bg-[#09583F] text-white text-[11px] font-semibold shrink-0 cursor-pointer"
                      >
                        {t.locationsPage.tagInPost}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Search Matches across Hierarchy when user types a query */}
        {trimmed && (
          <div className="pt-3 border-t border-emerald-950/10 dark:border-emerald-200/10 space-y-2">
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              {t.locationsPage.hierarchyTitle} ({formatCount(matchingLocations.length, language)})
            </p>
            {matchingLocations.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t.locationsPage.noLocationsMatch}
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {matchingLocations.slice(0, 12).map((node) => {
                  const tag = buildNodeTag(node);
                  const levelText =
                    node.level === 'division'
                      ? t.locationsPage.divisionLabel
                      : node.level === 'district'
                      ? t.locationsPage.districtLabel
                      : node.level === 'upazila'
                      ? t.locationsPage.upazilaLabel
                      : node.level === 'union'
                      ? t.locationsPage.unionLabel
                      : t.locationsPage.villageLabel;
                  return (
                    <div
                      key={node.id}
                      className="p-2.5 rounded-xl border border-emerald-950/10 dark:border-emerald-200/10 flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                          {language === 'bn' ? node.nameBn : node.name}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {levelText} · {language === 'bn' ? tag.bn : tag.en}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => prefillComposerWithLocation(tag)}
                        className="min-h-[34px] px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-[#0B6E4F] dark:text-emerald-300 text-[11px] font-semibold shrink-0 cursor-pointer"
                      >
                        {t.locationsPage.tagInPost}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </section>

      {/* Section 2: Curated Tourist Attractions */}
      <section className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white">
            {t.locationsPage.attractionsTitle}
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {formatCount(filteredAttractions.length, language)}
          </span>
        </div>

        {filteredAttractions.length === 0 ? (
          <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-10 text-center space-y-3">
            <p className="text-sm text-slate-500 dark:text-slate-400">
              {t.locationsPage.noAttractionsMatch}
            </p>
            {hasFiltersActive && (
              <button
                type="button"
                onClick={clearAllFilters}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-[#0B6E4F] text-white text-xs font-semibold cursor-pointer"
              >
                {t.locationsPage.clearFilters}
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredAttractions.map((attr) => {
              const title = language === 'bn' ? attr.nameBn || attr.name : attr.name;
              const summary =
                language === 'bn'
                  ? attr.locationSummaryBn || attr.locationSummary
                  : attr.locationSummary;
              const desc =
                language === 'bn'
                  ? attr.descriptionBn || attr.description
                  : attr.description;
              const catLabel = getCategoryLabel(attr.category);
              const unionDisplay =
                language === 'bn' ? attr.unionNameBn || attr.unionName : attr.unionName;

              return (
                <article
                  key={attr.id}
                  className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl overflow-hidden flex flex-col"
                >
                  <div className="relative aspect-[16/9] bg-emerald-950/10 overflow-hidden">
                    <img
                      src={attr.imageUrl || ASSET_IMAGES.teaGardenCover}
                      alt={title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    {attr.isFeatured && (
                      <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-lg bg-[#0B6E4F]/90 text-white text-[11px] font-semibold flex items-center gap-1 backdrop-blur-xs">
                        <Sparkles className="w-3 h-3" />
                        <span>{t.locationsPage.featuredBadge}</span>
                      </div>
                    )}
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                    <div className="space-y-1.5">
                      <p className="text-[11px] font-semibold text-[#0B6E4F] dark:text-emerald-400">
                        {catLabel}
                        {unionDisplay ? ` · ${unionDisplay}` : ''}
                      </p>
                      <h3 className="font-display text-base font-bold text-slate-900 dark:text-white leading-snug">
                        {title}
                      </h3>
                      <p className="text-xs text-slate-600 dark:text-slate-300 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400 shrink-0" />
                        <span>{summary}</span>
                      </p>
                      {desc && (
                        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed pt-0.5 line-clamp-3">
                          {desc}
                        </p>
                      )}
                    </div>

                    <div className="pt-2 border-t border-emerald-950/10 dark:border-emerald-200/10 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => navigateToSearch(attr.name)}
                        className="flex-1 min-h-[40px] px-3 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 cursor-pointer"
                      >
                        {t.locationsPage.explorePosts}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          prefillComposerWithLocation({
                            en: `${attr.name}, ${attr.upazilaName}, ${attr.districtName}`.slice(0, 118),
                            bn: `${attr.nameBn || attr.name}, ${attr.upazilaNameBn || attr.upazilaName}, ${attr.districtNameBn || attr.districtName}`.slice(
                              0,
                              118
                            ),
                          })
                        }
                        className="flex-1 min-h-[40px] px-3 py-1.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold cursor-pointer"
                      >
                        {t.locationsPage.tagInPost}
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
