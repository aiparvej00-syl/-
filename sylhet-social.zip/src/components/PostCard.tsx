import React, { useEffect, useState } from 'react';
import {
  Bookmark,
  Flag,
  Heart,
  Link2,
  MapPin,
  MessageCircle,
  Pause,
  Play,
  Repeat2,
  Send,
  Share2,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { PostItem, ReportReason } from '../types/social';
import { formatCount, formatRelativeTime, getDisplayName } from '../utils/formatters';
import { Avatar } from './Avatar';

interface PostCardProps {
  post: PostItem;
}

const TEXT_CARD_STYLE: Record<string, string> = {
  emerald: 'bg-gradient-to-br from-[#0B6E4F] to-[#064E3B] text-white',
  surma: 'bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-800 text-white',
  tea: 'bg-gradient-to-br from-amber-700 to-amber-900 text-white',
};

export const PostCard: React.FC<PostCardProps> = ({ post }) => {
  const {
    t,
    language,
    currentUser,
    posts,
    savedPostIds,
    highlightedPostId,
    setHighlightedPostId,
    getUserById,
    openProfile,
    toggleLike,
    addComment,
    sharePost,
    toggleSavePost,
    deleteOwnPost,
    reportPost,
    showToast,
  } = useSocial();

  const author = getUserById(post.authorId);
  const sharedSource = post.sharedPostId
    ? posts.find((p) => p.id === post.sharedPostId)
    : undefined;
  const sharedAuthor = sharedSource ? getUserById(sharedSource.authorId) : undefined;

  const [commentsOpen, setCommentsOpen] = useState(
    post.comments.length > 0 && highlightedPostId === post.id
  );
  const [commentText, setCommentText] = useState('');
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [shareNote, setShareNote] = useState('');
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportReason, setReportReason] = useState<ReportReason>('spam');
  const [reportDetails, setReportDetails] = useState('');
  const [imgFailed, setImgFailed] = useState(false);

  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [progress, setProgress] = useState(18);

  useEffect(() => {
    if (!isPlaying || post.videoUrl) return;
    const timer = window.setInterval(() => {
      setProgress((prev) => (prev >= 100 ? 0 : prev + 4));
    }, 300);
    return () => window.clearInterval(timer);
  }, [isPlaying, post.videoUrl]);

  useEffect(() => {
    if (highlightedPostId === post.id) {
      setCommentsOpen(true);
      const timer = window.setTimeout(() => setHighlightedPostId(null), 2500);
      return () => window.clearTimeout(timer);
    }
  }, [highlightedPostId, post.id, setHighlightedPostId]);

  const authorDisplayName = author ? getDisplayName(author, language) : 'Sylhet Member';
  const isLiked = Boolean(post.likedByMe);
  const isSaved = savedPostIds.includes(post.id);
  const isOwnPost = currentUser?.uid === post.authorId;

  const displayPostText =
    language === 'bn' && post.textBn ? post.textBn : post.text;
  const displayLocation =
    language === 'bn' && post.locationBn ? post.locationBn : post.location;

  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    await addComment(post.id, commentText);
    setCommentText('');
    setCommentsOpen(true);
  };

  const handleCopyLink = async () => {
    const shareUrl = `${window.location.origin}/?post=${post.id}`;
    try {
      await navigator.clipboard.writeText(shareUrl);
    } catch {
      // Fallback silent
    }
    showToast(t.actions.linkCopied);
    setShareModalOpen(false);
  };

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    await reportPost(post.id, post.authorId, reportReason, reportDetails);
    setReportDetails('');
    setReportModalOpen(false);
  };

  const renderMedia = (targetPost: PostItem, targetAuthorName: string) => {
    if (targetPost.mediaType === 'photo' && targetPost.photoUrl) {
      return (
        <div className="mt-3 rounded-xl overflow-hidden bg-emerald-950/5 dark:bg-black/30 border border-emerald-950/10 dark:border-emerald-200/10">
          {!imgFailed ? (
            <img
              src={targetPost.photoUrl}
              alt={`${targetAuthorName} — Sylhet Social`}
              referrerPolicy="no-referrer"
              onError={() => setImgFailed(true)}
              className="w-full max-h-[480px] object-cover"
            />
          ) : (
            <div className="h-56 flex flex-col items-center justify-center gap-2 text-slate-500 dark:text-slate-400">
              <MapPin className="w-6 h-6 text-emerald-700" />
              <span className="text-xs font-medium">{displayLocation || 'Sylhet, Bangladesh'}</span>
            </div>
          )}
        </div>
      );
    }

    if (targetPost.mediaType === 'video') {
      if (targetPost.videoUrl) {
        return (
          <div className="mt-3 rounded-xl overflow-hidden bg-black border border-emerald-950/10 dark:border-emerald-200/10">
            <video
              src={targetPost.videoUrl}
              controls
              playsInline
              className="w-full max-h-[460px] object-contain"
            />
          </div>
        );
      }

      if (targetPost.videoThumbnailUrl) {
        return (
          <div className="mt-3 relative rounded-xl overflow-hidden bg-black aspect-[4/3] border border-emerald-950/10 dark:border-emerald-200/10 group">
            <img
              src={targetPost.videoThumbnailUrl}
              alt={`${targetAuthorName} video reel`}
              referrerPolicy="no-referrer"
              className={`w-full h-full object-cover ${
                isPlaying ? 'animate-kenburns' : 'animate-kenburns-paused'
              }`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-black/25 pointer-events-none" />

            <button
              type="button"
              onClick={() => setIsPlaying((prev) => !prev)}
              aria-label={isPlaying ? 'Pause video' : 'Play video'}
              className="absolute inset-0 flex items-center justify-center cursor-pointer"
            >
              <span className="w-14 h-14 rounded-full bg-black/60 backdrop-blur-xs text-white flex items-center justify-center transition-transform group-hover:scale-105">
                {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
              </span>
            </button>

            <div className="absolute bottom-0 left-0 right-0 p-3 flex items-center gap-3 text-white">
              <button
                type="button"
                onClick={() => setIsPlaying((prev) => !prev)}
                aria-label={isPlaying ? 'Pause' : 'Play'}
                className="min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg hover:bg-white/15 cursor-pointer"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
              <div className="flex-1 h-1.5 rounded-full bg-white/30 overflow-hidden">
                <div
                  className="h-full bg-emerald-400 transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <span className="text-xs font-mono tabular-nums">
                {targetPost.videoDuration || '0:24'}
              </span>
              <button
                type="button"
                onClick={() => setIsMuted((prev) => !prev)}
                aria-label={isMuted ? 'Unmute' : 'Mute'}
                className="min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg hover:bg-white/15 cursor-pointer"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>
          </div>
        );
      }
    }

    return null;
  };

  return (
    <article
      className={`bg-white dark:bg-[#14201B] border rounded-2xl p-4 sm:p-5 transition-colors ${
        highlightedPostId === post.id
          ? 'border-emerald-600 ring-2 ring-emerald-600/25'
          : 'border-emerald-950/10 dark:border-emerald-200/10'
      }`}
    >
      {/* Post Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => openProfile(post.authorId)}
            className="shrink-0 rounded-full focus-visible:outline-2 focus-visible:outline-emerald-700 cursor-pointer"
          >
            <Avatar src={author?.avatarUrl} name={authorDisplayName} size="md" />
          </button>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-x-1.5">
              <button
                type="button"
                onClick={() => openProfile(post.authorId)}
                className="font-semibold text-sm sm:text-base text-slate-900 dark:text-white hover:underline text-left truncate cursor-pointer"
              >
                {authorDisplayName}
              </button>
              {sharedSource && (
                <span className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                  {t.feed.sharedAPost}
                </span>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
              <span>{formatRelativeTime(post.createdAt, language)}</span>
              {displayLocation && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-emerald-700 dark:text-emerald-400 shrink-0" />
                    <span className="truncate">{displayLocation}</span>
                  </span>
                </>
              )}
              {post.moderationStatus === 'pending' && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-amber-700 dark:text-amber-400 font-medium">
                    {t.feed.pendingReviewBadge}
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => void toggleSavePost(post.id)}
            aria-label={isSaved ? t.actions.saved : t.actions.save}
            className={`min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl transition-colors cursor-pointer ${
              isSaved
                ? 'text-[#0B6E4F] dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60'
                : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-700 dark:hover:text-slate-200'
            }`}
          >
            <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
          </button>

          {isOwnPost ? (
            <button
              type="button"
              onClick={() => void deleteOwnPost(post.id)}
              aria-label={t.actions.deletePost}
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 hover:text-rose-600 transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setReportModalOpen(true)}
              aria-label={t.actions.reportPost}
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:bg-amber-50 dark:hover:bg-amber-950/30 hover:text-amber-600 transition-colors cursor-pointer"
            >
              <Flag className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Post Body */}
      {displayPostText &&
        (post.mediaType === 'text' && post.textCardTheme && post.textCardTheme !== 'none' ? (
          <div
            className={`mt-3 rounded-2xl px-6 py-10 text-center ${
              TEXT_CARD_STYLE[post.textCardTheme] || ''
            }`}
          >
            <p className="text-lg sm:text-xl font-semibold leading-relaxed text-balance">
              {displayPostText}
            </p>
          </div>
        ) : (
          <p className="mt-3 text-sm sm:text-[15px] text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line">
            {displayPostText}
          </p>
        ))}

      {renderMedia(post, authorDisplayName)}

      {sharedSource && sharedAuthor && (
        <div className="mt-3 rounded-xl border border-emerald-950/10 dark:border-emerald-200/10 p-3.5 bg-[#F8FAF8] dark:bg-[#0D1512]">
          <div className="flex items-center gap-2.5">
            <Avatar
              src={sharedAuthor.avatarUrl}
              name={getDisplayName(sharedAuthor, language)}
              size="xs"
            />
            <div className="min-w-0">
              <button
                type="button"
                onClick={() => openProfile(sharedAuthor.id)}
                className="text-xs font-semibold text-slate-900 dark:text-white hover:underline cursor-pointer"
              >
                {getDisplayName(sharedAuthor, language)}
              </button>
              <span className="text-xs text-slate-500 dark:text-slate-400 ml-1.5">
                · {formatRelativeTime(sharedSource.createdAt, language)}
              </span>
            </div>
          </div>
          {(language === 'bn' && sharedSource.textBn ? sharedSource.textBn : sharedSource.text) && (
            <p className="mt-2 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
              {language === 'bn' && sharedSource.textBn ? sharedSource.textBn : sharedSource.text}
            </p>
          )}
          {renderMedia(sharedSource, getDisplayName(sharedAuthor, language))}
        </div>
      )}

      {/* Counts Summary */}
      <div className="mt-3.5 pt-2.5 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 tabular-nums">
        <span>
          {formatCount(post.likesCount, language)} {t.feed.likesCount}
        </span>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setCommentsOpen((prev) => !prev)}
            className="hover:underline cursor-pointer"
          >
            {formatCount(post.commentsCount, language)} {t.feed.commentsCount}
          </button>
          <span aria-hidden="true">·</span>
          <span>
            {formatCount(post.sharesCount, language)} {t.feed.sharesCount}
          </span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-2 pt-2 border-t border-emerald-950/10 dark:border-emerald-200/10 grid grid-cols-3 gap-1">
        <button
          type="button"
          onClick={() => void toggleLike(post.id)}
          className={`min-h-[44px] rounded-xl flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer ${
            isLiked
              ? 'text-[#0B6E4F] dark:text-emerald-300 bg-emerald-50/80 dark:bg-emerald-950/50'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
          }`}
        >
          <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
          <span>{isLiked ? t.actions.liked : t.actions.like}</span>
        </button>

        <button
          type="button"
          onClick={() => setCommentsOpen((prev) => !prev)}
          className="min-h-[44px] rounded-xl flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors whitespace-nowrap cursor-pointer"
        >
          <MessageCircle className="w-4 h-4" />
          <span>{t.actions.comment}</span>
        </button>

        <button
          type="button"
          onClick={() => setShareModalOpen(true)}
          className="min-h-[44px] rounded-xl flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors whitespace-nowrap cursor-pointer"
        >
          <Share2 className="w-4 h-4" />
          <span>{t.actions.share}</span>
        </button>
      </div>

      {/* Comments Section */}
      {commentsOpen && (
        <div className="mt-3 pt-3 border-t border-emerald-950/10 dark:border-emerald-200/10 space-y-3">
          {post.comments.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t.feed.noCommentsYet}
            </p>
          ) : (
            <div className="space-y-2.5">
              {post.comments.map((comment) => {
                const cAuthor = getUserById(comment.authorId);
                const cName = cAuthor ? getDisplayName(cAuthor, language) : 'Sylhet Member';
                return (
                  <div key={comment.id} className="flex items-start gap-2.5">
                    <button
                      type="button"
                      onClick={() => openProfile(comment.authorId)}
                      className="shrink-0 mt-0.5 cursor-pointer"
                    >
                      <Avatar src={cAuthor?.avatarUrl} name={cName} size="xs" />
                    </button>
                    <div className="flex-1 min-w-0 bg-[#F4F6F4] dark:bg-[#0D1512] rounded-xl px-3.5 py-2">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openProfile(comment.authorId)}
                          className="text-xs font-semibold text-slate-900 dark:text-white hover:underline cursor-pointer"
                        >
                          {cName}
                        </button>
                        <span className="text-[11px] text-slate-400">
                          {formatRelativeTime(comment.createdAt, language)}
                        </span>
                      </div>
                      <p className="text-sm text-slate-800 dark:text-slate-200 mt-0.5">
                        {comment.text}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <form onSubmit={(e) => void handleCommentSubmit(e)} className="flex items-center gap-2">
            <Avatar
              src={currentUser?.avatarUrl}
              name={currentUser ? getDisplayName(currentUser, language) : 'Guest'}
              size="xs"
            />
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder={t.feed.writeComment}
              className="flex-1 min-h-[40px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700"
            />
            <button
              type="submit"
              disabled={!commentText.trim()}
              aria-label={t.actions.send}
              className="min-w-[40px] min-h-[40px] rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] disabled:opacity-40 text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* Share Sheet / Modal */}
      {shareModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full sm:max-w-md bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-t-3xl sm:rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-semibold text-base text-slate-900 dark:text-white">
                {t.actions.share}
              </h3>
              <button
                type="button"
                onClick={() => setShareModalOpen(false)}
                aria-label={t.actions.cancel}
                className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <textarea
              value={shareNote}
              onChange={(e) => setShareNote(e.target.value)}
              rows={2}
              placeholder={t.feed.whatsOnMind}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700 resize-none"
            />

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => {
                  void sharePost(post.id, shareNote);
                  setShareNote('');
                  setShareModalOpen(false);
                }}
                className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
              >
                <Repeat2 className="w-4 h-4" />
                <span>{t.actions.repostToFeed}</span>
              </button>

              <button
                type="button"
                onClick={() => void handleCopyLink()}
                className="w-full min-h-[46px] px-4 py-2.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-white/5 text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
              >
                <Link2 className="w-4 h-4" />
                <span>{t.actions.copyLink}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Report Post Modal */}
      {reportModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <form
            onSubmit={(e) => void handleSubmitReport(e)}
            className="w-full sm:max-w-md bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-t-3xl sm:rounded-2xl p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-display font-semibold text-base text-slate-900 dark:text-white">
                {t.reportModal.title}
              </h3>
              <button
                type="button"
                onClick={() => setReportModalOpen(false)}
                aria-label={t.actions.cancel}
                className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                {t.reportModal.reasonLabel}
              </label>
              <select
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value as ReportReason)}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700"
              >
                <option value="spam">{t.reportModal.reasons.spam}</option>
                <option value="harassment">{t.reportModal.reasons.harassment}</option>
                <option value="misinformation">{t.reportModal.reasons.misinformation}</option>
                <option value="inappropriate">{t.reportModal.reasons.inappropriate}</option>
                <option value="other">{t.reportModal.reasons.other}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                {t.reportModal.detailsLabel}
              </label>
              <textarea
                value={reportDetails}
                onChange={(e) => setReportDetails(e.target.value)}
                rows={3}
                placeholder={t.reportModal.detailsPlaceholder}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700 resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setReportModalOpen(false)}
                className="min-h-[44px] px-4 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-sm font-semibold text-slate-700 dark:text-slate-200"
              >
                {t.actions.cancel}
              </button>
              <button
                type="submit"
                className="min-h-[44px] px-5 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold cursor-pointer"
              >
                {t.actions.submitReport}
              </button>
            </div>
          </form>
        </div>
      )}
    </article>
  );
};
