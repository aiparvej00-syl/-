import React, { useMemo, useState } from 'react';
import {
  Ban,
  Check,
  CheckCircle2,
  Download,
  PauseCircle,
  Pencil,
  Plus,
  RefreshCw,
  ShieldAlert,
  Smartphone,
  Trash2,
} from 'lucide-react';
import {
  GOOGLE_ADMOB_TEST_UNITS,
  PRODUCTION_ADMOB_PLACEHOLDERS,
} from '../config/admobConfig';
import { useSocial } from '../context/SocialContext';
import {
  AdPackage,
  AdPaymentMethod,
  AdPlacement,
  AdStatus,
} from '../types/social';
import { formatCount } from '../utils/formatters';

export const AdminMonetizationSection: React.FC = () => {
  const {
    t,
    language,
    adPackages,
    localAds,
    monetizationConfig,
    adminSeedMonetizationDefaults,
    adminSaveAdPackage,
    adminDeleteAdPackage,
    adminUpdateAdModeration,
    adminConfirmAdPayment,
    adminDeleteLocalAd,
    adminSaveMonetizationConfig,
  } = useSocial();

  const [subtab, setSubtab] = useState<'adsQueue' | 'packages' | 'admobSettings'>('adsQueue');
  const [adFilter, setAdFilter] = useState<'all' | AdStatus>('all');
  const [notesByAd, setNotesByAd] = useState<Record<string, string>>({});
  const [methodByAd, setMethodByAd] = useState<Record<string, AdPaymentMethod>>({});

  // Package editor state
  const [editingPkgId, setEditingPkgId] = useState<string | null>(null);
  const [pkgName, setPkgName] = useState('');
  const [pkgNameBn, setPkgNameBn] = useState('');
  const [pkgDesc, setPkgDesc] = useState('');
  const [pkgDescBn, setPkgDescBn] = useState('');
  const [pkgDuration, setPkgDuration] = useState(7);
  const [pkgPrice, setPkgPrice] = useState(500);
  const [pkgPlacement, setPkgPlacement] = useState<AdPlacement>('feed');
  const [pkgSort, setPkgSort] = useState(1);
  const [pkgActive, setPkgActive] = useState(true);

  // AdMob & Config draft state
  const [cfgDraft, setCfgDraft] = useState({
    admobEnvironment: monetizationConfig.admobEnvironment,
    admobBannerEnabled: monetizationConfig.admobBannerEnabled,
    admobNativeEnabled: monetizationConfig.admobNativeEnabled,
    localAdsEnabled: monetizationConfig.localAdsEnabled,
    feedAdInterval: monetizationConfig.feedAdInterval,
    requireAdConsent: monetizationConfig.requireAdConsent,
    manualPaymentInstructionsEn: monetizationConfig.manualPaymentInstructionsEn,
    manualPaymentInstructionsBn: monetizationConfig.manualPaymentInstructionsBn,
  });

  // Strict Revenue Reporting: ONLY manually confirmed 'paid' ads count as Confirmed Revenue
  const metrics = useMemo(() => {
    let confirmedPaidRevenueBdt = 0;
    let pendingUnverifiedFeeBdt = 0;
    let liveApprovedPaidCount = 0;
    let pendingReviewOrPaymentCount = 0;
    let totalImpressions = 0;
    let totalClicks = 0;

    for (const ad of localAds) {
      totalImpressions += ad.impressionsCount;
      totalClicks += ad.clicksCount;
      if (ad.paymentStatus === 'paid') {
        confirmedPaidRevenueBdt += ad.priceBdt;
      } else if (
        (ad.paymentStatus === 'unpaid' || ad.paymentStatus === 'pending_verification') &&
        ad.status !== 'rejected'
      ) {
        pendingUnverifiedFeeBdt += ad.priceBdt;
      }
      if (ad.status === 'approved' && ad.paymentStatus === 'paid') {
        liveApprovedPaidCount += 1;
      }
      if (ad.status === 'pending_review' || ad.paymentStatus === 'pending_verification') {
        pendingReviewOrPaymentCount += 1;
      }
    }

    return {
      confirmedPaidRevenueBdt,
      pendingUnverifiedFeeBdt,
      liveApprovedPaidCount,
      pendingReviewOrPaymentCount,
      totalImpressions,
      totalClicks,
    };
  }, [localAds]);

  const filteredAds = useMemo(
    () =>
      adFilter === 'all' ? localAds : localAds.filter((ad) => ad.status === adFilter),
    [localAds, adFilter]
  );

  const handleExportCsv = () => {
    const header = [
      'AdID',
      'BusinessName',
      'Category',
      'Location',
      'Package',
      'DurationDays',
      'PriceBDT',
      'ReviewStatus',
      'PaymentStatus',
      'PaymentMethod',
      'PaymentReference',
      'Impressions',
      'Clicks',
      'CreatedAt',
    ].join(',');
    const rows = localAds.map((ad) =>
      [
        ad.id,
        `"${ad.businessName.replace(/"/g, '""')}"`,
        ad.category,
        `"${ad.location.replace(/"/g, '""')}"`,
        `"${ad.packageName.replace(/"/g, '""')}"`,
        ad.durationDays,
        ad.priceBdt,
        ad.status,
        ad.paymentStatus,
        ad.paymentMethod || 'none',
        `"${(ad.paymentReference || '').replace(/"/g, '""')}"`,
        ad.impressionsCount,
        ad.clicksCount,
        ad.createdAt,
      ].join(',')
    );
    const blob = new Blob([[header, ...rows].join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `sylhet-social-ads-report-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const resetPackageForm = () => {
    setEditingPkgId(null);
    setPkgName('');
    setPkgNameBn('');
    setPkgDesc('');
    setPkgDescBn('');
    setPkgDuration(7);
    setPkgPrice(500);
    setPkgPlacement('feed');
    setPkgSort(adPackages.length + 1);
    setPkgActive(true);
  };

  const loadPackageForEdit = (pkg: AdPackage) => {
    setEditingPkgId(pkg.id);
    setPkgName(pkg.name);
    setPkgNameBn(pkg.nameBn);
    setPkgDesc(pkg.description || '');
    setPkgDescBn(pkg.descriptionBn || '');
    setPkgDuration(pkg.durationDays);
    setPkgPrice(pkg.priceBdt);
    setPkgPlacement(pkg.placement);
    setPkgSort(pkg.sortOrder);
    setPkgActive(pkg.isActive);
  };

  const handleSavePackage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pkgName.trim()) return;
    await adminSaveAdPackage({
      id: editingPkgId || undefined,
      name: pkgName,
      nameBn: pkgNameBn || pkgName,
      description: pkgDesc,
      descriptionBn: pkgDescBn,
      durationDays: pkgDuration,
      priceBdt: pkgPrice,
      placement: pkgPlacement,
      isActive: pkgActive,
      sortOrder: pkgSort,
    });
    resetPackageForm();
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    await adminSaveMonetizationConfig(cfgDraft);
  };

  const inputClass =
    'w-full min-h-[42px] px-3 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm text-slate-900 dark:text-slate-100';

  return (
    <div className="space-y-4">
      {/* KPI Revenue & Performance Cards (Strict Confirmed vs Pending Distinction) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            {t.admin.monetization.confirmedRevenueBdt}
          </p>
          <p className="font-display text-2xl font-bold text-[#0B6E4F] dark:text-emerald-300 mt-1 tabular-nums">
            ৳{formatCount(metrics.confirmedPaidRevenueBdt, language)}
          </p>
        </div>
        <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            {t.admin.monetization.pendingRevenueBdt}
          </p>
          <p className="font-display text-2xl font-bold text-amber-600 dark:text-amber-300 mt-1 tabular-nums">
            ৳{formatCount(metrics.pendingUnverifiedFeeBdt, language)}
          </p>
        </div>
        <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            {t.admin.monetization.activeAdsCount}
          </p>
          <p className="font-display text-2xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
            {formatCount(metrics.liveApprovedPaidCount, language)}
          </p>
        </div>
        <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            {t.admin.monetization.totalImpressions} / {t.admin.monetization.totalClicks}
          </p>
          <p className="font-display text-xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
            {formatCount(metrics.totalImpressions, language)} ·{' '}
            {formatCount(metrics.totalClicks, language)}
          </p>
        </div>
      </div>

      {/* Toolbar & Sub-tabs */}
      <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          {(['adsQueue', 'packages', 'admobSettings'] as const).map((tabId) => {
            const active = subtab === tabId;
            return (
              <button
                key={tabId}
                type="button"
                onClick={() => setSubtab(tabId)}
                className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold cursor-pointer ${
                  active
                    ? 'bg-[#0B6E4F] text-white'
                    : 'bg-[#F4F6F4] dark:bg-[#0D1512] text-slate-700 dark:text-slate-200'
                }`}
              >
                {t.admin.monetization.subtabs[tabId]}
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => void adminSeedMonetizationDefaults()}
            className="min-h-[40px] px-3 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 text-[#0B6E4F] dark:text-emerald-400" />
            <span>{t.admin.monetization.seedDefaults}</span>
          </button>
          <button
            type="button"
            onClick={handleExportCsv}
            className="min-h-[40px] px-3 py-1.5 rounded-xl bg-slate-900 dark:bg-emerald-800 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.admin.monetization.exportCsv}</span>
          </button>
        </div>
      </div>

      {/* 1. AD MODERATION & MANUAL PAYMENT QUEUE */}
      {subtab === 'adsQueue' && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-1.5">
            {(['all', 'pending_review', 'approved', 'paused', 'rejected'] as const).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setAdFilter(f)}
                className={`min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer ${
                  adFilter === f
                    ? 'bg-[#0B6E4F] text-white'
                    : 'bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 text-slate-600 dark:text-slate-300'
                }`}
              >
                {f === 'all' ? t.admin.monetization.filterAll : t.ads.statuses[f]}
              </button>
            ))}
          </div>

          {filteredAds.length === 0 ? (
            <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-8 text-center text-sm text-slate-500 dark:text-slate-400">
              {t.admin.monetization.noAdsFound}
            </div>
          ) : (
            filteredAds.map((ad) => {
              const note = notesByAd[ad.id] ?? ad.adminNote ?? '';
              const chosenMethod = methodByAd[ad.id] || ad.paymentMethod || 'manual_bkash';

              return (
                <article
                  key={ad.id}
                  className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    <div className="space-y-1 min-w-0">
                      <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
                        {ad.businessName} — {ad.title}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                        {t.ads.categories[ad.category]} · {ad.location} · {ad.contactPhone} ·{' '}
                        {ad.packageName} (৳{formatCount(ad.priceBdt, language)} /{' '}
                        {formatCount(ad.durationDays, language)} {t.ads.daysUnit})
                      </p>
                      <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                        {ad.description}
                      </p>
                    </div>

                    {ad.imageUrl && (
                      <img
                        src={ad.imageUrl}
                        alt={ad.businessName}
                        referrerPolicy="no-referrer"
                        className="w-24 h-16 object-cover rounded-xl shrink-0 border border-emerald-950/10 dark:border-emerald-200/10"
                      />
                    )}
                  </div>

                  {/* Honest Payment Proof Status Row */}
                  <div className="rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] p-3 flex flex-wrap items-center justify-between gap-2 text-xs tabular-nums">
                    <div>
                      <span className="font-semibold text-slate-700 dark:text-slate-200">
                        {t.ads.reviewStatusLabel}: {t.ads.statuses[ad.status]}
                      </span>
                      <span aria-hidden="true" className="mx-2 text-slate-400">
                        ·
                      </span>
                      <span
                        className={`font-bold ${
                          ad.paymentStatus === 'paid'
                            ? 'text-[#0B6E4F] dark:text-emerald-300'
                            : 'text-amber-700 dark:text-amber-300'
                        }`}
                      >
                        {t.ads.paymentStatusLabel}: {t.ads.paymentStatuses[ad.paymentStatus]}
                      </span>
                      {ad.paymentReference && (
                        <>
                          <span aria-hidden="true" className="mx-2 text-slate-400">
                            ·
                          </span>
                          <span className="font-mono text-slate-800 dark:text-slate-200">
                            Ref: {ad.paymentReference}
                          </span>
                        </>
                      )}
                    </div>
                    <span className="text-slate-500 dark:text-slate-400">
                      {formatCount(ad.impressionsCount, language)} {t.ads.impressions} ·{' '}
                      {formatCount(ad.clicksCount, language)} {t.ads.clicks}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={note}
                      onChange={(e) =>
                        setNotesByAd((prev) => ({ ...prev, [ad.id]: e.target.value }))
                      }
                      placeholder={t.admin.monetization.adminNotePlaceholder}
                      className="min-h-[40px] px-3 py-1.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs"
                    />
                    <select
                      value={chosenMethod}
                      onChange={(e) =>
                        setMethodByAd((prev) => ({
                          ...prev,
                          [ad.id]: e.target.value as AdPaymentMethod,
                        }))
                      }
                      aria-label={t.admin.monetization.paymentMethodLabel}
                      className="min-h-[40px] px-3 py-1.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs"
                    >
                      <option value="manual_bkash">{t.ads.paymentMethods.manual_bkash}</option>
                      <option value="manual_nagad">{t.ads.paymentMethods.manual_nagad}</option>
                      <option value="bank_transfer">{t.ads.paymentMethods.bank_transfer}</option>
                      <option value="cash_office">{t.ads.paymentMethods.cash_office}</option>
                    </select>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        void adminConfirmAdPayment(ad.id, 'paid', chosenMethod, note)
                      }
                      className="min-h-[38px] px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{t.admin.monetization.confirmManualPayment}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => void adminUpdateAdModeration(ad.id, 'approved', note)}
                      className="min-h-[38px] px-3 py-1.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{t.admin.monetization.approveAndPublish}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => void adminUpdateAdModeration(ad.id, 'paused', note)}
                      className="min-h-[38px] px-3 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 cursor-pointer"
                    >
                      <PauseCircle className="w-3.5 h-3.5" />
                      <span>{t.admin.monetization.pauseAd}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => void adminUpdateAdModeration(ad.id, 'rejected', note)}
                      className="min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/30 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>{t.admin.monetization.rejectAd}</span>
                    </button>

                    {ad.paymentStatus === 'paid' && (
                      <button
                        type="button"
                        onClick={() =>
                          void adminConfirmAdPayment(ad.id, 'refunded', chosenMethod, note)
                        }
                        className="min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
                      >
                        {t.admin.monetization.markRefunded}
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => void adminDeleteLocalAd(ad.id)}
                      className="min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-1.5 ml-auto cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{t.admin.posts.delete}</span>
                    </button>
                  </div>
                </article>
              );
            })
          )}
        </div>
      )}

      {/* 2. PACKAGE PRICING & DURATION MANAGER */}
      {subtab === 'packages' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-7 space-y-2.5">
            {adPackages.map((pkg) => (
              <div
                key={pkg.id}
                className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <p className="font-semibold text-sm text-slate-900 dark:text-white">
                    {language === 'bn' ? pkg.nameBn : pkg.name}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums mt-0.5">
                    ৳{formatCount(pkg.priceBdt, language)} · {formatCount(pkg.durationDays, language)}{' '}
                    {t.ads.daysUnit} · {t.ads.placements[pkg.placement]} ·{' '}
                    {pkg.isActive ? t.admin.users.active : t.admin.posts.hidden}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => loadPackageForEdit(pkg)}
                    aria-label={t.admin.monetization.editPackage}
                    className="min-h-[38px] min-w-[38px] rounded-xl border border-emerald-950/10 dark:border-emerald-200/10 flex items-center justify-center text-slate-600 dark:text-slate-300 cursor-pointer"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => void adminDeleteAdPackage(pkg.id)}
                    aria-label={t.admin.posts.delete}
                    className="min-h-[38px] min-w-[38px] rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center justify-center cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <form
            onSubmit={(e) => void handleSavePackage(e)}
            className="lg:col-span-5 bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 space-y-3"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-[#0B6E4F] dark:text-emerald-400" />
                <span>
                  {editingPkgId
                    ? t.admin.monetization.editPackage
                    : t.admin.monetization.addPackage}
                </span>
              </h3>
              {editingPkgId && (
                <button
                  type="button"
                  onClick={resetPackageForm}
                  className="text-xs font-semibold text-slate-500 hover:underline cursor-pointer"
                >
                  {t.actions.cancel}
                </button>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.monetization.packageNameEn}
              </label>
              <input
                type="text"
                required
                value={pkgName}
                onChange={(e) => setPkgName(e.target.value)}
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.monetization.packageNameBn}
              </label>
              <input
                type="text"
                required
                value={pkgNameBn}
                onChange={(e) => setPkgNameBn(e.target.value)}
                className={inputClass}
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {t.admin.monetization.durationDays}
                </label>
                <input
                  type="number"
                  min={1}
                  max={365}
                  value={pkgDuration}
                  onChange={(e) => setPkgDuration(Number(e.target.value) || 7)}
                  className={inputClass}
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {t.admin.monetization.priceBdt}
                </label>
                <input
                  type="number"
                  min={0}
                  max={500000}
                  value={pkgPrice}
                  onChange={(e) => setPkgPrice(Number(e.target.value) || 0)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {t.admin.monetization.placementLabel}
                </label>
                <select
                  value={pkgPlacement}
                  onChange={(e) => setPkgPlacement(e.target.value as AdPlacement)}
                  className={inputClass}
                >
                  <option value="feed">{t.ads.placements.feed}</option>
                  <option value="sidebar">{t.ads.placements.sidebar}</option>
                  <option value="both">{t.ads.placements.both}</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  Order
                </label>
                <input
                  type="number"
                  min={0}
                  max={1000}
                  value={pkgSort}
                  onChange={(e) => setPkgSort(Number(e.target.value) || 1)}
                  className={inputClass}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.monetization.packageDescEn}
              </label>
              <input
                type="text"
                value={pkgDesc}
                onChange={(e) => setPkgDesc(e.target.value)}
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.monetization.packageDescBn}
              </label>
              <input
                type="text"
                value={pkgDescBn}
                onChange={(e) => setPkgDescBn(e.target.value)}
                className={inputClass}
              />
            </div>

            <label className="flex items-center justify-between py-1 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer">
              <span>{t.admin.locations.activeLabel}</span>
              <input
                type="checkbox"
                checked={pkgActive}
                onChange={(e) => setPkgActive(e.target.checked)}
                className="w-4 h-4 accent-[#0B6E4F]"
              />
            </label>

            <button
              type="submit"
              className="w-full min-h-[44px] rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold cursor-pointer"
            >
              {t.admin.monetization.savePackage}
            </button>
          </form>
        </div>
      )}

      {/* 3. ADMOB TEST ARCHITECTURE & PLACEMENT CONFIG */}
      {subtab === 'admobSettings' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-3">
            <div className="flex items-start gap-2.5">
              <Smartphone className="w-5 h-5 text-[#0B6E4F] dark:text-emerald-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h3 className="font-display text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                  {t.admin.monetization.admobArchitectureTitle}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {t.admin.monetization.admobArchitectureDesc}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
              <div className="rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] p-3 space-y-1.5">
                <p className="font-sans font-bold text-[#0B6E4F] dark:text-emerald-300">
                  Active Google Official Test IDs (Development)
                </p>
                <p>App ID: {GOOGLE_ADMOB_TEST_UNITS.appId}</p>
                <p>Banner: {GOOGLE_ADMOB_TEST_UNITS.bannerUnitId}</p>
                <p>Native: {GOOGLE_ADMOB_TEST_UNITS.nativeUnitId}</p>
                <p>Interstitial: {GOOGLE_ADMOB_TEST_UNITS.interstitialUnitId}</p>
              </div>

              <div className="rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] p-3 space-y-1.5">
                <p className="font-sans font-bold text-amber-700 dark:text-amber-300">
                  Future Android Production Placeholders
                </p>
                <p>App ID: {PRODUCTION_ADMOB_PLACEHOLDERS.appId}</p>
                <p>Banner: {PRODUCTION_ADMOB_PLACEHOLDERS.bannerUnitId}</p>
                <p>Native: {PRODUCTION_ADMOB_PLACEHOLDERS.nativeUnitId}</p>
                <p>Interstitial: {PRODUCTION_ADMOB_PLACEHOLDERS.interstitialUnitId}</p>
              </div>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>{t.admin.monetization.testIdsNotice}</span>
            </p>
          </div>

          <form
            onSubmit={(e) => void handleSaveConfig(e)}
            className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-3"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t.admin.monetization.admobEnvLabel}
                </label>
                <select
                  value={cfgDraft.admobEnvironment}
                  onChange={(e) =>
                    setCfgDraft((prev) => ({
                      ...prev,
                      admobEnvironment: e.target.value as 'development_test' | 'production_ready',
                    }))
                  }
                  className={inputClass}
                >
                  <option value="development_test">{t.admin.monetization.devTestMode}</option>
                  <option value="production_ready">{t.admin.monetization.prodReadyMode}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t.admin.monetization.feedIntervalLabel}
                </label>
                <input
                  type="number"
                  min={2}
                  max={20}
                  value={cfgDraft.feedAdInterval}
                  onChange={(e) =>
                    setCfgDraft((prev) => ({
                      ...prev,
                      feedAdInterval: Math.min(20, Math.max(2, Number(e.target.value) || 4)),
                    }))
                  }
                  className={inputClass}
                />
              </div>
            </div>

            <div className="divide-y divide-emerald-950/10 dark:divide-emerald-200/10">
              <label className="py-2.5 flex items-center justify-between text-sm font-medium cursor-pointer">
                <span>{t.admin.monetization.localAdsToggle}</span>
                <input
                  type="checkbox"
                  checked={cfgDraft.localAdsEnabled}
                  onChange={(e) =>
                    setCfgDraft((prev) => ({ ...prev, localAdsEnabled: e.target.checked }))
                  }
                  className="w-5 h-5 accent-[#0B6E4F]"
                />
              </label>
              <label className="py-2.5 flex items-center justify-between text-sm font-medium cursor-pointer">
                <span>{t.admin.monetization.bannerToggle}</span>
                <input
                  type="checkbox"
                  checked={cfgDraft.admobBannerEnabled}
                  onChange={(e) =>
                    setCfgDraft((prev) => ({ ...prev, admobBannerEnabled: e.target.checked }))
                  }
                  className="w-5 h-5 accent-[#0B6E4F]"
                />
              </label>
              <label className="py-2.5 flex items-center justify-between text-sm font-medium cursor-pointer">
                <span>{t.admin.monetization.nativeToggle}</span>
                <input
                  type="checkbox"
                  checked={cfgDraft.admobNativeEnabled}
                  onChange={(e) =>
                    setCfgDraft((prev) => ({ ...prev, admobNativeEnabled: e.target.checked }))
                  }
                  className="w-5 h-5 accent-[#0B6E4F]"
                />
              </label>
              <label className="py-2.5 flex items-center justify-between text-sm font-medium cursor-pointer">
                <span>{t.admin.monetization.requireConsentToggle}</span>
                <input
                  type="checkbox"
                  checked={cfgDraft.requireAdConsent}
                  onChange={(e) =>
                    setCfgDraft((prev) => ({ ...prev, requireAdConsent: e.target.checked }))
                  }
                  className="w-5 h-5 accent-[#0B6E4F]"
                />
              </label>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t.admin.monetization.paymentInstructionsEn}
              </label>
              <textarea
                rows={2}
                maxLength={500}
                value={cfgDraft.manualPaymentInstructionsEn}
                onChange={(e) =>
                  setCfgDraft((prev) => ({
                    ...prev,
                    manualPaymentInstructionsEn: e.target.value,
                  }))
                }
                className="w-full px-3 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t.admin.monetization.paymentInstructionsBn}
              </label>
              <textarea
                rows={2}
                maxLength={500}
                value={cfgDraft.manualPaymentInstructionsBn}
                onChange={(e) =>
                  setCfgDraft((prev) => ({
                    ...prev,
                    manualPaymentInstructionsBn: e.target.value,
                  }))
                }
                className="w-full px-3 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm"
              />
            </div>

            <button
              type="submit"
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold cursor-pointer"
            >
              {t.admin.monetization.saveConfig}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
