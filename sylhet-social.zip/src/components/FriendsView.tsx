import React, { useState } from 'react';
import { Check, MessageCircle, UserCheck, UserMinus, UserPlus, X } from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { formatCount, getDisplayLocation, getDisplayName } from '../utils/formatters';
import { Avatar } from './Avatar';

type FriendsSubTab = 'friends' | 'requests' | 'followers' | 'following' | 'discover';

export const FriendsView: React.FC = () => {
  const {
    t,
    language,
    currentUser,
    users,
    openProfile,
    openChatWith,
    sendFriendRequest,
    acceptFriendRequest,
    declineFriendRequest,
    removeFriend,
    toggleFollow,
  } = useSocial();

  const [subTab, setSubTab] = useState<FriendsSubTab>(
    currentUser && currentUser.friendRequestsReceived.length > 0 ? 'requests' : 'friends'
  );

  if (!currentUser) return null;

  const otherUsers = users.filter((u) => u.uid !== currentUser.uid);
  const friendsList = otherUsers.filter((u) => currentUser.friends.includes(u.uid));
  const requestsList = otherUsers.filter((u) =>
    currentUser.friendRequestsReceived.includes(u.uid)
  );
  const followersList = otherUsers.filter((u) => currentUser.followers.includes(u.uid));
  const followingList = otherUsers.filter((u) => currentUser.following.includes(u.uid));
  const discoverList = otherUsers.filter(
    (u) =>
      !currentUser.friends.includes(u.uid) &&
      !currentUser.friendRequestsReceived.includes(u.uid)
  );

  const tabs: { id: FriendsSubTab; label: string; count: number }[] = [
    { id: 'friends', label: t.friendsPage.allFriends, count: friendsList.length },
    { id: 'requests', label: t.friendsPage.requests, count: requestsList.length },
    { id: 'followers', label: t.friendsPage.followers, count: followersList.length },
    { id: 'following', label: t.friendsPage.following, count: followingList.length },
    { id: 'discover', label: t.friendsPage.discover, count: discoverList.length },
  ];

  const activeList =
    subTab === 'friends'
      ? friendsList
      : subTab === 'requests'
      ? requestsList
      : subTab === 'followers'
      ? followersList
      : subTab === 'following'
      ? followingList
      : discoverList;

  return (
    <div className="space-y-4">
      <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5">
        <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white mb-3">
          {t.nav.friends}
        </h1>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {tabs.map((tab) => {
            const active = subTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setSubTab(tab.id)}
                className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  active
                    ? 'bg-[#0B6E4F] text-white'
                    : 'bg-[#F4F6F4] dark:bg-[#0D1512] text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`text-xs tabular-nums ${
                    active ? 'text-emerald-100' : 'text-slate-400'
                  }`}
                >
                  {formatCount(tab.count, language)}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {activeList.length === 0 ? (
        <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-10 text-center text-sm text-slate-500 dark:text-slate-400">
          {subTab === 'requests' ? t.friendsPage.noRequests : t.friendsPage.noFriends}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {activeList.map((person) => {
            const isFriend = currentUser.friends.includes(person.uid);
            const isRequested = currentUser.friendRequestsSent.includes(person.uid);
            const hasIncoming = currentUser.friendRequestsReceived.includes(person.uid);
            const isFollowing = currentUser.following.includes(person.uid);
            const displayName = getDisplayName(person, language);

            return (
              <div
                key={person.uid}
                className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 flex flex-col justify-between gap-4"
              >
                <div className="flex items-start gap-3">
                  <button
                    type="button"
                    onClick={() => openProfile(person.uid)}
                    className="shrink-0 cursor-pointer"
                  >
                    <Avatar
                      src={person.avatarUrl}
                      name={displayName}
                      size="lg"
                      showOnline
                      isOnline={person.isOnline}
                    />
                  </button>
                  <div className="min-w-0 flex-1">
                    <button
                      type="button"
                      onClick={() => openProfile(person.uid)}
                      className="font-semibold text-base text-slate-900 dark:text-white hover:underline text-left truncate block w-full cursor-pointer"
                    >
                      {displayName}
                    </button>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {getDisplayLocation(person, language)}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
                      {formatCount(person.friendsCount, language)} {t.profile.friends} ·{' '}
                      {formatCount(person.followersCount, language)} {t.profile.followers}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {hasIncoming ? (
                    <>
                      <button
                        type="button"
                        onClick={() => void acceptFriendRequest(person.uid)}
                        className="flex-1 min-h-[42px] px-3 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                        <span>{t.actions.accept}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => void declineFriendRequest(person.uid)}
                        className="min-h-[42px] px-3 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                        <span>{t.actions.decline}</span>
                      </button>
                    </>
                  ) : isFriend ? (
                    <>
                      <button
                        type="button"
                        onClick={() => void openChatWith(person.uid)}
                        className="flex-1 min-h-[42px] px-3 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>{t.actions.message}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => void removeFriend(person.uid)}
                        aria-label={t.actions.unfriend}
                        className="min-h-[42px] px-3 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-1 cursor-pointer"
                      >
                        <UserMinus className="w-4 h-4" />
                        <span>{t.actions.unfriend}</span>
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        type="button"
                        disabled={isRequested}
                        onClick={() => void sendFriendRequest(person.uid)}
                        className="flex-1 min-h-[42px] px-3 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] disabled:opacity-60 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        {isRequested ? (
                          <>
                            <UserCheck className="w-4 h-4" />
                            <span>{t.actions.requested}</span>
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-4 h-4" />
                            <span>{t.actions.addFriend}</span>
                          </>
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => void toggleFollow(person.uid)}
                        className={`min-h-[42px] px-3 py-2 rounded-xl border text-xs font-semibold cursor-pointer ${
                          isFollowing
                            ? 'border-emerald-700/30 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300'
                            : 'border-emerald-950/15 dark:border-emerald-200/15 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5'
                        }`}
                      >
                        {isFollowing ? t.actions.following : t.actions.follow}
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
