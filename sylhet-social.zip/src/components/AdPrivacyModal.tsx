import React from 'react';
import { Check, Shield, ShieldCheck, X } from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { AdConsentStatus } from '../types/social';

export const AdConsentBanner: React.FC = () => {
  const {
    t,
    monetizationConfig,
    adConsentStatus,
    updateAdConsent,
    setAdPrivacyModalOpen,
  } = useSocial();

  if (!monetizationConfig.requireAdConsent || adConsentStatus !== 'unset') {
    return null;
  }

  return (
    <div
      role="region"
      aria-label={t.consent.bannerTitle}
      className="fixed bottom-18 md:bottom-4 left-3 right-3 md:left-auto md:right-5 md:max-w-md z-40 bg-white dark:bg-[#14201B] border border-emerald-950/15 dark:border-emerald-200/20 rounded-2xl shadow-xl p-4 space-y-3"
    >
      <div className="flex items-start gap-2.5">
        <ShieldCheck className="w-5 h-5 text-[#0B6E4F] dark:text-emerald-400 shrink-0 mt-0.5" />
        <div className="space-y-1 min-w-0">
          <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
            {t.consent.bannerTitle}
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            {t.consent.bannerBody}
          </p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => void updateAdConsent('personalized')}
          className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold cursor-pointer"
        >
          {t.consent.acceptPersonalized}
        </button>
        <button
          type="button"
          onClick={() => void updateAdConsent('non_personalized')}
          className="min-h-[40px] px-3 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 cursor-pointer"
        >
          {t.consent.useNonPersonalized}
        </button>
        <button
          type="button"
          onClick={() => void updateAdConsent('essential_only')}
          className="min-h-[36px] px-2.5 py-1 rounded-lg text-[11px] font-medium text-slate-500 dark:text-slate-400 hover:underline cursor-pointer"
        >
          {t.consent.essentialOnly}
        </button>
        <button
          type="button"
          onClick={() => setAdPrivacyModalOpen(true)}
          className="min-h-[36px] px-2 py-1 rounded-lg text-[11px] font-semibold text-[#0B6E4F] dark:text-emerald-300 hover:underline cursor-pointer ml-auto"
        >
          {t.consent.privacyLink}
        </button>
      </div>
    </div>
  );
};

export const AdPrivacyModal: React.FC = () => {
  const {
    t,
    adPrivacyModalOpen,
    setAdPrivacyModalOpen,
    adConsentStatus,
    updateAdConsent,
  } = useSocial();

  if (!adPrivacyModalOpen) return null;

  const choices: { value: Exclude<AdConsentStatus, 'unset'>; label: string }[] = [
    { value: 'personalized', label: t.consent.choices.personalized },
    { value: 'non_personalized', label: t.consent.choices.non_personalized },
    { value: 'essential_only', label: t.consent.choices.essential_only },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="ad-privacy-modal-title"
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="bg-white dark:bg-[#14201B] border border-emerald-950/15 dark:border-emerald-200/15 rounded-2xl w-full max-w-lg max-h-[88vh] overflow-y-auto p-5 sm:p-6 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0B6E4F] dark:text-emerald-300 flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2
                id="ad-privacy-modal-title"
                className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white"
              >
                {t.consent.modalTitle}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t.consent.modalSubtitle}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setAdPrivacyModalOpen(false)}
            aria-label={t.actions.cancel}
            className="min-w-[40px] min-h-[40px] rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] p-3.5 space-y-2.5">
          <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
            {t.consent.currentChoiceLabel}:{' '}
            <span className="text-[#0B6E4F] dark:text-emerald-300">
              {t.consent.choices[adConsentStatus]}
            </span>
          </p>

          <div className="grid grid-cols-1 gap-2">
            {choices.map((opt) => {
              const selected = adConsentStatus === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => void updateAdConsent(opt.value)}
                  className={`min-h-[44px] px-3.5 py-2 rounded-xl border text-left text-xs sm:text-sm font-medium flex items-center justify-between gap-2 cursor-pointer transition-colors ${
                    selected
                      ? 'bg-[#0B6E4F] text-white border-[#0B6E4F]'
                      : 'bg-white dark:bg-[#14201B] text-slate-800 dark:text-slate-200 border-emerald-950/10 dark:border-emerald-200/10 hover:bg-emerald-50/60 dark:hover:bg-white/5'
                  }`}
                >
                  <span>{opt.label}</span>
                  {selected && <Check className="w-4 h-4 shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          <div className="space-y-1">
            <h3 className="font-semibold text-slate-900 dark:text-white">
              {t.consent.googleAdmobPolicyTitle}
            </h3>
            <p>{t.consent.googleAdmobPolicyBody}</p>
          </div>
          <div className="space-y-1">
            <h3 className="font-semibold text-slate-900 dark:text-white">
              {t.consent.localAdsPolicyTitle}
            </h3>
            <p>{t.consent.localAdsPolicyBody}</p>
          </div>
          <div className="space-y-1">
            <h3 className="font-semibold text-slate-900 dark:text-white">
              {t.consent.noAutoChargeTitle}
            </h3>
            <p>{t.consent.noAutoChargeBody}</p>
          </div>
        </div>

        <div className="flex justify-end pt-1">
          <button
            type="button"
            onClick={() => setAdPrivacyModalOpen(false)}
            className="min-h-[44px] px-5 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold cursor-pointer"
          >
            OK
          </button>
        </div>
      </div>
    </div>
  );
};
