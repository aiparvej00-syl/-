import React, { useMemo, useState } from 'react';
import { Bookmark, Compass, Film, Image as ImageIcon, Megaphone, Sparkles, Users } from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { PostComposer } from './PostComposer';
import { PostCard } from './PostCard';
import { AdMobTestSlot, SponsoredAdCard } from './SponsoredAdCard';

type FeedFilter = 'all' | 'photo' | 'video' | 'friends' | 'saved';

export const NewsFeedView: React.FC = () => {
  const {
    t,
    language,
    posts,
    currentUser,
    isAdmin,
    adminVerified,
    appSettings,
    savedPostIds,
    activeLocalAds,
    monetizationConfig,
    setActiveTab,
    adminSeedStarterPosts,
  } = useSocial();
  const [filter, setFilter] = useState<FeedFilter>('all');

  const feedLocalAds = useMemo(
    () =>
      activeLocalAds.filter(
        (ad) => ad.placement === 'feed' || ad.placement === 'both'
      ),
    [activeLocalAds]
  );

  const feedInterval = Math.max(2, monetizationConfig.feedAdInterval || 4);

  const visiblePosts = useMemo(
    () =>
      posts.filter(
        (p) =>
          p.moderationStatus === 'approved' ||
          p.authorId === currentUser?.uid
      ),
    [posts, currentUser]
  );

  const filteredPosts = useMemo(() => {
    switch (filter) {
      case 'photo':
        return visiblePosts.filter((p) => p.mediaType === 'photo');
      case 'video':
        return visiblePosts.filter((p) => p.mediaType === 'video');
      case 'friends':
        if (!currentUser) return visiblePosts;
        return visiblePosts.filter(
          (p) => p.authorId === currentUser.uid || currentUser.friends.includes(p.authorId)
        );
      case 'saved':
        return visiblePosts.filter((p) => savedPostIds.includes(p.id));
      default:
        return visiblePosts;
    }
  }, [visiblePosts, filter, currentUser, savedPostIds]);

  const filterTabs: { id: FeedFilter; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: t.feed.allPosts, icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'photo', label: t.feed.photos, icon: <ImageIcon className="w-3.5 h-3.5" /> },
    { id: 'video', label: t.feed.videos, icon: <Film className="w-3.5 h-3.5" /> },
    { id: 'friends', label: t.feed.friendsOnly, icon: <Users className="w-3.5 h-3.5" /> },
    { id: 'saved', label: t.nav.saved, icon: <Bookmark className="w-3.5 h-3.5" /> },
  ];

  const bannerText =
    language === 'bn' ? appSettings.featuredBannerBn : appSettings.featuredBannerEn;

  return (
    <div className="space-y-4">
      {bannerText && (
        <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-2.5">
          <p className="text-xs sm:text-sm font-medium text-emerald-900 dark:text-emerald-200">
            {bannerText}
          </p>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('explore')}
              className="min-h-[36px] px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-[#0B6E4F] dark:text-emerald-300 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>{t.nav.explore}</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('advertise')}
              className="min-h-[36px] px-3 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Megaphone className="w-3.5 h-3.5 text-[#0B6E4F] dark:text-emerald-400" />
              <span>{t.nav.advertise}</span>
            </button>
          </div>
        </div>
      )}

      <PostComposer />

      <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-1.5 flex items-center gap-1 overflow-x-auto">
        {filterTabs.map((tab) => {
          const active = filter === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilter(tab.id)}
              className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                active
                  ? 'bg-[#0B6E4F] text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {filteredPosts.length === 0 ? (
        <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-10 text-center space-y-4">
          <p className="text-sm text-slate-500 dark:text-slate-400">{t.feed.noPostsFound}</p>
          {isAdmin && adminVerified && visiblePosts.length === 0 && (
            <button
              type="button"
              onClick={() => void adminSeedStarterPosts()}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold cursor-pointer"
            >
              {t.admin.settings.seedStarterPosts}
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredPosts.map((post, idx) => {
            const slotNumber = idx + 1;
            const shouldInsertSlot = slotNumber % feedInterval === 0;
            const slotIndex = Math.floor(slotNumber / feedInterval) - 1;
            const adForSlot =
              feedLocalAds.length > 0 ? feedLocalAds[slotIndex % feedLocalAds.length] : null;

            return (
              <React.Fragment key={post.id}>
                <PostCard post={post} />
                {shouldInsertSlot && (
                  <>
                    {adForSlot && <SponsoredAdCard ad={adForSlot} />}
                    {!adForSlot && slotIndex === 0 && <AdMobTestSlot variant="native" />}
                  </>
                )}
              </React.Fragment>
            );
          })}
          {filteredPosts.length > 0 && <AdMobTestSlot variant="banner" />}
        </div>
      )}
    </div>
  );
};
