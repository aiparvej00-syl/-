import React, { useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  ImagePlus,
  Megaphone,
  PauseCircle,
  Send,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react';
import { ASSET_IMAGES } from '../data/seedData';
import { useSocial } from '../context/SocialContext';
import {
  AdCategory,
  AdCtaLabel,
  AdPaymentMethod,
} from '../types/social';
import { formatCount } from '../utils/formatters';
import { compressImageToDataUrl } from '../utils/media';
import { HierarchicalLocationSelect } from './HierarchicalLocationSelect';

const PRESET_BUSINESS_PHOTOS = [
  { id: 'tea', labelEn: 'Sylhet Tea Valley', labelBn: 'সিলেট চা-বাগান', url: ASSET_IMAGES.teaGardenCover },
  { id: 'keane', labelEn: 'Surma & City Center', labelBn: 'সুরমা ও শহর এলাকা', url: ASSET_IMAGES.keaneBridge },
  { id: 'madhabpur', labelEn: 'Sreemangal & Lakeside', labelBn: 'শ্রীমঙ্গল ও লেক', url: ASSET_IMAGES.madhabpurLake },
  { id: 'manipuri', labelEn: 'Local Craft & Heritage', labelBn: 'স্থানীয় ঐতিহ্য ও পণ্য', url: ASSET_IMAGES.manipuriPara },
];

const CATEGORIES: AdCategory[] = [
  'restaurant',
  'hotel_resort',
  'retail',
  'education',
  'healthcare',
  'tech_services',
  'tourism',
  'real_estate',
  'other',
];

const CTAS: AdCtaLabel[] = ['call_now', 'whatsapp', 'visit_website', 'learn_more'];

export const LocalAdsPortalView: React.FC = () => {
  const {
    t,
    language,
    adPackages,
    adPackagesSyncedToFirestore,
    myLocalAds,
    monetizationConfig,
    submitLocalAd,
    submitAdPaymentReference,
    pauseOwnAd,
    deleteOwnUnpaidAd,
    setAdPrivacyModalOpen,
  } = useSocial();

  const [subtab, setSubtab] = useState<'submit' | 'my_ads'>('submit');
  const [submitting, setSubmitting] = useState(false);

  const activePackages = useMemo(
    () => adPackages.filter((p) => p.isActive),
    [adPackages]
  );

  const [businessName, setBusinessName] = useState('');
  const [category, setCategory] = useState<AdCategory>('restaurant');
  const [title, setTitle] = useState('');
  const [titleBn, setTitleBn] = useState('');
  const [description, setDescription] = useState('');
  const [descriptionBn, setDescriptionBn] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [ctaLabel, setCtaLabel] = useState<AdCtaLabel>('call_now');
  const [locationPair, setLocationPair] = useState<{ en: string; bn: string }>({
    en: 'Zindabazar, Sylhet',
    bn: 'জিন্দাবাজার, সিলেট',
  });
  const [selectedPackageId, setSelectedPackageId] = useState<string>(
    activePackages[0]?.id || 'pkg_starter_7d'
  );
  const [formError, setFormError] = useState<string | null>(null);

  const [paymentMethodsByAd, setPaymentMethodsByAd] = useState<Record<string, AdPaymentMethod>>({});
  const [paymentRefsByAd, setPaymentRefsByAd] = useState<Record<string, string>>({});

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const chosenPkg =
    activePackages.find((p) => p.id === selectedPackageId) || activePackages[0];

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageToDataUrl(file, 960, 0.76);
      setImageUrl(compressed);
    } catch {
      setFormError(
        language === 'bn'
          ? 'ছবিটি প্রসেস করা যায়নি। অনুগ্রহ করে অন্য ছবি বেছে নিন।'
          : 'Could not process selected image.'
      );
    }
    e.target.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (businessName.trim().length < 2) {
      setFormError(
        language === 'bn'
          ? 'প্রতিষ্ঠানের নাম কমপক্ষে ২ অক্ষরের হতে হবে।'
          : 'Business name must be at least 2 characters.'
      );
      return;
    }
    if (title.trim().length < 3) {
      setFormError(
        language === 'bn'
          ? 'বিজ্ঞাপনের শিরোনাম কমপক্ষে ৩ অক্ষরের হতে হবে।'
          : 'Ad headline must be at least 3 characters.'
      );
      return;
    }
    if (description.trim().length < 10) {
      setFormError(
        language === 'bn'
          ? 'বিবরণ কমপক্ষে ১০ অক্ষরের হতে হবে।'
          : 'Offer description must be at least 10 characters.'
      );
      return;
    }
    if (contactPhone.trim().length < 6) {
      setFormError(
        language === 'bn'
          ? 'সঠিক যোগাযোগের ফোন নম্বর দিন।'
          : 'Enter a valid contact phone number (at least 6 characters).'
      );
      return;
    }
    if (!chosenPkg) return;

    setSubmitting(true);
    const ok = await submitLocalAd({
      businessName,
      category,
      title,
      titleBn: titleBn.trim() || undefined,
      description,
      descriptionBn: descriptionBn.trim() || undefined,
      imageUrl: imageUrl || undefined,
      contactPhone,
      whatsappNumber: whatsappNumber.trim() || undefined,
      contactEmail: contactEmail.trim() || undefined,
      websiteUrl: websiteUrl.trim() || undefined,
      ctaLabel,
      location: locationPair.en,
      locationBn: locationPair.bn,
      packageId: chosenPkg.id,
    });
    setSubmitting(false);

    if (ok) {
      setBusinessName('');
      setTitle('');
      setTitleBn('');
      setDescription('');
      setDescriptionBn('');
      setImageUrl('');
      setContactPhone('');
      setWhatsappNumber('');
      setContactEmail('');
      setWebsiteUrl('');
      setSubtab('my_ads');
    }
  };

  const manualNote =
    language === 'bn'
      ? monetizationConfig.manualPaymentInstructionsBn
      : monetizationConfig.manualPaymentInstructionsEn;

  const inputClass =
    'w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700';

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-[#0B6E4F] dark:text-emerald-400">
              <Megaphone className="w-5 h-5" />
              <span className="text-xs font-bold uppercase tracking-wider">
                {t.sponsoredCard.sponsored}
              </span>
            </div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {t.ads.portalTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {t.ads.portalSubtitle}
            </p>
          </div>

          <button
            type="button"
            onClick={() => setAdPrivacyModalOpen(true)}
            className="min-h-[40px] px-3.5 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-1.5 shrink-0 cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-[#0B6E4F] dark:text-emerald-400" />
            <span>{t.consent.privacyLink}</span>
          </button>
        </div>

        {/* Sub-navigation */}
        <div className="flex items-center gap-2 pt-1">
          <button
            type="button"
            onClick={() => setSubtab('submit')}
            className={`min-h-[42px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold cursor-pointer transition-colors ${
              subtab === 'submit'
                ? 'bg-[#0B6E4F] text-white'
                : 'bg-[#F4F6F4] dark:bg-[#0D1512] text-slate-700 dark:text-slate-200'
            }`}
          >
            {t.ads.submitTab}
          </button>
          <button
            type="button"
            onClick={() => setSubtab('my_ads')}
            className={`min-h-[42px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5 cursor-pointer transition-colors ${
              subtab === 'my_ads'
                ? 'bg-[#0B6E4F] text-white'
                : 'bg-[#F4F6F4] dark:bg-[#0D1512] text-slate-700 dark:text-slate-200'
            }`}
          >
            <span>{t.ads.myAdsTab}</span>
            {myLocalAds.length > 0 && (
              <span className="tabular-nums opacity-85">
                ({formatCount(myLocalAds.length, language)})
              </span>
            )}
          </button>
        </div>
      </section>

      {/* Transparent Pricing & Duration Packages */}
      <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-display text-sm sm:text-base font-bold text-slate-900 dark:text-white">
            {t.ads.packagesTitle}
          </h2>
          {!adPackagesSyncedToFirestore && (
            <span className="text-[11px] font-medium text-amber-700 dark:text-amber-300">
              {language === 'bn' ? 'ডিফল্ট প্রদর্শিত' : 'Preview Tiers'}
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {activePackages.map((pkg) => {
            const isSelected = chosenPkg?.id === pkg.id;
            return (
              <button
                key={pkg.id}
                type="button"
                onClick={() => {
                  setSelectedPackageId(pkg.id);
                  setSubtab('submit');
                }}
                className={`p-3.5 rounded-xl border text-left space-y-1.5 transition-colors cursor-pointer ${
                  isSelected
                    ? 'border-[#0B6E4F] bg-emerald-50/70 dark:bg-emerald-950/35'
                    : 'border-emerald-950/10 dark:border-emerald-200/10 bg-[#F8FAF8] dark:bg-[#0F1915] hover:border-[#0B6E4F]/50'
                }`}
              >
                <div className="flex items-baseline justify-between gap-2">
                  <p className="text-xs font-bold text-slate-900 dark:text-white">
                    {language === 'bn' ? pkg.nameBn : pkg.name}
                  </p>
                  <p className="font-display text-base font-bold text-[#0B6E4F] dark:text-emerald-300 tabular-nums shrink-0">
                    ৳{formatCount(pkg.priceBdt, language)}
                  </p>
                </div>
                <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 tabular-nums">
                  {formatCount(pkg.durationDays, language)} {t.ads.daysUnit} ·{' '}
                  {t.ads.placements[pkg.placement]}
                </p>
                {(pkg.description || pkg.descriptionBn) && (
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-snug">
                    {language === 'bn' ? pkg.descriptionBn || pkg.description : pkg.description}
                  </p>
                )}
              </button>
            );
          })}
        </div>
      </section>

      {subtab === 'submit' ? (
        <form
          onSubmit={(e) => void handleSubmit(e)}
          className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-4"
        >
          {/* Honest Manual Payment Notice */}
          <div className="rounded-xl border border-amber-600/25 dark:border-amber-400/20 bg-amber-50/70 dark:bg-amber-950/25 p-3.5 flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-amber-700 dark:text-amber-300 shrink-0 mt-0.5" />
            <div className="space-y-1 text-xs">
              <p className="font-bold text-amber-900 dark:text-amber-200">
                {t.ads.manualPaymentNoticeTitle}
              </p>
              <p className="text-amber-800 dark:text-amber-200/90 leading-relaxed">
                {manualNote}
              </p>
            </div>
          </div>

          {formError && (
            <div className="rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-300 dark:border-rose-800/40 px-3.5 py-2.5 text-xs font-medium text-rose-700 dark:text-rose-200">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.businessName} *
              </label>
              <input
                type="text"
                required
                maxLength={100}
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder={language === 'bn' ? 'যেমন: সুরমা ভ্যালি কিচেন' : 'e.g. Surma Valley Kitchen'}
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.categoryLabel} *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as AdCategory)}
                className={inputClass}
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {t.ads.categories[cat]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.titleEn} *
              </label>
              <input
                type="text"
                required
                maxLength={140}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Weekend Family Tea Platter - 20% Off"
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.titleBn}
              </label>
              <input
                type="text"
                maxLength={160}
                value={titleBn}
                onChange={(e) => setTitleBn(e.target.value)}
                placeholder="সপ্তাহান্তে পরিবার নিয়ে ২০% ছাড়ে চা-আড্ডা"
                className={inputClass}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.descEn} *
              </label>
              <textarea
                rows={3}
                required
                maxLength={600}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Fresh Sylheti dishes near Keane Bridge. Open daily 11 AM - 11 PM."
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.descBn}
              </label>
              <textarea
                rows={3}
                maxLength={600}
                value={descriptionBn}
                onChange={(e) => setDescriptionBn(e.target.value)}
                placeholder="ক্বিন ব্রিজের পাশে ঐতিহ্যবাহী সিলেটি খাবার..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
              />
            </div>
          </div>

          {/* Image Upload or Curated Sylhet Preset */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              {t.ads.imageLabel}
            </label>
            <div className="flex flex-wrap items-center gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={(e) => void handleImageUpload(e)}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="min-h-[42px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 cursor-pointer"
              >
                <ImagePlus className="w-4 h-4 text-[#0B6E4F] dark:text-emerald-400" />
                <span>{t.ads.uploadBanner}</span>
              </button>

              <select
                value=""
                onChange={(e) => {
                  if (e.target.value) setImageUrl(e.target.value);
                }}
                aria-label={t.ads.useSamplePhoto}
                className="min-h-[42px] px-3 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs text-slate-700 dark:text-slate-200"
              >
                <option value="">{t.ads.useSamplePhoto}</option>
                {PRESET_BUSINESS_PHOTOS.map((preset) => (
                  <option key={preset.id} value={preset.url}>
                    {language === 'bn' ? preset.labelBn : preset.labelEn}
                  </option>
                ))}
              </select>

              {imageUrl && (
                <button
                  type="button"
                  onClick={() => setImageUrl('')}
                  className="min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 flex items-center gap-1 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>{t.actions.removeMedia}</span>
                </button>
              )}
            </div>

            {imageUrl && (
              <img
                src={imageUrl}
                alt="Ad preview"
                referrerPolicy="no-referrer"
                className="w-full max-h-56 object-cover rounded-xl border border-emerald-950/10 dark:border-emerald-200/10"
              />
            )}
          </div>

          {/* Business Contacts & CTA */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.phoneLabel} *
              </label>
              <input
                type="tel"
                required
                maxLength={40}
                value={contactPhone}
                onChange={(e) => setContactPhone(e.target.value)}
                placeholder="+880 1711-000000"
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.whatsappLabel}
              </label>
              <input
                type="tel"
                maxLength={40}
                value={whatsappNumber}
                onChange={(e) => setWhatsappNumber(e.target.value)}
                placeholder="+880 1711-000000"
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.emailLabel}
              </label>
              <input
                type="email"
                maxLength={160}
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                placeholder="hello@business-sylhet.bd"
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.websiteLabel}
              </label>
              <input
                type="text"
                maxLength={300}
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
                placeholder="https://example.com"
                className={inputClass}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.ctaLabel}
              </label>
              <select
                value={ctaLabel}
                onChange={(e) => setCtaLabel(e.target.value as AdCtaLabel)}
                className={inputClass}
              >
                {CTAS.map((cta) => (
                  <option key={cta} value={cta}>
                    {t.ads.ctas[cta]}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.ads.packageLabel}
              </label>
              <select
                value={chosenPkg?.id || ''}
                onChange={(e) => setSelectedPackageId(e.target.value)}
                className={inputClass}
              >
                {activePackages.map((pkg) => (
                  <option key={pkg.id} value={pkg.id}>
                    {language === 'bn' ? pkg.nameBn : pkg.name} — ৳{pkg.priceBdt} ({pkg.durationDays}{' '}
                    {t.ads.daysUnit})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Hierarchical Location Picker */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              {t.ads.locationTitle}
            </label>
            <HierarchicalLocationSelect
              valueEn={locationPair.en}
              valueBn={locationPair.bn}
              onChange={(loc) => {
                if (loc) setLocationPair(loc);
              }}
              compact
            />
          </div>

          <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
            {chosenPkg && (
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300 tabular-nums">
                {language === 'bn' ? 'নির্বাচিত ফি:' : 'Selected package fee:'}{' '}
                <strong className="text-[#0B6E4F] dark:text-emerald-300">
                  ৳{formatCount(chosenPkg.priceBdt, language)}
                </strong>{' '}
                · {formatCount(chosenPkg.durationDays, language)} {t.ads.daysUnit}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="min-h-[46px] px-5 py-2.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] disabled:opacity-50 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{t.ads.submitAdBtn}</span>
            </button>
          </div>
        </form>
      ) : (
        /* My Campaigns & Manual Payment Status Tracker */
        <div className="space-y-3">
          {myLocalAds.length === 0 ? (
            <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-8 text-center text-sm text-slate-500 dark:text-slate-400">
              {t.ads.noMyAds}
            </div>
          ) : (
            myLocalAds.map((ad) => {
              const method = paymentMethodsByAd[ad.id] || 'manual_bkash';
              const refText = paymentRefsByAd[ad.id] ?? ad.paymentReference ?? '';
              const canSubmitProof =
                ad.paymentStatus === 'unpaid' || ad.paymentStatus === 'pending_verification';

              return (
                <article
                  key={ad.id}
                  className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
                        {ad.businessName} — {language === 'bn' && ad.titleBn ? ad.titleBn : ad.title}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums mt-0.5">
                        {ad.packageName} · ৳{formatCount(ad.priceBdt, language)} ·{' '}
                        {formatCount(ad.durationDays, language)} {t.ads.daysUnit} ·{' '}
                        {language === 'bn' && ad.locationBn ? ad.locationBn : ad.location}
                      </p>
                    </div>

                    <div className="text-left sm:text-right text-xs space-y-0.5 shrink-0 tabular-nums">
                      <p className="font-semibold text-slate-700 dark:text-slate-200">
                        {t.ads.reviewStatusLabel}:{' '}
                        <span
                          className={
                            ad.status === 'approved'
                              ? 'text-[#0B6E4F] dark:text-emerald-300'
                              : ad.status === 'rejected'
                              ? 'text-rose-600 dark:text-rose-400'
                              : 'text-amber-700 dark:text-amber-300'
                          }
                        >
                          {t.ads.statuses[ad.status]}
                        </span>
                      </p>
                      <p className="font-semibold text-slate-700 dark:text-slate-200">
                        {t.ads.paymentStatusLabel}:{' '}
                        <span
                          className={
                            ad.paymentStatus === 'paid'
                              ? 'text-[#0B6E4F] dark:text-emerald-300'
                              : 'text-amber-700 dark:text-amber-300'
                          }
                        >
                          {t.ads.paymentStatuses[ad.paymentStatus]}
                        </span>
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 dark:text-slate-300 tabular-nums pt-1 border-t border-emerald-950/10 dark:border-emerald-200/10">
                    <span>
                      {t.ads.performanceLabel}:{' '}
                      <strong>{formatCount(ad.impressionsCount, language)}</strong>{' '}
                      {t.ads.impressions} ·{' '}
                      <strong>{formatCount(ad.clicksCount, language)}</strong> {t.ads.clicks}
                    </span>
                    {ad.startsAt && ad.endsAt && (
                      <span>
                        {t.ads.scheduleLabel}: {new Date(ad.startsAt).toLocaleDateString()} –{' '}
                        {new Date(ad.endsAt).toLocaleDateString()}
                      </span>
                    )}
                    {ad.paymentStatus === 'paid' && (
                      <span className="inline-flex items-center gap-1 text-[#0B6E4F] dark:text-emerald-300 font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {t.ads.paymentStatuses.paid}
                      </span>
                    )}
                    {ad.paymentStatus === 'pending_verification' && (
                      <span className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-300 font-semibold">
                        <Clock className="w-3.5 h-3.5" />
                        {ad.paymentReference}
                      </span>
                    )}
                  </div>

                  {ad.adminNote && (
                    <p className="text-xs text-slate-600 dark:text-slate-300 bg-[#F4F6F4] dark:bg-[#0D1512] rounded-xl px-3 py-2">
                      {ad.adminNote}
                    </p>
                  )}

                  {canSubmitProof && (
                    <div className="rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] p-3 space-y-2">
                      <p className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                        {t.ads.submitPaymentProofTitle}
                      </p>
                      <div className="flex flex-col sm:flex-row gap-2">
                        <select
                          value={method}
                          onChange={(e) =>
                            setPaymentMethodsByAd((prev) => ({
                              ...prev,
                              [ad.id]: e.target.value as AdPaymentMethod,
                            }))
                          }
                          className="min-h-[42px] px-3 py-2 rounded-xl bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 text-xs"
                        >
                          <option value="manual_bkash">{t.ads.paymentMethods.manual_bkash}</option>
                          <option value="manual_nagad">{t.ads.paymentMethods.manual_nagad}</option>
                          <option value="bank_transfer">{t.ads.paymentMethods.bank_transfer}</option>
                          <option value="cash_office">{t.ads.paymentMethods.cash_office}</option>
                        </select>
                        <input
                          type="text"
                          value={refText}
                          onChange={(e) =>
                            setPaymentRefsByAd((prev) => ({
                              ...prev,
                              [ad.id]: e.target.value,
                            }))
                          }
                          placeholder={t.ads.trxPlaceholder}
                          className="flex-1 min-h-[42px] px-3 py-2 rounded-xl bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 text-xs"
                        />
                        <button
                          type="button"
                          onClick={() => void submitAdPaymentReference(ad.id, method, refText)}
                          className="min-h-[42px] px-4 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold whitespace-nowrap cursor-pointer"
                        >
                          {t.ads.submitProofBtn}
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="flex flex-wrap items-center gap-2">
                    {ad.status === 'approved' && (
                      <button
                        type="button"
                        onClick={() => void pauseOwnAd(ad.id)}
                        className="min-h-[38px] px-3 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 cursor-pointer"
                      >
                        <PauseCircle className="w-3.5 h-3.5" />
                        <span>{t.ads.pauseMyAd}</span>
                      </button>
                    )}

                    {ad.paymentStatus === 'unpaid' &&
                      (ad.status === 'pending_review' || ad.status === 'rejected') && (
                        <button
                          type="button"
                          onClick={() => void deleteOwnUnpaidAd(ad.id)}
                          className="min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-1.5 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{t.ads.deleteUnpaidAd}</span>
                        </button>
                      )}
                  </div>
                </article>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
