import React from 'react';
import {
  Bell,
  Check,
  Heart,
  Megaphone,
  MessageCircle,
  Repeat2,
  ShieldAlert,
  UserCheck,
  UserPlus,
  X,
} from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { NotificationItem } from '../types/social';
import { formatCount, formatRelativeTime, getDisplayName } from '../utils/formatters';
import { Avatar } from './Avatar';

export const NotificationsView: React.FC = () => {
  const {
    t,
    language,
    notifications,
    unreadNotificationsCount,
    getUserById,
    markNotificationRead,
    markAllNotificationsRead,
    openProfile,
    setActiveTab,
    setHighlightedPostId,
    acceptFriendRequest,
    declineFriendRequest,
    currentUser,
  } = useSocial();

  const getNotificationCopy = (notif: NotificationItem): string => {
    switch (notif.type) {
      case 'like':
        return t.notificationsPage.likedYourPost;
      case 'comment':
        return t.notificationsPage.commentedOnPost;
      case 'share':
        return t.notificationsPage.sharedYourPost;
      case 'friend_request':
        return t.notificationsPage.sentFriendRequest;
      case 'friend_accept':
        return t.notificationsPage.acceptedFriendRequest;
      case 'follow':
        return t.notificationsPage.startedFollowing;
      case 'admin_broadcast':
        return notif.title || t.notificationsPage.adminBroadcast;
      case 'moderation':
        return t.notificationsPage.moderationAlert;
      default:
        return '';
    }
  };

  const getNotificationIcon = (notif: NotificationItem) => {
    switch (notif.type) {
      case 'like':
        return <Heart className="w-3.5 h-3.5 text-rose-600 fill-current" />;
      case 'comment':
        return <MessageCircle className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />;
      case 'share':
        return <Repeat2 className="w-3.5 h-3.5 text-amber-600" />;
      case 'friend_request':
      case 'follow':
        return <UserPlus className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />;
      case 'friend_accept':
        return <UserCheck className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />;
      case 'admin_broadcast':
        return <Megaphone className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />;
      case 'moderation':
        return <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />;
    }
  };

  const handleOpenNotification = (notif: NotificationItem) => {
    void markNotificationRead(notif.id);
    if (notif.postId) {
      setHighlightedPostId(notif.postId);
      setActiveTab('feed');
    } else if (notif.type !== 'admin_broadcast' && notif.type !== 'moderation') {
      openProfile(notif.actorId);
    }
  };

  return (
    <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl overflow-hidden">
      <div className="p-4 sm:p-5 border-b border-emerald-950/10 dark:border-emerald-200/10 flex items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white">
            {t.notificationsPage.title}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
            {unreadNotificationsCount > 0
              ? `${formatCount(unreadNotificationsCount, language)} ${t.notificationsPage.unread}`
              : t.notificationsPage.allCaughtUp}
          </p>
        </div>

        {unreadNotificationsCount > 0 && (
          <button
            type="button"
            onClick={() => void markAllNotificationsRead()}
            className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0B6E4F] dark:text-emerald-300 text-xs font-semibold hover:bg-emerald-100 dark:hover:bg-emerald-950 transition-colors cursor-pointer whitespace-nowrap"
          >
            {t.actions.markAllRead}
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="p-12 text-center space-y-2">
          <Bell className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto" />
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {t.notificationsPage.allCaughtUp}
          </p>
        </div>
      ) : (
        <div className="divide-y divide-emerald-950/10 dark:divide-emerald-200/10">
          {notifications.map((notif) => {
            const actor = getUserById(notif.actorId);
            const isSystemNotif =
              notif.type === 'admin_broadcast' || notif.type === 'moderation';
            const actorName = isSystemNotif
              ? 'Sylhet Social'
              : actor
              ? getDisplayName(actor, language)
              : 'Sylhet Member';
            const isPendingRequest =
              notif.type === 'friend_request' &&
              Boolean(actor) &&
              currentUser?.friendRequestsReceived.includes(actor!.id);

            return (
              <div
                key={notif.id}
                className={`p-4 sm:px-5 flex items-start gap-3 transition-colors ${
                  !notif.read ? 'bg-emerald-50/45 dark:bg-emerald-950/25' : ''
                }`}
              >
                <button
                  type="button"
                  onClick={() => {
                    if (!isSystemNotif && actor) openProfile(actor.id);
                  }}
                  className="relative shrink-0 cursor-pointer"
                >
                  <Avatar
                    src={isSystemNotif ? undefined : actor?.avatarUrl}
                    name={actorName}
                    size="md"
                  />
                  <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 flex items-center justify-center">
                    {getNotificationIcon(notif)}
                  </span>
                </button>

                <div className="flex-1 min-w-0">
                  <button
                    type="button"
                    onClick={() => handleOpenNotification(notif)}
                    className="text-left w-full cursor-pointer"
                  >
                    <p className="text-sm text-slate-800 dark:text-slate-200 leading-snug">
                      <span className="font-semibold text-slate-900 dark:text-white">
                        {actorName}
                      </span>{' '}
                      {getNotificationCopy(notif)}
                    </p>
                    {notif.previewText && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        {notif.previewText}
                      </p>
                    )}
                    <p className="text-xs text-slate-400 mt-1">
                      {formatRelativeTime(notif.createdAt, language)}
                    </p>
                  </button>

                  {isPendingRequest && actor && (
                    <div className="flex items-center gap-2 mt-2.5">
                      <button
                        type="button"
                        onClick={() => {
                          void acceptFriendRequest(actor.id);
                          void markNotificationRead(notif.id);
                        }}
                        className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{t.actions.accept}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          void declineFriendRequest(actor.id);
                          void markNotificationRead(notif.id);
                        }}
                        className="min-h-[38px] px-3.5 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-1 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>{t.actions.decline}</span>
                      </button>
                    </div>
                  )}
                </div>

                {!notif.read && (
                  <span
                    aria-label="Unread"
                    className="w-2.5 h-2.5 rounded-full bg-[#0B6E4F] mt-2 shrink-0"
                  />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
