import React from 'react';
import { Globe, ShieldCheck, X } from 'lucide-react';
import { ASSET_IMAGES } from '../data/seedData';
import { useSocial } from '../context/SocialContext';

interface AuthViewProps {
  isModal?: boolean;
  onClose?: () => void;
}

export const AuthView: React.FC<AuthViewProps> = ({ isModal = false, onClose }) => {
  const {
    t,
    language,
    setLanguage,
    signInWithGoogle,
    authError,
    appSettings,
  } = useSocial();

  const card = (
    <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-6 sm:p-8 w-full max-w-md space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-1.5">
          <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
            {t.auth.googleSignInTitle}
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            {t.auth.googleSignInHint}
          </p>
        </div>

        {isModal && onClose && (
          <button
            type="button"
            onClick={onClose}
            aria-label={t.actions.cancel}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {!appSettings.allowRegistrations && (
        <p className="text-xs text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 px-3.5 py-2.5 rounded-xl border border-amber-200 dark:border-amber-800/40">
          {t.auth.registrationsPaused}
        </p>
      )}

      {authError && (
        <p className="text-xs text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-3.5 py-2.5 rounded-xl border border-rose-200 dark:border-rose-800/40">
          {authError}
        </p>
      )}

      <button
        type="button"
        onClick={() => void signInWithGoogle()}
        className="w-full min-h-[48px] px-4 py-3 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white font-semibold text-sm flex items-center justify-center gap-3 transition-colors cursor-pointer"
      >
        <svg aria-hidden="true" viewBox="0 0 24 24" className="w-5 h-5 shrink-0">
          <path
            fill="#FFFFFF"
            d="M21.35 11.1h-9.17v2.92h5.27c-.45 2.38-2.46 3.74-5.27 3.74a5.76 5.76 0 1 1 3.77-10.12l2.14-2.14A8.74 8.74 0 0 0 12.18 3C7.2 3 3.18 7.03 3.18 12s4.02 9 9 9c5.19 0 8.64-3.65 8.64-8.79 0-.59-.07-1.15-.17-1.11Z"
          />
        </svg>
        <span>{t.actions.signInWithGoogle}</span>
      </button>

      <div className="pt-4 border-t border-emerald-950/10 dark:border-emerald-200/10 flex items-start gap-2.5 text-xs text-slate-500 dark:text-slate-400">
        <ShieldCheck className="w-4 h-4 text-[#0B6E4F] dark:text-emerald-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          {language === 'bn'
            ? 'নিরাপদ গুগল অথেনটিকেশন এবং ক্লাউড ফায়ারস্টোর ডাটাবেজের মাধ্যমে আপনার প্রোফাইল ও বার্তা সুরক্ষিত থাকে।'
            : 'Secured with verified Google Authentication and real-time Cloud Firestore persistence.'}
        </p>
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
        <div className="w-full sm:w-auto rounded-t-3xl sm:rounded-2xl overflow-hidden">{card}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F3F5F4] dark:bg-[#0D1512] flex flex-col">
      <header className="max-w-6xl w-full mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <svg aria-hidden="true" viewBox="0 0 36 36" className="w-9 h-9 shrink-0" fill="none">
            <rect width="36" height="36" rx="10" fill="#0B6E4F" />
            <path d="M11 24C11 16.5 16.2 11 25 10C24 18.5 19.2 24 11 24Z" fill="#D1FAE5" />
            <path
              d="M11 24C15.5 19.5 19.5 15.5 24 11"
              stroke="#0B6E4F"
              strokeWidth="1.8"
              strokeLinecap="round"
            />
          </svg>
          <span className="font-display text-xl font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
            Sylhet Social
          </span>
        </div>

        <button
          type="button"
          onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
          className="min-h-[40px] px-3.5 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 bg-white dark:bg-[#14201B] text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-2 hover:bg-emerald-50 dark:hover:bg-white/5 transition-colors cursor-pointer"
        >
          <Globe className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
          <span>{language === 'en' ? 'বাংলা' : 'English'}</span>
        </button>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-12 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
        <div className="lg:col-span-6 space-y-6">
          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-900 dark:text-white text-balance leading-tight">
            {t.auth.welcomeTitle}
          </h1>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-xl leading-relaxed">
            {t.auth.welcomeSubtitle}
          </p>

          <div className="relative rounded-2xl overflow-hidden border border-emerald-950/10 dark:border-emerald-200/10 aspect-[16/9] bg-emerald-950">
            <img
              src={ASSET_IMAGES.teaGardenCover}
              alt="Malnicherra Tea Estate in Sylhet, Bangladesh"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent flex items-end p-5">
              <div className="text-white">
                <p className="text-sm font-semibold">Sylhet Social</p>
                <p className="text-xs text-white/80">
                  {language === 'bn'
                    ? 'মালনিছড়া চা-বাগান · রাতারগুল · সুরমা উপত্যকা'
                    : 'Malnicherra Tea Estate · Ratargul · Surma Valley'}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 flex justify-center lg:justify-end">{card}</div>
      </main>
    </div>
  );
};
