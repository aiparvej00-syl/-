import React, { useMemo, useState } from 'react';
import {
  Compass,
  MapPin,
  MessageCircle,
  Search as SearchIcon,
  UserPlus,
  X,
} from 'lucide-react';
import { ASSET_IMAGES } from '../data/seedData';
import { useSocial } from '../context/SocialContext';
import { getDisplayLocation, getDisplayName } from '../utils/formatters';
import { Avatar } from './Avatar';
import { PostCard } from './PostCard';

type SearchScope = 'all' | 'people' | 'posts' | 'locations';

const POPULAR_QUERIES = [
  { en: 'Madhabkunda', bn: 'মাধবকুণ্ড' },
  { en: 'Lawachara', bn: 'লাউয়াছড়া' },
  { en: 'Sreemangal', bn: 'শ্রীমঙ্গল' },
  { en: 'Hakaluki Haor', bn: 'হাকালুকি হাওর' },
  { en: 'Ratargul', bn: 'রাতারগুল' },
  { en: 'Jaflong', bn: 'জাফলং' },
];

export const SearchView: React.FC = () => {
  const {
    t,
    language,
    searchQuery,
    setSearchQuery,
    setActiveTab,
    users,
    posts,
    locations,
    attractions,
    currentUser,
    openProfile,
    openChatWith,
    sendFriendRequest,
    prefillComposerWithLocation,
  } = useSocial();

  const [scope, setScope] = useState<SearchScope>('all');
  const [districtFilter, setDistrictFilter] = useState<string>('all');
  const [upazilaFilter, setUpazilaFilter] = useState<string>('all');

  const trimmed = searchQuery.trim().toLowerCase();

  const activeLocations = useMemo(
    () =>
      locations
        .filter((l) => l.isActive)
        .sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name)),
    [locations]
  );

  const districts = useMemo(
    () => activeLocations.filter((l) => l.level === 'district'),
    [activeLocations]
  );

  const upazilas = useMemo(
    () =>
      activeLocations.filter(
        (l) =>
          l.level === 'upazila' &&
          (districtFilter === 'all' || l.districtId === districtFilter || l.parentId === districtFilter)
      ),
    [activeLocations, districtFilter]
  );

  const matchedUsers = useMemo(() => {
    const activeUsers = users.filter((u) => u.status === 'active');
    if (!trimmed) return activeUsers.filter((u) => u.uid !== currentUser?.uid);
    return activeUsers.filter(
      (u) =>
        u.name.toLowerCase().includes(trimmed) ||
        u.nameBn.toLowerCase().includes(trimmed) ||
        u.username.toLowerCase().includes(trimmed) ||
        u.location.toLowerCase().includes(trimmed) ||
        u.locationBn.toLowerCase().includes(trimmed) ||
        u.bio.toLowerCase().includes(trimmed)
    );
  }, [trimmed, users, currentUser]);

  const matchedPosts = useMemo(() => {
    const visiblePosts = posts.filter(
      (p) => p.moderationStatus === 'approved' || p.authorId === currentUser?.uid
    );
    if (!trimmed) return visiblePosts;
    return visiblePosts.filter(
      (p) =>
        p.text.toLowerCase().includes(trimmed) ||
        (p.textBn && p.textBn.toLowerCase().includes(trimmed)) ||
        (p.location && p.location.toLowerCase().includes(trimmed)) ||
        (p.locationBn && p.locationBn.toLowerCase().includes(trimmed))
    );
  }, [trimmed, posts, currentUser]);

  const matchedAttractions = useMemo(() => {
    return attractions
      .filter((a) => a.isActive)
      .filter((a) => {
        if (districtFilter !== 'all' && a.districtId !== districtFilter) return false;
        if (upazilaFilter !== 'all' && a.upazilaId !== upazilaFilter) return false;
        if (!trimmed) return true;
        return (
          a.name.toLowerCase().includes(trimmed) ||
          a.nameBn.toLowerCase().includes(trimmed) ||
          a.upazilaName.toLowerCase().includes(trimmed) ||
          (a.upazilaNameBn && a.upazilaNameBn.toLowerCase().includes(trimmed)) ||
          a.districtName.toLowerCase().includes(trimmed) ||
          a.locationSummary.toLowerCase().includes(trimmed) ||
          a.locationSummaryBn.toLowerCase().includes(trimmed)
        );
      });
  }, [attractions, districtFilter, upazilaFilter, trimmed]);

  const matchedLocations = useMemo(() => {
    return activeLocations.filter((l) => {
      if (districtFilter !== 'all' && l.districtId !== districtFilter && l.id !== districtFilter) {
        return false;
      }
      if (upazilaFilter !== 'all' && l.upazilaId !== upazilaFilter && l.id !== upazilaFilter) {
        return false;
      }
      if (!trimmed) return l.level === 'upazila' || l.level === 'district';
      return (
        l.name.toLowerCase().includes(trimmed) ||
        l.nameBn.toLowerCase().includes(trimmed)
      );
    });
  }, [activeLocations, districtFilter, upazilaFilter, trimmed]);

  const showPeople = scope === 'all' || scope === 'people';
  const showPosts = scope === 'all' || scope === 'posts';
  const showLocations = scope === 'all' || scope === 'locations';

  const hasAnyResults =
    (showPeople && matchedUsers.length > 0) ||
    (showLocations && (matchedAttractions.length > 0 || matchedLocations.length > 0)) ||
    (showPosts && matchedPosts.length > 0);

  return (
    <div className="space-y-4">
      <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-4">
        <div className="relative">
          <SearchIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchPage.placeholder}
            className="w-full min-h-[46px] pl-10 pr-10 py-2.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              aria-label="Clear search"
              className="absolute right-2 top-1/2 -translate-y-1/2 min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Popular Topics */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="font-medium text-slate-500 dark:text-slate-400">
            {t.searchPage.popularTopics}:
          </span>
          {POPULAR_QUERIES.map((topic) => {
            const label = language === 'bn' ? topic.bn : topic.en;
            return (
              <button
                key={topic.en}
                type="button"
                onClick={() => setSearchQuery(label)}
                className="min-h-[34px] px-3 py-1 rounded-lg bg-[#F4F6F4] dark:bg-[#0D1512] hover:bg-emerald-50 dark:hover:bg-emerald-950/60 text-slate-700 dark:text-slate-200 font-medium transition-colors cursor-pointer"
              >
                {label}
              </button>
            );
          })}
        </div>

        {/* District & Upazila Filter Bar when searching all or locations */}
        {showLocations && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <select
              value={districtFilter}
              onChange={(e) => {
                setDistrictFilter(e.target.value);
                setUpazilaFilter('all');
              }}
              aria-label={t.locationsPage.districtLabel}
              className="w-full min-h-[40px] px-3 py-1.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
            >
              <option value="all">{t.locationsPage.allDistricts}</option>
              {districts.map((dist) => (
                <option key={dist.id} value={dist.id}>
                  {language === 'bn' ? dist.nameBn : dist.name}
                </option>
              ))}
            </select>

            <select
              value={upazilaFilter}
              onChange={(e) => setUpazilaFilter(e.target.value)}
              aria-label={t.locationsPage.upazilaLabel}
              className="w-full min-h-[40px] px-3 py-1.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700"
            >
              <option value="all">{t.locationsPage.allUpazilas}</option>
              {upazilas.map((upa) => (
                <option key={upa.id} value={upa.id}>
                  {language === 'bn' ? upa.nameBn : upa.name}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Scope Tabs */}
        <div className="flex items-center gap-1 pt-1 border-t border-emerald-950/10 dark:border-emerald-200/10 overflow-x-auto">
          {(['all', 'locations', 'people', 'posts'] as SearchScope[]).map((id) => {
            const label =
              id === 'all'
                ? t.searchPage.allResults
                : id === 'locations'
                ? t.nav.explore
                : id === 'people'
                ? t.searchPage.people
                : t.searchPage.posts;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setScope(id)}
                className={`min-h-[40px] px-4 py-1.5 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  scope === id
                    ? 'bg-[#0B6E4F] text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
      </section>

      {showLocations && (matchedAttractions.length > 0 || matchedLocations.length > 0) && (
        <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#0B6E4F] dark:text-emerald-400" />
              <span>{t.locationsPage.attractionsTitle} & {t.locationsPage.hierarchyTitle}</span>
            </h2>
            <button
              type="button"
              onClick={() => setActiveTab('explore')}
              className="text-xs font-semibold text-[#0B6E4F] dark:text-emerald-300 hover:underline cursor-pointer"
            >
              {t.nav.explore} →
            </button>
          </div>

          {matchedAttractions.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {matchedAttractions.slice(0, scope === 'locations' ? 20 : 4).map((attr) => (
                <div
                  key={attr.id}
                  className="p-3 rounded-xl border border-emerald-950/10 dark:border-emerald-200/10 bg-[#F8FAF8] dark:bg-[#0D1512] flex items-center gap-3"
                >
                  <img
                    src={attr.imageUrl || ASSET_IMAGES.teaGardenCover}
                    alt={language === 'bn' ? attr.nameBn : attr.name}
                    referrerPolicy="no-referrer"
                    className="w-16 h-14 rounded-lg object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                      {language === 'bn' ? attr.nameBn : attr.name}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-emerald-700 dark:text-emerald-400 shrink-0" />
                      <span>
                        {language === 'bn' ? attr.locationSummaryBn : attr.locationSummary}
                      </span>
                    </p>
                    <button
                      type="button"
                      onClick={() =>
                        prefillComposerWithLocation({
                          en: `${attr.name}, ${attr.upazilaName}, ${attr.districtName}`.slice(0, 118),
                          bn: `${attr.nameBn || attr.name}, ${attr.upazilaNameBn || attr.upazilaName}, ${attr.districtNameBn || attr.districtName}`.slice(
                            0,
                            118
                          ),
                        })
                      }
                      className="text-[11px] font-semibold text-[#0B6E4F] dark:text-emerald-300 hover:underline mt-1 cursor-pointer"
                    >
                      {t.locationsPage.tagInPost}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {matchedLocations.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-1">
              {matchedLocations.slice(0, 12).map((node) => (
                <button
                  key={node.id}
                  type="button"
                  onClick={() =>
                    setSearchQuery(language === 'bn' ? node.nameBn || node.name : node.name)
                  }
                  className="min-h-[34px] px-3 py-1 rounded-lg border border-emerald-950/10 dark:border-emerald-200/10 bg-white dark:bg-[#14201B] hover:border-emerald-700/40 text-xs font-medium text-slate-700 dark:text-slate-200 flex items-center gap-1.5 cursor-pointer"
                >
                  <MapPin className="w-3 h-3 text-[#0B6E4F] dark:text-emerald-400" />
                  <span>{language === 'bn' ? node.nameBn : node.name}</span>
                </button>
              ))}
            </div>
          )}
        </section>
      )}

      {showPeople && matchedUsers.length > 0 && (
        <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-3">
          <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
            {t.searchPage.people}
          </h2>
          <div className="divide-y divide-emerald-950/10 dark:divide-emerald-200/10">
            {matchedUsers.map((person) => {
              const isSelf = currentUser?.id === person.id;
              const isFriend = currentUser?.friends.includes(person.id);
              const isRequested = currentUser?.friendRequestsSent.includes(person.id);
              const displayName = getDisplayName(person, language);
              return (
                <div
                  key={person.id}
                  className="py-3 first:pt-1 last:pb-1 flex items-center justify-between gap-3"
                >
                  <button
                    type="button"
                    onClick={() => openProfile(person.id)}
                    className="flex items-center gap-3 min-w-0 text-left cursor-pointer"
                  >
                    <Avatar src={person.avatarUrl} name={displayName} size="md" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {displayName}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        @{person.username} · {getDisplayLocation(person, language)}
                      </p>
                    </div>
                  </button>

                  {!isSelf && currentUser && (
                    <div className="flex items-center gap-1.5 shrink-0">
                      {isFriend ? (
                        <button
                          type="button"
                          onClick={() => void openChatWith(person.uid)}
                          className="min-h-[38px] px-3 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-white/5 cursor-pointer"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>{t.actions.message}</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={isRequested}
                          onClick={() => void sendFriendRequest(person.uid)}
                          className="min-h-[38px] px-3 py-1.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] disabled:opacity-60 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                        >
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>{isRequested ? t.actions.requested : t.actions.addFriend}</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {showPosts && matchedPosts.length > 0 && (
        <div className="space-y-4">
          {matchedPosts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}

      {!hasAnyResults && (
        <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-10 text-center text-sm text-slate-500 dark:text-slate-400">
          {t.searchPage.noResults}
        </div>
      )}
    </div>
  );
};
