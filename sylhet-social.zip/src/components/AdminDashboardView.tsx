import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  BadgeDollarSign,
  BarChart3,
  Check,
  EyeOff,
  FileText,
  Film,
  Flag,
  Lock,
  MapPin,
  Megaphone,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  Trash2,
  Users,
} from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { ModerationStatus, ReportStatus, UserRole } from '../types/social';
import { formatCount, formatRelativeTime, getDisplayLocation, getDisplayName } from '../utils/formatters';
import { AdminLocationsSection } from './AdminLocationsSection';
import { AdminMonetizationSection } from './AdminMonetizationSection';
import { Avatar } from './Avatar';

type AdminSection =
  | 'analytics'
  | 'users'
  | 'posts'
  | 'media'
  | 'reports'
  | 'locations'
  | 'monetization'
  | 'notifications'
  | 'settings';

export const AdminDashboardView: React.FC = () => {
  const {
    t,
    language,
    currentUser,
    isAdmin,
    isBootstrappedAdmin,
    adminRole,
    adminVerified,
    verifyAdminSession,
    lockAdminConsole,
    setActiveTab,
    users,
    privateEmailsByUid,
    posts,
    reports,
    localAds,
    notifications,
    auditLogs,
    appSettings,
    getUserById,
    adminUpdateUserRole,
    adminUpdateUserStatus,
    adminModeratePost,
    adminDeletePost,
    adminResolveReport,
    adminSendBroadcast,
    adminSaveAppSettings,
    adminSeedStarterPosts,
  } = useSocial();

  const [section, setSection] = useState<AdminSection>('analytics');
  const [userSearch, setUserSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [postFilter, setPostFilter] = useState<'all' | ModerationStatus>('all');
  const [mediaFilter, setMediaFilter] = useState<'all' | 'photo' | 'video'>('all');
  const [reportFilter, setReportFilter] = useState<'all' | ReportStatus>('all');

  const [moderationNotes, setModerationNotes] = useState<Record<string, string>>({});
  const [resolutionNotes, setResolutionNotes] = useState<Record<string, string>>({});

  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastBody, setBroadcastBody] = useState('');

  const [settingsDraft, setSettingsDraft] = useState({
    siteName: appSettings.siteName,
    maintenanceMode: appSettings.maintenanceMode,
    allowRegistrations: appSettings.allowRegistrations,
    requirePostReview: appSettings.requirePostReview,
    maxUploadMb: appSettings.maxUploadMb,
    featuredBannerEn: appSettings.featuredBannerEn,
    featuredBannerBn: appSettings.featuredBannerBn,
  });

  if (!isAdmin || !currentUser) {
    return null;
  }

  // Secondary Re-Authentication Gate for Admin Console
  if (!adminVerified) {
    return (
      <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-6 sm:p-10 max-w-lg mx-auto my-6 text-center space-y-5">
        <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0B6E4F] dark:text-emerald-300 mx-auto flex items-center justify-center">
          <ShieldCheck className="w-7 h-7" />
        </div>
        <div className="space-y-2">
          <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white">
            {t.admin.verifyTitle}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            {t.admin.verifyDesc}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={() => void verifyAdminSession()}
            className="w-full sm:w-auto min-h-[46px] px-5 py-2.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold cursor-pointer"
          >
            {t.admin.verifyButton}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('feed')}
            className="w-full sm:w-auto min-h-[46px] px-5 py-2.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
          >
            {t.admin.backToApp}
          </button>
        </div>
      </div>
    );
  }

  // Computed Analytics Metrics
  const totalUsers = users.length;
  const activeUsersCount = users.filter((u) => u.status === 'active').length;
  const suspendedUsersCount = users.filter((u) => u.status === 'suspended').length;
  const totalPosts = posts.length;
  const photoCount = posts.filter((p) => p.mediaType === 'photo').length;
  const videoCount = posts.filter((p) => p.mediaType === 'video').length;
  const textCount = posts.filter((p) => p.mediaType === 'text').length;
  const approvedPosts = posts.filter((p) => p.moderationStatus === 'approved').length;
  const pendingPosts = posts.filter((p) => p.moderationStatus === 'pending').length;
  const hiddenPosts = posts.filter((p) => p.moderationStatus === 'hidden').length;
  const pendingReportsCount = reports.filter((r) => r.status === 'pending').length;
  const totalEngagement = posts.reduce(
    (sum, p) => sum + p.likesCount + p.commentsCount + p.sharesCount,
    0
  );

  const filteredUsers = users.filter((u) => {
    if (roleFilter !== 'all' && u.role !== roleFilter) return false;
    const q = userSearch.trim().toLowerCase();
    if (!q) return true;
    const email = (privateEmailsByUid[u.uid] || u.email || '').toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.username.toLowerCase().includes(q) ||
      u.location.toLowerCase().includes(q) ||
      email.includes(q)
    );
  });

  const filteredPosts = posts.filter((p) =>
    postFilter === 'all' ? true : p.moderationStatus === postFilter
  );

  const mediaPosts = posts.filter((p) => {
    if (p.mediaType === 'text') return false;
    if (mediaFilter === 'all') return true;
    return p.mediaType === mediaFilter;
  });

  const filteredReports = reports.filter((r) =>
    reportFilter === 'all' ? true : r.status === reportFilter
  );

  const broadcasts = notifications.filter((n) => n.type === 'admin_broadcast');

  const navTabs: { id: AdminSection; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'analytics', label: t.admin.tabs.analytics, icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'users', label: t.admin.tabs.users, icon: <Users className="w-4 h-4" /> },
    {
      id: 'posts',
      label: t.admin.tabs.posts,
      icon: <FileText className="w-4 h-4" />,
      badge: pendingPosts || undefined,
    },
    { id: 'media', label: t.admin.tabs.media, icon: <Film className="w-4 h-4" /> },
    {
      id: 'reports',
      label: t.admin.tabs.reports,
      icon: <Flag className="w-4 h-4" />,
      badge: pendingReportsCount || undefined,
    },
    {
      id: 'locations',
      label: t.admin.locations.tabLabel,
      icon: <MapPin className="w-4 h-4" />,
    },
    {
      id: 'monetization',
      label: t.admin.monetization.tabLabel,
      icon: <BadgeDollarSign className="w-4 h-4" />,
      badge:
        localAds.filter(
          (a) => a.status === 'pending_review' || a.paymentStatus === 'pending_verification'
        ).length || undefined,
    },
    {
      id: 'notifications',
      label: t.admin.tabs.notifications,
      icon: <Megaphone className="w-4 h-4" />,
    },
    { id: 'settings', label: t.admin.tabs.settings, icon: <Settings className="w-4 h-4" /> },
  ];

  const handleBroadcastSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle.trim() || !broadcastBody.trim()) return;
    await adminSendBroadcast(broadcastTitle, broadcastBody);
    setBroadcastTitle('');
    setBroadcastBody('');
  };

  const handleSettingsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await adminSaveAppSettings(settingsDraft);
  };

  return (
    <div className="space-y-4">
      {/* Admin Header Bar */}
      <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
              <span>Sylhet Social</span>
              <span aria-hidden="true">/</span>
              <span>{t.admin.title}</span>
              <span aria-hidden="true">/</span>
              <span className="capitalize text-emerald-700 dark:text-emerald-400 font-semibold">
                {adminRole || 'admin'}
              </span>
            </div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {t.admin.title}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-0.5">
              {t.admin.subtitle}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('feed')}
              className="min-h-[42px] px-3.5 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{t.admin.backToApp}</span>
            </button>
            <button
              type="button"
              onClick={lockAdminConsole}
              className="min-h-[42px] px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-emerald-800 text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              <span>{t.admin.lockConsole}</span>
            </button>
          </div>
        </div>

        {/* Section Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-2 border-t border-emerald-950/10 dark:border-emerald-200/10">
          {navTabs.map((tab) => {
            const active = section === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setSection(tab.id);
                  if (tab.id === 'settings') {
                    setSettingsDraft({
                      siteName: appSettings.siteName,
                      maintenanceMode: appSettings.maintenanceMode,
                      allowRegistrations: appSettings.allowRegistrations,
                      requirePostReview: appSettings.requirePostReview,
                      maxUploadMb: appSettings.maxUploadMb,
                      featuredBannerEn: appSettings.featuredBannerEn,
                      featuredBannerBn: appSettings.featuredBannerBn,
                    });
                  }
                }}
                className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  active
                    ? 'bg-[#0B6E4F] text-white'
                    : 'bg-[#F4F6F4] dark:bg-[#0D1512] text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span
                    className={`px-1.5 py-0.5 rounded-full text-[11px] font-bold tabular-nums ${
                      active ? 'bg-white text-[#0B6E4F]' : 'bg-amber-600 text-white'
                    }`}
                  >
                    {formatCount(tab.badge, language)}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* 1. ANALYTICS SECTION */}
      {section === 'analytics' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                {t.admin.metrics.totalUsers}
              </p>
              <p className="font-display text-2xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
                {formatCount(totalUsers, language)}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
                {formatCount(activeUsersCount, language)} {t.admin.users.active} ·{' '}
                {formatCount(suspendedUsersCount, language)} {t.admin.users.suspended}
              </p>
            </div>

            <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                {t.admin.metrics.totalPosts}
              </p>
              <p className="font-display text-2xl font-bold text-slate-900 dark:text-white mt-1 tabular-nums">
                {formatCount(totalPosts, language)}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
                {formatCount(approvedPosts, language)} {t.admin.posts.approved} ·{' '}
                {formatCount(hiddenPosts, language)} {t.admin.posts.hidden}
              </p>
            </div>

            <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                {t.admin.metrics.pendingReports}
              </p>
              <p className="font-display text-2xl font-bold text-amber-700 dark:text-amber-400 mt-1 tabular-nums">
                {formatCount(pendingReportsCount, language)}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
                {formatCount(reports.length, language)} {t.admin.reports.all}
              </p>
            </div>

            <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                {t.admin.metrics.totalEngagement}
              </p>
              <p className="font-display text-2xl font-bold text-[#0B6E4F] dark:text-emerald-300 mt-1 tabular-nums">
                {formatCount(totalEngagement, language)}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {t.actions.like} · {t.actions.comment} · {t.actions.share}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-5 space-y-4">
              <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
                {t.admin.metrics.mediaDistribution}
              </h2>
              {[
                { label: t.feed.photos, count: photoCount, color: 'bg-[#0B6E4F]' },
                { label: t.feed.videos, count: videoCount, color: 'bg-amber-600' },
                { label: t.feed.textCard, count: textCount, color: 'bg-slate-600' },
              ].map((row) => {
                const pct = totalPosts > 0 ? Math.round((row.count / totalPosts) * 100) : 0;
                return (
                  <div key={row.label} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-medium tabular-nums">
                      <span className="text-slate-700 dark:text-slate-200">{row.label}</span>
                      <span className="text-slate-500 dark:text-slate-400">
                        {formatCount(row.count, language)} ({formatCount(pct, language)}%)
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-[#EEF2EF] dark:bg-[#0D1512] overflow-hidden">
                      <div className={`h-full ${row.color}`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </section>

            <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-5 space-y-4">
              <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
                {t.admin.metrics.moderationStatus}
              </h2>
              {[
                { label: t.admin.posts.approved, count: approvedPosts, color: 'bg-emerald-600' },
                { label: t.admin.posts.pending, count: pendingPosts, color: 'bg-amber-500' },
                { label: t.admin.posts.hidden, count: hiddenPosts, color: 'bg-rose-600' },
              ].map((row) => {
                const pct = totalPosts > 0 ? Math.round((row.count / totalPosts) * 100) : 0;
                return (
                  <div key={row.label} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-medium tabular-nums">
                      <span className="text-slate-700 dark:text-slate-200">{row.label}</span>
                      <span className="text-slate-500 dark:text-slate-400">
                        {formatCount(row.count, language)} ({formatCount(pct, language)}%)
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-[#EEF2EF] dark:bg-[#0D1512] overflow-hidden">
                      <div className={`h-full ${row.color}`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </section>
          </div>

          <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-5 space-y-3">
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
              {t.admin.metrics.recentAudit}
            </h2>
            {auditLogs.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                No admin actions recorded yet.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-emerald-950/10 dark:border-emerald-200/10 text-slate-500 dark:text-slate-400">
                      <th className="py-2 pr-3 font-medium">Action</th>
                      <th className="py-2 pr-3 font-medium">Admin</th>
                      <th className="py-2 pr-3 font-medium">Summary</th>
                      <th className="py-2 font-medium text-right">Time</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-emerald-950/10 dark:divide-emerald-200/10">
                    {auditLogs.slice(0, 12).map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50/70 dark:hover:bg-white/5">
                        <td className="py-2.5 pr-3 font-mono text-slate-900 dark:text-slate-100 whitespace-nowrap">
                          {log.action}
                        </td>
                        <td className="py-2.5 pr-3 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                          {log.adminEmail}
                        </td>
                        <td className="py-2.5 pr-3 text-slate-700 dark:text-slate-200">
                          {log.summary}
                        </td>
                        <td className="py-2.5 text-slate-400 text-right whitespace-nowrap tabular-nums">
                          {formatRelativeTime(log.createdAt, language)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </div>
      )}

      {/* 2. USER MANAGEMENT SECTION */}
      {section === 'users' && (
        <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder={t.admin.users.searchPlaceholder}
                className="w-full min-h-[42px] pl-10 pr-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700"
              />
            </div>

            <div className="flex items-center gap-1 bg-[#F4F6F4] dark:bg-[#0D1512] p-1 rounded-xl">
              {(['all', 'admin', 'moderator', 'user'] as const).map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setRoleFilter(r)}
                  className={`min-h-[36px] px-3 py-1 rounded-lg text-xs font-semibold capitalize cursor-pointer ${
                    roleFilter === r
                      ? 'bg-white dark:bg-[#1C2C25] text-emerald-800 dark:text-emerald-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-emerald-950/10 dark:divide-emerald-200/10">
            {filteredUsers.map((person) => {
              const email = privateEmailsByUid[person.uid] || person.email || '';
              const isSelf = person.uid === currentUser.uid;
              return (
                <div
                  key={person.uid}
                  className="py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar
                      src={person.avatarUrl}
                      name={getDisplayName(person, language)}
                      size="md"
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {getDisplayName(person, language)}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        @{person.username}
                        {email ? ` · ${email}` : ''} · {getDisplayLocation(person, language)}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
                        {t.admin.users.roleLabel}: <strong className="capitalize">{person.role}</strong> ·{' '}
                        {t.admin.users.statusLabel}:{' '}
                        <strong
                          className={
                            person.status === 'suspended'
                              ? 'text-rose-600 dark:text-rose-400'
                              : 'text-emerald-700 dark:text-emerald-400'
                          }
                        >
                          {person.status === 'suspended'
                            ? t.admin.users.suspended
                            : t.admin.users.active}
                        </strong>
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {isBootstrappedAdmin && !isSelf && (
                      <select
                        aria-label={t.admin.users.roleLabel}
                        value={person.role}
                        onChange={(e) =>
                          void adminUpdateUserRole(person.uid, e.target.value as UserRole)
                        }
                        className="min-h-[38px] px-3 py-1.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs font-semibold"
                      >
                        <option value="user">{t.admin.users.makeUser}</option>
                        <option value="moderator">{t.admin.users.makeModerator}</option>
                        <option value="admin">{t.admin.users.makeAdmin}</option>
                      </select>
                    )}

                    {!isSelf && (
                      <button
                        type="button"
                        onClick={() =>
                          void adminUpdateUserStatus(
                            person.uid,
                            person.status === 'active' ? 'suspended' : 'active'
                          )
                        }
                        className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold cursor-pointer ${
                          person.status === 'active'
                            ? 'border border-rose-200 dark:border-rose-800/40 text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30'
                            : 'bg-[#0B6E4F] text-white hover:bg-[#09583F]'
                        }`}
                      >
                        {person.status === 'active'
                          ? t.admin.users.suspend
                          : t.admin.users.activate}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 3. POST MODERATION SECTION */}
      {section === 'posts' && (
        <section className="space-y-4">
          <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-2 flex items-center gap-1 overflow-x-auto">
            {(['all', 'pending', 'approved', 'hidden'] as const).map((status) => (
              <button
                key={status}
                type="button"
                onClick={() => setPostFilter(status)}
                className={`min-h-[40px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap cursor-pointer ${
                  postFilter === status
                    ? 'bg-[#0B6E4F] text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
                }`}
              >
                {t.admin.posts[status]}
              </button>
            ))}
          </div>

          {filteredPosts.length === 0 ? (
            <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-10 text-center text-sm text-slate-500">
              {t.feed.noPostsFound}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredPosts.map((post) => {
                const author = getUserById(post.authorId);
                return (
                  <div
                    key={post.id}
                    className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <Avatar
                          src={author?.avatarUrl}
                          name={author ? getDisplayName(author, language) : 'Member'}
                          size="sm"
                        />
                        <div>
                          <p className="text-sm font-semibold text-slate-900 dark:text-white">
                            {author ? getDisplayName(author, language) : post.authorId}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {formatRelativeTime(post.createdAt, language)} · {post.mediaType} ·{' '}
                            <strong
                              className={
                                post.moderationStatus === 'hidden'
                                  ? 'text-rose-600 dark:text-rose-400'
                                  : post.moderationStatus === 'pending'
                                  ? 'text-amber-600 dark:text-amber-400'
                                  : 'text-emerald-700 dark:text-emerald-400'
                              }
                            >
                              {post.moderationStatus}
                            </strong>
                          </p>
                        </div>
                      </div>
                    </div>

                    {post.text && (
                      <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                        {post.text}
                      </p>
                    )}

                    {(post.photoUrl || post.videoThumbnailUrl) && (
                      <div className="max-w-xs rounded-xl overflow-hidden border border-emerald-950/10 dark:border-emerald-200/10">
                        <img
                          src={post.photoUrl || post.videoThumbnailUrl}
                          alt="Post media preview"
                          referrerPolicy="no-referrer"
                          className="w-full h-36 object-cover"
                        />
                      </div>
                    )}

                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 pt-2 border-t border-emerald-950/10 dark:border-emerald-200/10">
                      <input
                        type="text"
                        value={moderationNotes[post.id] ?? post.moderationNote ?? ''}
                        onChange={(e) =>
                          setModerationNotes((prev) => ({ ...prev, [post.id]: e.target.value }))
                        }
                        placeholder={t.admin.posts.notePlaceholder}
                        className="flex-1 min-h-[40px] px-3 py-1.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs"
                      />
                      <div className="flex items-center gap-2">
                        {post.moderationStatus !== 'approved' && (
                          <button
                            type="button"
                            onClick={() =>
                              void adminModeratePost(
                                post.id,
                                'approved',
                                moderationNotes[post.id] ?? ''
                              )
                            }
                            className="min-h-[38px] px-3 py-1.5 rounded-xl bg-[#0B6E4F] text-white text-xs font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>{t.admin.posts.approve}</span>
                          </button>
                        )}
                        {post.moderationStatus !== 'hidden' && (
                          <button
                            type="button"
                            onClick={() =>
                              void adminModeratePost(
                                post.id,
                                'hidden',
                                moderationNotes[post.id] ?? ''
                              )
                            }
                            className="min-h-[38px] px-3 py-1.5 rounded-xl border border-amber-300 dark:border-amber-700/50 text-amber-800 dark:text-amber-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <EyeOff className="w-3.5 h-3.5" />
                            <span>{t.admin.posts.hide}</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => void adminDeletePost(post.id)}
                          className="min-h-[38px] px-3 py-1.5 rounded-xl border border-rose-200 dark:border-rose-800/40 text-rose-700 dark:text-rose-400 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{t.admin.posts.delete}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* 4. PHOTO & VIDEO MEDIA MANAGEMENT */}
      {section === 'media' && (
        <section className="space-y-4">
          <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-2 flex items-center gap-1">
            {([
              { id: 'all', label: t.admin.media.allMedia },
              { id: 'photo', label: t.admin.media.photosOnly },
              { id: 'video', label: t.admin.media.videosOnly },
            ] as const).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setMediaFilter(tab.id)}
                className={`min-h-[40px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold cursor-pointer ${
                  mediaFilter === tab.id
                    ? 'bg-[#0B6E4F] text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {mediaPosts.length === 0 ? (
            <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-10 text-center text-sm text-slate-500">
              {t.admin.media.noMedia}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {mediaPosts.map((item) => {
                const author = getUserById(item.authorId);
                return (
                  <div
                    key={item.id}
                    className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl overflow-hidden flex flex-col justify-between"
                  >
                    <div className="aspect-[4/3] bg-slate-900 relative">
                      {item.mediaType === 'video' && item.videoUrl ? (
                        <video src={item.videoUrl} controls className="w-full h-full object-cover" />
                      ) : (
                        <img
                          src={item.photoUrl || item.videoThumbnailUrl}
                          alt={item.text || 'Media item'}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      )}
                    </div>
                    <div className="p-3.5 space-y-2.5">
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        <strong className="text-slate-900 dark:text-white">
                          {author ? getDisplayName(author, language) : item.authorId}
                        </strong>{' '}
                        · {item.mediaType} · {item.moderationStatus}
                      </div>
                      <p className="text-xs text-slate-700 dark:text-slate-200 line-clamp-2">
                        {item.text || item.location || 'Sylhet Media'}
                      </p>
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() =>
                            void adminModeratePost(
                              item.id,
                              item.moderationStatus === 'hidden' ? 'approved' : 'hidden'
                            )
                          }
                          className="flex-1 min-h-[36px] px-2.5 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-white/5 cursor-pointer"
                        >
                          {item.moderationStatus === 'hidden'
                            ? t.admin.posts.approve
                            : t.admin.posts.hide}
                        </button>
                        <button
                          type="button"
                          onClick={() => void adminDeletePost(item.id)}
                          aria-label={t.admin.posts.delete}
                          className="min-w-[36px] min-h-[36px] rounded-xl border border-rose-200 dark:border-rose-800/40 text-rose-600 flex items-center justify-center cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* 5. REPORTS SECTION */}
      {section === 'reports' && (
        <section className="space-y-4">
          <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-2 flex items-center gap-1 overflow-x-auto">
            {(['all', 'pending', 'resolved', 'dismissed'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setReportFilter(st)}
                className={`min-h-[40px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap cursor-pointer ${
                  reportFilter === st
                    ? 'bg-[#0B6E4F] text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
                }`}
              >
                {t.admin.reports[st]}
              </button>
            ))}
          </div>

          {filteredReports.length === 0 ? (
            <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-10 text-center text-sm text-slate-500">
              {t.admin.reports.noReports}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredReports.map((rep) => {
                const reporter = getUserById(rep.reporterId);
                const targetPost = rep.targetPostId
                  ? posts.find((p) => p.id === rep.targetPostId)
                  : undefined;
                const reportedUser = rep.targetUserId ? getUserById(rep.targetUserId) : undefined;

                return (
                  <div
                    key={rep.id}
                    className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <span className="font-semibold text-slate-900 dark:text-white">
                        [{rep.targetType.toUpperCase()}] {rep.reason.toUpperCase()} · {rep.status}
                      </span>
                      <span className="text-slate-400">
                        {reporter ? getDisplayName(reporter, language) : rep.reporterId} ·{' '}
                        {formatRelativeTime(rep.createdAt, language)}
                      </span>
                    </div>

                    {rep.details && (
                      <p className="text-sm text-slate-700 dark:text-slate-200">{rep.details}</p>
                    )}

                    {rep.targetType === 'user' && rep.targetUserId && (
                      <div className="p-3 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs text-slate-600 dark:text-slate-300">
                        <p className="font-semibold text-slate-900 dark:text-white">
                          Reported Member:{' '}
                          {reportedUser
                            ? `${getDisplayName(reportedUser, language)} (@${reportedUser.username}) · ${reportedUser.status}`
                            : rep.targetUserId}
                        </p>
                      </div>
                    )}

                    {targetPost && (
                      <div className="p-3 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs text-slate-600 dark:text-slate-300">
                        <p className="font-semibold text-slate-900 dark:text-white mb-1">
                          Reported Post ({targetPost.moderationStatus})
                        </p>
                        <p className="line-clamp-3">{targetPost.text || '[Media Post]'}</p>
                      </div>
                    )}

                    {rep.status === 'pending' && (
                      <div className="space-y-2 pt-2 border-t border-emerald-950/10 dark:border-emerald-200/10">
                        <input
                          type="text"
                          value={resolutionNotes[rep.id] ?? ''}
                          onChange={(e) =>
                            setResolutionNotes((prev) => ({ ...prev, [rep.id]: e.target.value }))
                          }
                          placeholder={t.admin.posts.notePlaceholder}
                          className="w-full min-h-[40px] px-3 py-1.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs"
                        />
                        <div className="flex flex-wrap items-center gap-2">
                          {rep.targetType === 'post' ? (
                            <button
                              type="button"
                              onClick={() =>
                                void adminResolveReport(
                                  rep.id,
                                  'resolved',
                                  resolutionNotes[rep.id] || 'Removed after review',
                                  true,
                                  false
                                )
                              }
                              className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold cursor-pointer"
                            >
                              {t.admin.reports.resolveHide}
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() =>
                                void adminResolveReport(
                                  rep.id,
                                  'resolved',
                                  resolutionNotes[rep.id] || 'User suspended after report review',
                                  false,
                                  true
                                )
                              }
                              className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold cursor-pointer"
                            >
                              {language === 'bn'
                                ? 'সদস্য স্থগিত করে সমাধান করুন'
                                : 'Suspend User & Resolve'}
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() =>
                              void adminResolveReport(
                                rep.id,
                                'resolved',
                                resolutionNotes[rep.id] || 'Reviewed and kept',
                                false,
                                false
                              )
                            }
                            className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold cursor-pointer"
                          >
                            {t.admin.reports.resolveKeep}
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              void adminResolveReport(
                                rep.id,
                                'dismissed',
                                resolutionNotes[rep.id] || 'Dismissed',
                                false,
                                false
                              )
                            }
                            className="min-h-[38px] px-3.5 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
                          >
                            {t.admin.reports.dismiss}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* 6. NOTIFICATIONS & BROADCASTS */}
      {section === 'notifications' && (
        <div className="space-y-4">
          <form
            onSubmit={(e) => void handleBroadcastSubmit(e)}
            className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-5 space-y-4"
          >
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
              {t.admin.tabs.notifications}
            </h2>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                {t.admin.broadcast.titleLabel}
              </label>
              <input
                type="text"
                value={broadcastTitle}
                onChange={(e) => setBroadcastTitle(e.target.value)}
                placeholder="Sylhet Weekend Community Update"
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                {t.admin.broadcast.messageLabel}
              </label>
              <textarea
                value={broadcastBody}
                onChange={(e) => setBroadcastBody(e.target.value)}
                rows={3}
                placeholder="Share a platform-wide announcement with all Sylhet Social members..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700 resize-none"
              />
            </div>
            <button
              type="submit"
              disabled={!broadcastTitle.trim() || !broadcastBody.trim()}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] disabled:opacity-45 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <Megaphone className="w-4 h-4" />
              <span>{t.admin.broadcast.sendBroadcast}</span>
            </button>
          </form>

          <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-5 space-y-3">
            <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
              {t.admin.broadcast.recentBroadcasts}
            </h3>
            {broadcasts.length === 0 ? (
              <p className="text-xs text-slate-500">No broadcasts sent yet.</p>
            ) : (
              <div className="divide-y divide-emerald-950/10 dark:divide-emerald-200/10">
                {broadcasts.map((b) => (
                  <div key={b.id} className="py-3 first:pt-1 last:pb-1">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white">
                      {b.title}
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                      {b.previewText}
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {formatRelativeTime(b.createdAt, language)}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}

      {/* 7. APP SETTINGS */}
      {section === 'settings' && (
        <div className="space-y-4">
          <form
            onSubmit={(e) => void handleSettingsSubmit(e)}
            className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-5 space-y-4"
          >
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
              {t.admin.tabs.settings}
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                  {t.admin.settings.siteName}
                </label>
                <input
                  type="text"
                  value={settingsDraft.siteName}
                  onChange={(e) =>
                    setSettingsDraft((prev) => ({ ...prev, siteName: e.target.value }))
                  }
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                  {t.admin.settings.maxUploadMb}
                </label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  value={settingsDraft.maxUploadMb}
                  onChange={(e) =>
                    setSettingsDraft((prev) => ({
                      ...prev,
                      maxUploadMb: Number(e.target.value) || 5,
                    }))
                  }
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm tabular-nums"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                {t.admin.settings.bannerEn}
              </label>
              <input
                type="text"
                value={settingsDraft.featuredBannerEn}
                onChange={(e) =>
                  setSettingsDraft((prev) => ({ ...prev, featuredBannerEn: e.target.value }))
                }
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                {t.admin.settings.bannerBn}
              </label>
              <input
                type="text"
                value={settingsDraft.featuredBannerBn}
                onChange={(e) =>
                  setSettingsDraft((prev) => ({ ...prev, featuredBannerBn: e.target.value }))
                }
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm"
              />
            </div>

            <div className="divide-y divide-emerald-950/10 dark:divide-emerald-200/10 pt-2">
              <label className="py-3 flex items-center justify-between gap-4 cursor-pointer">
                <div>
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">
                    {t.admin.settings.maintenanceMode}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {t.admin.settings.maintenanceDesc}
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settingsDraft.maintenanceMode}
                  onChange={(e) =>
                    setSettingsDraft((prev) => ({ ...prev, maintenanceMode: e.target.checked }))
                  }
                  className="w-5 h-5 accent-[#0B6E4F]"
                />
              </label>

              <label className="py-3 flex items-center justify-between gap-4 cursor-pointer">
                <div>
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">
                    {t.admin.settings.allowRegistrations}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {t.admin.settings.allowRegistrationsDesc}
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settingsDraft.allowRegistrations}
                  onChange={(e) =>
                    setSettingsDraft((prev) => ({ ...prev, allowRegistrations: e.target.checked }))
                  }
                  className="w-5 h-5 accent-[#0B6E4F]"
                />
              </label>

              <label className="py-3 flex items-center justify-between gap-4 cursor-pointer">
                <div>
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">
                    {t.admin.settings.requirePostReview}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {t.admin.settings.requirePostReviewDesc}
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settingsDraft.requirePostReview}
                  onChange={(e) =>
                    setSettingsDraft((prev) => ({ ...prev, requirePostReview: e.target.checked }))
                  }
                  className="w-5 h-5 accent-[#0B6E4F]"
                />
              </label>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <button
                type="submit"
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold cursor-pointer"
              >
                {t.admin.settings.saveSettings}
              </button>

              <button
                type="button"
                onClick={() => void adminSeedStarterPosts()}
                className="min-h-[44px] px-4 py-2.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-[#0B6E4F] dark:text-emerald-400" />
                <span>{t.admin.settings.seedStarterPosts}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 8. LOCATIONS & TOURIST ATTRACTIONS */}
      {section === 'locations' && <AdminLocationsSection />}

      {/* 9. MONETIZATION & LOCAL ADS */}
      {section === 'monetization' && <AdminMonetizationSection />}
    </div>
  );
};
