import React from 'react';
import {
  Bell,
  Compass,
  Home,
  LogOut,
  Megaphone,
  MessageCircle,
  Search,
  ShieldCheck,
  User,
  Users,
} from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { NavTab } from '../types/social';
import { formatCount, getDisplayLocation, getDisplayName } from '../utils/formatters';
import { Avatar } from './Avatar';

export const LeftRail: React.FC = () => {
  const {
    t,
    language,
    setLanguage,
    currentUser,
    isAdmin,
    activeTab,
    setActiveTab,
    openProfile,
    unreadMessagesCount,
    unreadNotificationsCount,
    setAdPrivacyModalOpen,
    logout,
  } = useSocial();

  const items: {
    id: NavTab;
    label: string;
    icon: React.ReactNode;
    badge?: number;
    onClick?: () => void;
  }[] = [
    { id: 'feed', label: t.nav.feed, icon: <Home className="w-4 h-4" /> },
    { id: 'explore', label: t.nav.explore, icon: <Compass className="w-4 h-4" /> },
    { id: 'advertise', label: t.nav.advertise, icon: <Megaphone className="w-4 h-4" /> },
    {
      id: 'friends',
      label: t.nav.friends,
      icon: <Users className="w-4 h-4" />,
      badge: currentUser?.friendRequestsReceived.length || undefined,
    },
    { id: 'search', label: t.nav.search, icon: <Search className="w-4 h-4" /> },
    {
      id: 'messages',
      label: t.nav.messages,
      icon: <MessageCircle className="w-4 h-4" />,
      badge: unreadMessagesCount || undefined,
    },
    {
      id: 'notifications',
      label: t.nav.notifications,
      icon: <Bell className="w-4 h-4" />,
      badge: unreadNotificationsCount || undefined,
    },
    {
      id: 'profile',
      label: t.nav.profile,
      icon: <User className="w-4 h-4" />,
      onClick: () => {
        if (currentUser) openProfile(currentUser.id);
      },
    },
  ];

  return (
    <aside className="hidden lg:block lg:col-span-3 space-y-4">
      <div className="sticky top-20 space-y-4">
        {currentUser && (
          <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 space-y-3">
            <button
              type="button"
              onClick={() => openProfile(currentUser.id)}
              className="flex items-center gap-3 w-full text-left group cursor-pointer"
            >
              <Avatar
                src={currentUser.avatarUrl}
                name={getDisplayName(currentUser, language)}
                size="md"
              />
              <div className="min-w-0">
                <p className="font-semibold text-sm text-slate-900 dark:text-white group-hover:underline truncate">
                  {getDisplayName(currentUser, language)}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                  {getDisplayLocation(currentUser, language)}
                </p>
              </div>
            </button>

            <div className="pt-2.5 border-t border-emerald-950/10 dark:border-emerald-200/10 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 tabular-nums">
              <span>
                <strong className="text-slate-900 dark:text-white">
                  {formatCount(currentUser.friendsCount, language)}
                </strong>{' '}
                {t.profile.friends}
              </span>
              <span>
                <strong className="text-slate-900 dark:text-white">
                  {formatCount(currentUser.followersCount, language)}
                </strong>{' '}
                {t.profile.followers}
              </span>
            </div>
          </div>
        )}

        <nav
          aria-label="Sidebar navigation"
          className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-2 space-y-0.5"
        >
          {items.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={item.onClick ?? (() => setActiveTab(item.id))}
                className={`w-full min-h-[44px] px-3.5 py-2 rounded-xl flex items-center justify-between text-sm font-medium transition-colors cursor-pointer ${
                  active
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-[#0B6E4F] dark:text-emerald-300 font-semibold'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5'
                }`}
              >
                <span className="flex items-center gap-3">
                  {item.icon}
                  <span>{item.label}</span>
                </span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="text-xs font-semibold tabular-nums text-[#0B6E4F] dark:text-emerald-300">
                    {formatCount(item.badge, language)}
                  </span>
                )}
              </button>
            );
          })}

          {isAdmin && (
            <button
              type="button"
              onClick={() => setActiveTab('admin')}
              className={`w-full min-h-[44px] px-3.5 py-2 rounded-xl flex items-center justify-between text-sm font-semibold transition-colors cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-slate-900 text-white dark:bg-emerald-700'
                  : 'text-slate-800 dark:text-emerald-200 hover:bg-slate-50 dark:hover:bg-white/5'
              }`}
            >
              <span className="flex items-center gap-3">
                <ShieldCheck className="w-4 h-4" />
                <span>{t.nav.admin}</span>
              </span>
            </button>
          )}
        </nav>

        <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between text-xs font-medium text-slate-600 dark:text-slate-300">
            <span>{t.settings.language}</span>
            <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[#F4F6F4] dark:bg-[#0D1512]">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold cursor-pointer ${
                  language === 'en'
                    ? 'bg-white dark:bg-[#1C2C25] text-emerald-800 dark:text-emerald-300 shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLanguage('bn')}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold cursor-pointer ${
                  language === 'bn'
                    ? 'bg-white dark:bg-[#1C2C25] text-emerald-800 dark:text-emerald-300 shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                বাংলা
              </button>
            </div>
          </div>

          <div className="pt-2 border-t border-emerald-950/10 dark:border-emerald-200/10 space-y-1">
            <button
              type="button"
              onClick={() => setAdPrivacyModalOpen(true)}
              className="w-full min-h-[36px] px-3 py-1 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#0B6E4F] dark:text-emerald-400" />
              <span>{t.consent.privacyLink}</span>
            </button>
          </div>

          {currentUser && (
            <div className="pt-1 border-t border-emerald-950/10 dark:border-emerald-200/10">
              <button
                type="button"
                onClick={() => void logout()}
                className="w-full min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{t.actions.signOut}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};
