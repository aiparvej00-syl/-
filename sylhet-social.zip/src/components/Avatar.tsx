import React, { useState } from 'react';
import { getInitials } from '../utils/formatters';

interface AvatarProps {
  src?: string;
  name: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showOnline?: boolean;
  isOnline?: boolean;
  className?: string;
}

const SIZE_MAP = {
  xs: 'w-7 h-7 text-[11px]',
  sm: 'w-9 h-9 text-xs',
  md: 'w-11 h-11 text-sm',
  lg: 'w-16 h-16 text-lg',
  xl: 'w-24 h-24 sm:w-28 sm:h-28 text-2xl',
};

const TINT_PALETTE = [
  'bg-emerald-800 text-emerald-50',
  'bg-teal-800 text-teal-50',
  'bg-amber-700 text-amber-50',
  'bg-slate-700 text-slate-50',
];

function pickTint(name: string): string {
  let sum = 0;
  for (let i = 0; i < name.length; i += 1) {
    sum += name.charCodeAt(i);
  }
  return TINT_PALETTE[sum % TINT_PALETTE.length];
}

export const Avatar: React.FC<AvatarProps> = ({
  src,
  name,
  size = 'md',
  showOnline = false,
  isOnline = false,
  className = '',
}) => {
  const [imgError, setImgError] = useState(false);
  const showImage = Boolean(src) && !imgError;

  return (
    <div className={`relative inline-flex shrink-0 ${className}`}>
      {showImage ? (
        <img
          src={src}
          alt={name}
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className={`${SIZE_MAP[size]} rounded-full object-cover bg-emerald-950/10 dark:bg-emerald-200/10`}
        />
      ) : (
        <div
          aria-label={name}
          className={`${SIZE_MAP[size]} ${pickTint(name)} rounded-full flex items-center justify-center font-semibold tracking-tight select-none`}
        >
          {getInitials(name)}
        </div>
      )}
      {showOnline && isOnline && (
        <span
          aria-label="Online"
          className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#14201B]"
        />
      )}
    </div>
  );
};
