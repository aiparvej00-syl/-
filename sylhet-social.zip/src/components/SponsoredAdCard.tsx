import React, { useEffect, useState } from 'react';
import {
  ExternalLink,
  EyeOff,
  HelpCircle,
  MapPin,
  Megaphone,
  Phone,
  ShieldCheck,
  Smartphone,
} from 'lucide-react';
import {
  buildAdMobRequestOptions,
  dispatchAndroidAdMobBridge,
} from '../config/admobConfig';
import { useSocial } from '../context/SocialContext';
import { LocalAd } from '../types/social';
import { formatCount } from '../utils/formatters';

interface SponsoredAdCardProps {
  ad: LocalAd;
  compact?: boolean;
}

export const SponsoredAdCard: React.FC<SponsoredAdCardProps> = ({ ad, compact = false }) => {
  const {
    t,
    language,
    trackAdImpression,
    trackAdClick,
    hideAdForSession,
    setAdPrivacyModalOpen,
    setActiveTab,
  } = useSocial();

  useEffect(() => {
    trackAdImpression(ad.id);
  }, [ad.id, trackAdImpression]);

  const title = language === 'bn' && ad.titleBn ? ad.titleBn : ad.title;
  const description = language === 'bn' && ad.descriptionBn ? ad.descriptionBn : ad.description;
  const locationText = language === 'bn' && ad.locationBn ? ad.locationBn : ad.location;
  const categoryLabel = t.ads.categories[ad.category] || ad.category;
  const ctaText = t.ads.ctas[ad.ctaLabel] || t.ads.ctas.learn_more;

  const [showContactDetails, setShowContactDetails] = useState(false);

  const handlePrimaryCta = () => {
    trackAdClick(ad.id);
    if (ad.ctaLabel === 'whatsapp' && (ad.whatsappNumber || ad.contactPhone)) {
      const digits = (ad.whatsappNumber || ad.contactPhone).replace(/[^0-9]/g, '');
      window.open(`https://wa.me/${digits}`, '_blank', 'noopener,noreferrer');
      return;
    }
    if (ad.ctaLabel === 'visit_website' && ad.websiteUrl) {
      const url = /^https?:\/\//i.test(ad.websiteUrl) ? ad.websiteUrl : `https://${ad.websiteUrl}`;
      window.open(url, '_blank', 'noopener,noreferrer');
      return;
    }
    if (ad.ctaLabel === 'call_now' && ad.contactPhone) {
      setShowContactDetails(true);
      return;
    }
    setShowContactDetails((prev) => !prev);
  };

  return (
    <aside
      aria-label={`${t.sponsoredCard.sponsored}: ${ad.businessName}`}
      className="bg-amber-50/45 dark:bg-[#17211C] border border-amber-700/20 dark:border-amber-400/20 rounded-2xl overflow-hidden"
    >
      {/* Clear Sponsored Disclosure Strip (Unambiguous Separation From Organic Posts) */}
      <div className="px-4 py-2.5 bg-amber-100/65 dark:bg-amber-950/35 border-b border-amber-700/15 dark:border-amber-400/15 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0 text-xs">
          <Megaphone className="w-3.5 h-3.5 text-amber-800 dark:text-amber-300 shrink-0" />
          <span className="font-bold uppercase tracking-wider text-amber-900 dark:text-amber-200">
            {t.sponsoredCard.sponsored}
          </span>
          <span aria-hidden="true" className="text-amber-700/60 dark:text-amber-300/50">
            ·
          </span>
          <span className="text-amber-800 dark:text-amber-300/90 font-medium truncate">
            {t.sponsoredCard.paidAd}
          </span>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => setAdPrivacyModalOpen(true)}
            title={t.sponsoredCard.whyThisAd}
            className="min-h-[32px] px-2 py-1 rounded-lg text-[11px] font-medium text-slate-600 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5 flex items-center gap-1 cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            {!compact && <span className="hidden sm:inline">{t.sponsoredCard.whyThisAd}</span>}
          </button>
          <button
            type="button"
            onClick={() => hideAdForSession(ad.id)}
            title={t.sponsoredCard.hideAd}
            aria-label={t.sponsoredCard.hideAd}
            className="min-h-[32px] min-w-[32px] px-2 py-1 rounded-lg text-[11px] font-medium text-slate-600 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/5 flex items-center justify-center cursor-pointer"
          >
            <EyeOff className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className={compact ? 'p-3.5 space-y-2.5' : 'p-4 space-y-3'}>
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="font-display font-bold text-sm sm:text-base text-slate-900 dark:text-white truncate">
              {ad.businessName}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-1.5 mt-0.5">
              <span>{categoryLabel}</span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1">
                <MapPin className="w-3 h-3 text-[#0B6E4F] dark:text-emerald-400 shrink-0" />
                {locationText}
              </span>
            </p>
          </div>
        </div>

        <div className="space-y-1">
          <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 leading-snug">
            {title}
          </p>
          <p
            className={`text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed ${
              compact ? 'line-clamp-3' : ''
            }`}
          >
            {description}
          </p>
        </div>

        {ad.imageUrl && (
          <div className="rounded-xl overflow-hidden border border-amber-900/10 dark:border-white/10 bg-slate-100 dark:bg-black/20">
            <img
              src={ad.imageUrl}
              alt={ad.businessName}
              referrerPolicy="no-referrer"
              className={`w-full object-cover ${compact ? 'max-h-36' : 'max-h-72'}`}
            />
          </div>
        )}

        {showContactDetails && (
          <div className="rounded-xl bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 p-3 space-y-1.5 text-xs">
            <p className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 tabular-nums">
              <Phone className="w-3.5 h-3.5 text-[#0B6E4F] dark:text-emerald-400" />
              <a href={`tel:${ad.contactPhone}`} className="hover:underline">
                {ad.contactPhone}
              </a>
            </p>
            {ad.whatsappNumber && (
              <p className="text-slate-600 dark:text-slate-300 tabular-nums">
                WhatsApp: {ad.whatsappNumber}
              </p>
            )}
            {ad.contactEmail && (
              <p className="text-slate-600 dark:text-slate-300">{ad.contactEmail}</p>
            )}
            {ad.websiteUrl && (
              <a
                href={/^https?:\/\//i.test(ad.websiteUrl) ? ad.websiteUrl : `https://${ad.websiteUrl}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-[#0B6E4F] dark:text-emerald-300 font-semibold hover:underline"
              >
                <span>{ad.websiteUrl}</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        )}

        <div className="pt-1 flex flex-wrap items-center justify-between gap-2">
          <button
            type="button"
            onClick={handlePrimaryCta}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            {ad.ctaLabel === 'visit_website' ? (
              <ExternalLink className="w-3.5 h-3.5" />
            ) : (
              <Phone className="w-3.5 h-3.5" />
            )}
            <span>{ctaText}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('advertise')}
            className="min-h-[36px] px-2.5 py-1 rounded-lg text-[11px] font-medium text-slate-500 dark:text-slate-400 hover:text-[#0B6E4F] dark:hover:text-emerald-300 cursor-pointer"
          >
            {t.sponsoredCard.promoteBusiness}
          </button>
        </div>
      </div>
    </aside>
  );
};

interface AdMobTestSlotProps {
  variant: 'banner' | 'native';
}

export const AdMobTestSlot: React.FC<AdMobTestSlotProps> = ({ variant }) => {
  const {
    t,
    language,
    monetizationConfig,
    adConsentStatus,
    setAdPrivacyModalOpen,
  } = useSocial();

  const req = buildAdMobRequestOptions(monetizationConfig.admobEnvironment, adConsentStatus);

  useEffect(() => {
    if (!req.canShowAds) return;
    if (variant === 'banner' && monetizationConfig.admobBannerEnabled) {
      dispatchAndroidAdMobBridge('banner', monetizationConfig.admobEnvironment, adConsentStatus);
    } else if (variant === 'native' && monetizationConfig.admobNativeEnabled) {
      dispatchAndroidAdMobBridge('native', monetizationConfig.admobEnvironment, adConsentStatus);
    }
  }, [
    variant,
    req.canShowAds,
    monetizationConfig.admobBannerEnabled,
    monetizationConfig.admobNativeEnabled,
    monetizationConfig.admobEnvironment,
    adConsentStatus,
  ]);

  if (variant === 'banner' && !monetizationConfig.admobBannerEnabled) return null;
  if (variant === 'native' && !monetizationConfig.admobNativeEnabled) return null;
  if (adConsentStatus === 'essential_only') return null;

  const unitId =
    variant === 'banner' ? req.unitSet.bannerUnitId : req.unitSet.nativeUnitId;
  const hasNativeBridge =
    typeof window !== 'undefined' && Boolean(window.SylhetSocialAdMob?.isAndroidNativeHost?.());

  return (
    <aside
      aria-label={t.sponsoredCard.admobTestLabel}
      className="bg-slate-50 dark:bg-[#111B17] border border-dashed border-slate-300 dark:border-emerald-200/20 rounded-2xl p-3.5 sm:p-4 space-y-2"
    >
      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
        <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 font-semibold">
          <Smartphone className="w-3.5 h-3.5 text-[#0B6E4F] dark:text-emerald-400" />
          <span>{t.sponsoredCard.admobTestLabel}</span>
          <span aria-hidden="true">·</span>
          <span className="text-slate-500 dark:text-slate-400 font-normal">
            {hasNativeBridge
              ? t.sponsoredCard.admobAndroidBridgeReady
              : t.sponsoredCard.admobWebPreviewMode}
          </span>
        </div>

        <button
          type="button"
          onClick={() => setAdPrivacyModalOpen(true)}
          className="text-[11px] font-medium text-[#0B6E4F] dark:text-emerald-300 hover:underline flex items-center gap-1 cursor-pointer"
        >
          <ShieldCheck className="w-3 h-3" />
          <span>{t.consent.privacyLink}</span>
        </button>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-0.5">
        <div className="min-w-0 space-y-0.5">
          <p className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-100">
            {variant === 'banner'
              ? t.sponsoredCard.admobTestBannerTitle
              : t.sponsoredCard.admobTestNativeTitle}
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
            {t.sponsoredCard.admobTestBannerSubtitle}
          </p>
        </div>

        <div className="shrink-0 text-left sm:text-right">
          <code className="block text-[11px] font-mono text-slate-700 dark:text-emerald-200 bg-white dark:bg-[#0D1512] border border-slate-200 dark:border-emerald-200/15 px-2 py-1 rounded-lg">
            {unitId}
          </code>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {req.nonPersonalizedAds ? 'npa=1' : language === 'bn' ? 'সম্মতি সক্রিয়' : 'Consent OK'} ·{' '}
            {formatCount(monetizationConfig.feedAdInterval, language)}x
          </p>
        </div>
      </div>
    </aside>
  );
};
