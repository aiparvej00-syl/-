import React from 'react';
import { Bell, Home, MessageCircle, User, Users } from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { NavTab } from '../types/social';
import { formatCount } from '../utils/formatters';

export const MobileBottomNav: React.FC = () => {
  const {
    t,
    language,
    activeTab,
    setActiveTab,
    currentUser,
    openProfile,
    unreadMessagesCount,
    unreadNotificationsCount,
  } = useSocial();

  const tabs: {
    id: NavTab;
    label: string;
    icon: React.ReactNode;
    badge?: number;
    onClick: () => void;
  }[] = [
    {
      id: 'feed',
      label: t.nav.feed,
      icon: <Home className="w-5 h-5" />,
      onClick: () => setActiveTab('feed'),
    },
    {
      id: 'friends',
      label: t.nav.friends,
      icon: <Users className="w-5 h-5" />,
      badge: currentUser?.friendRequestsReceived.length || undefined,
      onClick: () => setActiveTab('friends'),
    },
    {
      id: 'messages',
      label: t.nav.messages,
      icon: <MessageCircle className="w-5 h-5" />,
      badge: unreadMessagesCount || undefined,
      onClick: () => setActiveTab('messages'),
    },
    {
      id: 'notifications',
      label: t.nav.notifications,
      icon: <Bell className="w-5 h-5" />,
      badge: unreadNotificationsCount || undefined,
      onClick: () => setActiveTab('notifications'),
    },
    {
      id: 'profile',
      label: t.nav.profile,
      icon: <User className="w-5 h-5" />,
      onClick: () => {
        if (currentUser) {
          openProfile(currentUser.id);
        } else {
          setActiveTab('profile');
        }
      },
    },
  ];

  return (
    <nav
      aria-label="Mobile bottom navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-white/95 dark:bg-[#14201B]/95 backdrop-blur-md border-t border-emerald-950/10 dark:border-emerald-200/10"
    >
      <div className="grid grid-cols-5 h-full max-w-md mx-auto">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={tab.onClick}
              className={`relative min-h-[44px] flex flex-col items-center justify-center gap-0.5 px-1 transition-colors ${
                isActive
                  ? 'text-[#0B6E4F] dark:text-emerald-300'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <div className="relative">
                {tab.icon}
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-[16px] h-[16px] px-1 rounded-full bg-[#0B6E4F] text-white text-[10px] font-bold tabular-nums flex items-center justify-center">
                    {formatCount(tab.badge, language)}
                  </span>
                )}
              </div>
              <span className="text-[11px] font-medium tracking-tight truncate max-w-full">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
