import React, { useMemo, useState } from 'react';
import {
  Compass,
  Edit3,
  Eye,
  EyeOff,
  MapPin,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { ASSET_IMAGES } from '../data/seedData';
import { useSocial } from '../context/SocialContext';
import {
  AttractionCategory,
  LocationLevel,
  LocationNode,
  TouristAttraction,
} from '../types/social';
import { formatCount } from '../utils/formatters';

const ATTRACTION_IMAGES: { label: string; url: string }[] = [
  { label: 'Madhabkunda Waterfall', url: ASSET_IMAGES.madhabkunda },
  { label: 'Lawachara Rainforest', url: ASSET_IMAGES.lawachara },
  { label: 'Madhabpur Lake', url: ASSET_IMAGES.madhabpurLake },
  { label: 'Haor / Baikka Beel', url: ASSET_IMAGES.haorWetland },
  { label: 'Manipuri Para Village', url: ASSET_IMAGES.manipuriPara },
  { label: 'Tea Garden Terrace', url: ASSET_IMAGES.teaGardenCover },
  { label: 'Ratargul Swamp Forest', url: ASSET_IMAGES.ratargul },
  { label: 'Jaflong / River Scene', url: ASSET_IMAGES.jaflong },
];

const CATEGORIES: AttractionCategory[] = [
  'waterfall',
  'forest',
  'lake',
  'haor',
  'tea_garden',
  'cultural',
  'river',
  'heritage',
];

const LEVELS: LocationLevel[] = ['division', 'district', 'upazila', 'union', 'village'];

export const AdminLocationsSection: React.FC = () => {
  const {
    t,
    language,
    locations,
    attractions,
    locationsSyncedToFirestore,
    adminSeedLocationsAndAttractions,
    adminSaveLocationNode,
    adminDeleteLocationNode,
    adminSaveAttraction,
    adminDeleteAttraction,
  } = useSocial();

  const [subTab, setSubTab] = useState<'locations' | 'attractions'>('locations');
  const [dirSearch, setDirSearch] = useState('');
  const [levelFilter, setLevelFilter] = useState<'all' | LocationLevel>('all');
  const [districtFilter, setDistrictFilter] = useState<string>('all');
  const [syncing, setSyncing] = useState(false);

  // Location Form State
  const [locFormOpen, setLocFormOpen] = useState(false);
  const [editingLocId, setEditingLocId] = useState<string | undefined>(undefined);
  const [locLevel, setLocLevel] = useState<LocationLevel>('village');
  const [locName, setLocName] = useState('');
  const [locNameBn, setLocNameBn] = useState('');
  const [locDivId, setLocDivId] = useState('div_sylhet');
  const [locDistId, setLocDistId] = useState('dist_moulvibazar');
  const [locUpaId, setLocUpaId] = useState('upa_kamalganj');
  const [locUnionId, setLocUnionId] = useState('');
  const [locSortOrder, setLocSortOrder] = useState<number>(10);
  const [locActive, setLocActive] = useState(true);

  // Attraction Form State
  const [attrFormOpen, setAttrFormOpen] = useState(false);
  const [editingAttrId, setEditingAttrId] = useState<string | undefined>(undefined);
  const [attrName, setAttrName] = useState('');
  const [attrNameBn, setAttrNameBn] = useState('');
  const [attrCategory, setAttrCategory] = useState<AttractionCategory>('waterfall');
  const [attrDistId, setAttrDistId] = useState('dist_moulvibazar');
  const [attrUpaId, setAttrUpaId] = useState('upa_barlekha');
  const [attrUnionId, setAttrUnionId] = useState('');
  const [attrVillage, setAttrVillage] = useState('');
  const [attrVillageBn, setAttrVillageBn] = useState('');
  const [attrSummary, setAttrSummary] = useState('');
  const [attrSummaryBn, setAttrSummaryBn] = useState('');
  const [attrDesc, setAttrDesc] = useState('');
  const [attrDescBn, setAttrDescBn] = useState('');
  const [attrImageUrl, setAttrImageUrl] = useState(ASSET_IMAGES.madhabkunda);
  const [attrFeatured, setAttrFeatured] = useState(true);
  const [attrActive, setAttrActive] = useState(true);

  const sortedLocations = useMemo(
    () =>
      [...locations].sort(
        (a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name)
      ),
    [locations]
  );

  const divisions = useMemo(
    () => sortedLocations.filter((l) => l.level === 'division'),
    [sortedLocations]
  );
  const districts = useMemo(
    () => sortedLocations.filter((l) => l.level === 'district'),
    [sortedLocations]
  );
  const upazilas = useMemo(
    () => sortedLocations.filter((l) => l.level === 'upazila'),
    [sortedLocations]
  );
  const unions = useMemo(
    () => sortedLocations.filter((l) => l.level === 'union'),
    [sortedLocations]
  );

  const locFormUpazilas = useMemo(
    () => upazilas.filter((u) => !locDistId || u.districtId === locDistId || u.parentId === locDistId),
    [upazilas, locDistId]
  );

  const locFormUnions = useMemo(
    () => unions.filter((u) => !locUpaId || u.upazilaId === locUpaId || u.parentId === locUpaId),
    [unions, locUpaId]
  );

  const attrFormUpazilas = useMemo(
    () => upazilas.filter((u) => !attrDistId || u.districtId === attrDistId || u.parentId === attrDistId),
    [upazilas, attrDistId]
  );

  const attrFormUnions = useMemo(
    () => unions.filter((u) => !attrUpaId || u.upazilaId === attrUpaId || u.parentId === attrUpaId),
    [unions, attrUpaId]
  );

  const q = dirSearch.trim().toLowerCase();

  const filteredLocations = useMemo(() => {
    return sortedLocations.filter((node) => {
      if (levelFilter !== 'all' && node.level !== levelFilter) return false;
      if (districtFilter !== 'all' && node.districtId !== districtFilter && node.id !== districtFilter) {
        return false;
      }
      if (!q) return true;
      return (
        node.name.toLowerCase().includes(q) ||
        node.nameBn.toLowerCase().includes(q) ||
        node.id.toLowerCase().includes(q)
      );
    });
  }, [sortedLocations, levelFilter, districtFilter, q]);

  const filteredAttractions = useMemo(() => {
    return [...attractions]
      .sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured) || a.name.localeCompare(b.name))
      .filter((attr) => {
        if (districtFilter !== 'all' && attr.districtId !== districtFilter) return false;
        if (!q) return true;
        return (
          attr.name.toLowerCase().includes(q) ||
          attr.nameBn.toLowerCase().includes(q) ||
          attr.upazilaName.toLowerCase().includes(q) ||
          attr.districtName.toLowerCase().includes(q) ||
          attr.locationSummary.toLowerCase().includes(q)
        );
      });
  }, [attractions, districtFilter, q]);

  const getNodeName = (id?: string) => {
    if (!id) return '';
    const found = locations.find((l) => l.id === id);
    return found ? (language === 'bn' ? found.nameBn || found.name : found.name) : id;
  };

  const resetLocationForm = () => {
    setEditingLocId(undefined);
    setLocLevel('village');
    setLocName('');
    setLocNameBn('');
    setLocDivId(divisions[0]?.id || 'div_sylhet');
    setLocDistId('dist_moulvibazar');
    setLocUpaId('upa_kamalganj');
    setLocUnionId('');
    setLocSortOrder(10);
    setLocActive(true);
    setLocFormOpen(true);
  };

  const openEditLocation = (node: LocationNode) => {
    setEditingLocId(node.id);
    setLocLevel(node.level);
    setLocName(node.name);
    setLocNameBn(node.nameBn);
    setLocDivId(node.divisionId || 'div_sylhet');
    setLocDistId(node.districtId || 'dist_moulvibazar');
    setLocUpaId(node.upazilaId || '');
    setLocUnionId(node.unionId || '');
    setLocSortOrder(node.sortOrder || 10);
    setLocActive(node.isActive);
    setLocFormOpen(true);
  };

  const handleSaveLocation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!locName.trim()) return;

    const parentId =
      locLevel === 'division'
        ? ''
        : locLevel === 'district'
        ? locDivId
        : locLevel === 'upazila'
        ? locDistId
        : locLevel === 'union'
        ? locUpaId
        : locUnionId || locUpaId;

    await adminSaveLocationNode({
      id: editingLocId,
      level: locLevel,
      name: locName,
      nameBn: locNameBn || locName,
      parentId,
      divisionId: locLevel === 'division' ? editingLocId || '' : locDivId,
      districtId:
        locLevel === 'division' || locLevel === 'district' ? (locLevel === 'district' ? editingLocId || '' : '') : locDistId,
      upazilaId:
        locLevel === 'union' || locLevel === 'village' ? locUpaId : locLevel === 'upazila' ? editingLocId || '' : '',
      unionId: locLevel === 'village' ? locUnionId : locLevel === 'union' ? editingLocId || '' : '',
      isActive: locActive,
      sortOrder: Number(locSortOrder) || 10,
    });
    setLocFormOpen(false);
  };

  const resetAttractionForm = () => {
    setEditingAttrId(undefined);
    setAttrName('');
    setAttrNameBn('');
    setAttrCategory('waterfall');
    setAttrDistId('dist_moulvibazar');
    setAttrUpaId('upa_barlekha');
    setAttrUnionId('');
    setAttrVillage('');
    setAttrVillageBn('');
    setAttrSummary('');
    setAttrSummaryBn('');
    setAttrDesc('');
    setAttrDescBn('');
    setAttrImageUrl(ASSET_IMAGES.madhabkunda);
    setAttrFeatured(true);
    setAttrActive(true);
    setAttrFormOpen(true);
  };

  const openEditAttraction = (attr: TouristAttraction) => {
    setEditingAttrId(attr.id);
    setAttrName(attr.name);
    setAttrNameBn(attr.nameBn);
    setAttrCategory(attr.category);
    setAttrDistId(attr.districtId);
    setAttrUpaId(attr.upazilaId);
    setAttrUnionId(attr.unionId || '');
    setAttrVillage(attr.villageName || '');
    setAttrVillageBn(attr.villageNameBn || '');
    setAttrSummary(attr.locationSummary);
    setAttrSummaryBn(attr.locationSummaryBn);
    setAttrDesc(attr.description || '');
    setAttrDescBn(attr.descriptionBn || '');
    setAttrImageUrl(attr.imageUrl || ASSET_IMAGES.madhabkunda);
    setAttrFeatured(attr.isFeatured);
    setAttrActive(attr.isActive);
    setAttrFormOpen(true);
  };

  const handleSaveAttraction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!attrName.trim() || !attrDistId || !attrUpaId) return;

    const distObj = districts.find((d) => d.id === attrDistId);
    const upaObj = upazilas.find((u) => u.id === attrUpaId);
    const uniObj = unions.find((u) => u.id === attrUnionId);

    const autoSummaryEn =
      attrSummary.trim() || `${upaObj?.name || ''}, ${distObj?.name || ''}`.trim();
    const autoSummaryBn =
      attrSummaryBn.trim() ||
      `${upaObj?.nameBn || upaObj?.name || ''}, ${distObj?.nameBn || distObj?.name || ''}`.trim();

    await adminSaveAttraction({
      id: editingAttrId,
      name: attrName,
      nameBn: attrNameBn || attrName,
      category: attrCategory,
      divisionId: distObj?.divisionId || 'div_sylhet',
      districtId: attrDistId,
      districtName: distObj?.name || 'Moulvibazar',
      districtNameBn: distObj?.nameBn || 'মৌলভীবাজার',
      upazilaId: attrUpaId,
      upazilaName: upaObj?.name || '',
      upazilaNameBn: upaObj?.nameBn || upaObj?.name || '',
      unionId: attrUnionId || '',
      unionName: uniObj?.name || '',
      unionNameBn: uniObj?.nameBn || '',
      villageName: attrVillage,
      villageNameBn: attrVillageBn || attrVillage,
      locationSummary: autoSummaryEn,
      locationSummaryBn: autoSummaryBn,
      description: attrDesc,
      descriptionBn: attrDescBn || attrDesc,
      imageUrl: attrImageUrl,
      isFeatured: attrFeatured,
      isActive: attrActive,
    });
    setAttrFormOpen(false);
  };

  const handleSyncOfficial = async () => {
    setSyncing(true);
    try {
      await adminSeedLocationsAndAttractions();
    } finally {
      setSyncing(false);
    }
  };

  const inputClass =
    'w-full min-h-[42px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700';

  return (
    <div className="space-y-4">
      {/* Control Header */}
      <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setSubTab('locations')}
              className={`min-h-[40px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5 cursor-pointer ${
                subTab === 'locations'
                  ? 'bg-[#0B6E4F] text-white'
                  : 'bg-[#F4F6F4] dark:bg-[#0D1512] text-slate-600 dark:text-slate-300'
              }`}
            >
              <MapPin className="w-4 h-4" />
              <span>
                {t.admin.locations.locationsSubtab} ({formatCount(locations.length, language)})
              </span>
            </button>

            <button
              type="button"
              onClick={() => setSubTab('attractions')}
              className={`min-h-[40px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5 cursor-pointer ${
                subTab === 'attractions'
                  ? 'bg-[#0B6E4F] text-white'
                  : 'bg-[#F4F6F4] dark:bg-[#0D1512] text-slate-600 dark:text-slate-300'
              }`}
            >
              <Compass className="w-4 h-4" />
              <span>
                {t.admin.locations.attractionsSubtab} ({formatCount(attractions.length, language)})
              </span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={syncing}
              onClick={() => void handleSyncOfficial()}
              className="min-h-[40px] px-3.5 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
              <span>{t.admin.locations.seedDefaults}</span>
              {locationsSyncedToFirestore && (
                <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-bold">
                  · Synced
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={subTab === 'locations' ? resetLocationForm : resetAttractionForm}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>
                {subTab === 'locations'
                  ? t.admin.locations.addLocation
                  : t.admin.locations.addAttraction}
              </span>
            </button>
          </div>
        </div>

        {/* Search & Filter Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <div className="relative sm:col-span-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={dirSearch}
              onChange={(e) => setDirSearch(e.target.value)}
              placeholder={t.locationsPage.searchPlaceholder}
              className="w-full min-h-[40px] pl-9 pr-3 py-1.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm"
            />
          </div>

          <select
            value={districtFilter}
            onChange={(e) => setDistrictFilter(e.target.value)}
            className={inputClass}
          >
            <option value="all">{t.locationsPage.allDistricts}</option>
            {districts.map((dist) => (
              <option key={dist.id} value={dist.id}>
                {language === 'bn' ? dist.nameBn : dist.name}
              </option>
            ))}
          </select>

          {subTab === 'locations' && (
            <select
              value={levelFilter}
              onChange={(e) => setLevelFilter(e.target.value as 'all' | LocationLevel)}
              className={inputClass}
            >
              <option value="all">
                {language === 'bn' ? 'সকল স্তর' : 'All Hierarchy Levels'}
              </option>
              {LEVELS.map((lvl) => (
                <option key={lvl} value={lvl}>
                  {lvl.toUpperCase()}
                </option>
              ))}
            </select>
          )}
        </div>
      </section>

      {/* Add / Edit Location Form */}
      {subTab === 'locations' && locFormOpen && (
        <form
          onSubmit={(e) => void handleSaveLocation(e)}
          className="bg-white dark:bg-[#14201B] border border-emerald-700/30 rounded-2xl p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
              {editingLocId ? t.admin.locations.editLocation : t.admin.locations.addLocation}
            </h3>
            <button
              type="button"
              onClick={() => setLocFormOpen(false)}
              className="text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
            >
              {t.actions.cancel}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.locations.levelLabel}
              </label>
              <select
                value={locLevel}
                disabled={Boolean(editingLocId)}
                onChange={(e) => setLocLevel(e.target.value as LocationLevel)}
                className={inputClass}
              >
                {LEVELS.map((lvl) => (
                  <option key={lvl} value={lvl}>
                    {lvl}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.locations.nameEnLabel}
              </label>
              <input
                type="text"
                required
                value={locName}
                onChange={(e) => setLocName(e.target.value)}
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.locations.nameBnLabel}
              </label>
              <input
                type="text"
                value={locNameBn}
                onChange={(e) => setLocNameBn(e.target.value)}
                className={inputClass}
              />
            </div>

            {locLevel !== 'division' && (
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {t.locationsPage.divisionLabel}
                </label>
                <select
                  value={locDivId}
                  onChange={(e) => setLocDivId(e.target.value)}
                  className={inputClass}
                >
                  {divisions.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {(locLevel === 'upazila' || locLevel === 'union' || locLevel === 'village') && (
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {t.locationsPage.districtLabel}
                </label>
                <select
                  value={locDistId}
                  onChange={(e) => {
                    setLocDistId(e.target.value);
                    setLocUpaId('');
                    setLocUnionId('');
                  }}
                  className={inputClass}
                >
                  <option value="">{t.locationsPage.selectDistrict}</option>
                  {districts.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {(locLevel === 'union' || locLevel === 'village') && (
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {t.locationsPage.upazilaLabel}
                </label>
                <select
                  value={locUpaId}
                  onChange={(e) => {
                    setLocUpaId(e.target.value);
                    setLocUnionId('');
                  }}
                  className={inputClass}
                >
                  <option value="">{t.locationsPage.selectUpazila}</option>
                  {locFormUpazilas.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {locLevel === 'village' && (
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {t.locationsPage.unionLabel}
                </label>
                <select
                  value={locUnionId}
                  onChange={(e) => setLocUnionId(e.target.value)}
                  className={inputClass}
                >
                  <option value="">{t.locationsPage.selectUnion}</option>
                  {locFormUnions.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Sort Order
              </label>
              <input
                type="number"
                min={0}
                max={999}
                value={locSortOrder}
                onChange={(e) => setLocSortOrder(Number(e.target.value) || 0)}
                className={inputClass}
              />
            </div>

            <label className="flex items-center gap-2 pt-5 cursor-pointer">
              <input
                type="checkbox"
                checked={locActive}
                onChange={(e) => setLocActive(e.target.checked)}
                className="w-4 h-4 accent-[#0B6E4F]"
              />
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                {t.admin.locations.activeLabel}
              </span>
            </label>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setLocFormOpen(false)}
              className="min-h-[40px] px-4 py-2 rounded-xl border border-emerald-950/15 text-xs font-semibold cursor-pointer"
            >
              {t.actions.cancel}
            </button>
            <button
              type="submit"
              className="min-h-[40px] px-5 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold cursor-pointer"
            >
              {t.admin.locations.saveItem}
            </button>
          </div>
        </form>
      )}

      {/* Add / Edit Attraction Form */}
      {subTab === 'attractions' && attrFormOpen && (
        <form
          onSubmit={(e) => void handleSaveAttraction(e)}
          className="bg-white dark:bg-[#14201B] border border-emerald-700/30 rounded-2xl p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
              {editingAttrId ? t.admin.locations.editAttraction : t.admin.locations.addAttraction}
            </h3>
            <button
              type="button"
              onClick={() => setAttrFormOpen(false)}
              className="text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
            >
              {t.actions.cancel}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.locations.nameEnLabel}
              </label>
              <input
                type="text"
                required
                value={attrName}
                onChange={(e) => setAttrName(e.target.value)}
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.locations.nameBnLabel}
              </label>
              <input
                type="text"
                value={attrNameBn}
                onChange={(e) => setAttrNameBn(e.target.value)}
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.locations.categoryLabel}
              </label>
              <select
                value={attrCategory}
                onChange={(e) => setAttrCategory(e.target.value as AttractionCategory)}
                className={inputClass}
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {t.locationsPage.categories[cat]}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.locationsPage.districtLabel}
              </label>
              <select
                required
                value={attrDistId}
                onChange={(e) => {
                  setAttrDistId(e.target.value);
                  setAttrUpaId('');
                  setAttrUnionId('');
                }}
                className={inputClass}
              >
                {districts.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.locationsPage.upazilaLabel}
              </label>
              <select
                required
                value={attrUpaId}
                onChange={(e) => {
                  setAttrUpaId(e.target.value);
                  setAttrUnionId('');
                }}
                className={inputClass}
              >
                <option value="">{t.locationsPage.selectUpazila}</option>
                {attrFormUpazilas.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.locationsPage.unionLabel}
              </label>
              <select
                value={attrUnionId}
                onChange={(e) => setAttrUnionId(e.target.value)}
                className={inputClass}
              >
                <option value="">{t.locationsPage.selectUnion}</option>
                {attrFormUnions.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.locationsPage.villageLabel} (EN)
              </label>
              <input
                type="text"
                value={attrVillage}
                onChange={(e) => setAttrVillage(e.target.value)}
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.locationsPage.villageLabel} (BN)
              </label>
              <input
                type="text"
                value={attrVillageBn}
                onChange={(e) => setAttrVillageBn(e.target.value)}
                className={inputClass}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Image Scene Preset
              </label>
              <select
                value={attrImageUrl}
                onChange={(e) => setAttrImageUrl(e.target.value)}
                className={inputClass}
              >
                {ATTRACTION_IMAGES.map((img) => (
                  <option key={img.url} value={img.url}>
                    {img.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2 lg:col-span-1">
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.locations.locationSummaryEn}
              </label>
              <input
                type="text"
                placeholder="e.g. Kamalganj, Moulvibazar"
                value={attrSummary}
                onChange={(e) => setAttrSummary(e.target.value)}
                className={inputClass}
              />
            </div>

            <div className="sm:col-span-2 lg:col-span-1">
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.locations.locationSummaryBn}
              </label>
              <input
                type="text"
                placeholder="কমলগঞ্জ, মৌলভীবাজার"
                value={attrSummaryBn}
                onChange={(e) => setAttrSummaryBn(e.target.value)}
                className={inputClass}
              />
            </div>

            <div className="flex items-center gap-4 pt-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={attrFeatured}
                  onChange={(e) => setAttrFeatured(e.target.checked)}
                  className="w-4 h-4 accent-[#0B6E4F]"
                />
                <span className="text-xs font-semibold">{t.admin.locations.featuredLabel}</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={attrActive}
                  onChange={(e) => setAttrActive(e.target.checked)}
                  className="w-4 h-4 accent-[#0B6E4F]"
                />
                <span className="text-xs font-semibold">{t.admin.locations.activeLabel}</span>
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.locations.descEn}
              </label>
              <textarea
                rows={2}
                value={attrDesc}
                onChange={(e) => setAttrDesc(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm resize-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {t.admin.locations.descBn}
              </label>
              <textarea
                rows={2}
                value={attrDescBn}
                onChange={(e) => setAttrDescBn(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm resize-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setAttrFormOpen(false)}
              className="min-h-[40px] px-4 py-2 rounded-xl border border-emerald-950/15 text-xs font-semibold cursor-pointer"
            >
              {t.actions.cancel}
            </button>
            <button
              type="submit"
              className="min-h-[40px] px-5 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold cursor-pointer"
            >
              {t.admin.locations.saveItem}
            </button>
          </div>
        </form>
      )}

      {/* List: Hierarchical Locations */}
      {subTab === 'locations' && (
        <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl divide-y divide-emerald-950/10 dark:divide-emerald-200/10">
          {filteredLocations.length === 0 ? (
            <p className="p-8 text-center text-sm text-slate-500 dark:text-slate-400">
              {t.locationsPage.noLocationsMatch}
            </p>
          ) : (
            filteredLocations.map((node) => {
              const lineage = [
                getNodeName(node.divisionId),
                getNodeName(node.districtId),
                getNodeName(node.upazilaId),
                getNodeName(node.unionId),
              ]
                .filter(Boolean)
                .filter((v, idx, arr) => arr.indexOf(v) === idx)
                .join(' › ');

              return (
                <div
                  key={node.id}
                  className="p-3.5 sm:px-5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                >
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[11px] font-bold uppercase tracking-wide text-[#0B6E4F] dark:text-emerald-300">
                        {node.level}
                      </span>
                      <span className="text-sm font-bold text-slate-900 dark:text-white">
                        {node.name}
                      </span>
                      {node.nameBn && (
                        <span className="text-xs text-slate-500 dark:text-slate-400">
                          ({node.nameBn})
                        </span>
                      )}
                      {!node.isActive && (
                        <span className="text-[11px] font-semibold text-rose-600 dark:text-rose-400">
                          · Hidden
                        </span>
                      )}
                    </div>
                    {lineage && (
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                        {lineage}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() =>
                        void adminSaveLocationNode({
                          id: node.id,
                          level: node.level,
                          name: node.name,
                          nameBn: node.nameBn,
                          parentId: node.parentId,
                          divisionId: node.divisionId,
                          districtId: node.districtId,
                          upazilaId: node.upazilaId,
                          unionId: node.unionId,
                          isActive: !node.isActive,
                          sortOrder: node.sortOrder,
                        })
                      }
                      aria-label="Toggle visibility"
                      className="min-h-[36px] px-2.5 py-1 rounded-lg border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1 cursor-pointer"
                    >
                      {node.isActive ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    </button>

                    <button
                      type="button"
                      onClick={() => openEditLocation(node)}
                      aria-label={t.admin.locations.editLocation}
                      className="min-h-[36px] px-2.5 py-1 rounded-lg border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => void adminDeleteLocationNode(node.id)}
                      aria-label={t.admin.locations.deleteConfirm}
                      className="min-h-[36px] px-2.5 py-1 rounded-lg border border-rose-200 dark:border-rose-800/40 text-xs font-semibold text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </section>
      )}

      {/* List: Tourist Attractions */}
      {subTab === 'attractions' && (
        <section className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filteredAttractions.map((attr) => (
            <div
              key={attr.id}
              className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 flex flex-col justify-between gap-3"
            >
              <div className="flex items-start gap-3">
                <img
                  src={attr.imageUrl || ASSET_IMAGES.teaGardenCover}
                  alt={attr.name}
                  referrerPolicy="no-referrer"
                  className="w-20 h-16 rounded-xl object-cover shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] font-semibold text-[#0B6E4F] dark:text-emerald-400">
                    {t.locationsPage.categories[attr.category]}
                    {attr.isFeatured ? ' · Featured' : ''}
                    {!attr.isActive ? ' · Hidden' : ''}
                  </p>
                  <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                    {language === 'bn' ? attr.nameBn : attr.name}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                    {language === 'bn' ? attr.locationSummaryBn : attr.locationSummary}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-1.5 pt-2 border-t border-emerald-950/10 dark:border-emerald-200/10">
                <button
                  type="button"
                  onClick={() =>
                    void adminSaveAttraction({
                      ...attr,
                      isFeatured: !attr.isFeatured,
                    })
                  }
                  className={`min-h-[36px] px-2.5 py-1 rounded-lg border text-xs font-semibold flex items-center gap-1 cursor-pointer ${
                    attr.isFeatured
                      ? 'border-emerald-700/30 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300'
                      : 'border-emerald-950/15 dark:border-emerald-200/15 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() =>
                    void adminSaveAttraction({
                      ...attr,
                      isActive: !attr.isActive,
                    })
                  }
                  className="min-h-[36px] px-2.5 py-1 rounded-lg border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1 cursor-pointer"
                >
                  {attr.isActive ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => openEditAttraction(attr)}
                  className="min-h-[36px] px-2.5 py-1 rounded-lg border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1 cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => void adminDeleteAttraction(attr.id)}
                  className="min-h-[36px] px-2.5 py-1 rounded-lg border border-rose-200 dark:border-rose-800/40 text-xs font-semibold text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </section>
      )}
    </div>
  );
};
