import React, { useMemo, useState } from 'react';
import { Compass, MapPin, X } from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { LocationNode } from '../types/social';

interface HierarchicalLocationSelectProps {
  valueEn?: string;
  valueBn?: string;
  onChange: (loc: { en: string; bn: string } | null) => void;
  includeAttractionShortcut?: boolean;
  compact?: boolean;
}

function clampLocationText(text: string): string {
  return text.trim().slice(0, 118);
}

export const HierarchicalLocationSelect: React.FC<HierarchicalLocationSelectProps> = ({
  valueEn,
  valueBn,
  onChange,
  includeAttractionShortcut = false,
  compact = false,
}) => {
  const { locations, attractions, language, t } = useSocial();

  const activeLocations = useMemo(
    () =>
      locations
        .filter((l) => l.isActive)
        .sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name)),
    [locations]
  );

  const activeAttractions = useMemo(
    () =>
      attractions
        .filter((a) => a.isActive)
        .sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured) || a.name.localeCompare(b.name)),
    [attractions]
  );

  const divisions = useMemo(
    () => activeLocations.filter((l) => l.level === 'division'),
    [activeLocations]
  );

  const [divisionId, setDivisionId] = useState<string>(() => divisions[0]?.id || 'div_sylhet');
  const [districtId, setDistrictId] = useState<string>('');
  const [upazilaId, setUpazilaId] = useState<string>('');
  const [unionId, setUnionId] = useState<string>('');
  const [villageId, setVillageId] = useState<string>('');
  const [selectedAttractionId, setSelectedAttractionId] = useState<string>('');

  const districts = useMemo(
    () =>
      activeLocations.filter(
        (l) => l.level === 'district' && (!divisionId || l.divisionId === divisionId || l.parentId === divisionId)
      ),
    [activeLocations, divisionId]
  );

  const upazilas = useMemo(
    () =>
      activeLocations.filter(
        (l) => l.level === 'upazila' && districtId && (l.districtId === districtId || l.parentId === districtId)
      ),
    [activeLocations, districtId]
  );

  const unions = useMemo(
    () =>
      activeLocations.filter(
        (l) => l.level === 'union' && upazilaId && (l.upazilaId === upazilaId || l.parentId === upazilaId)
      ),
    [activeLocations, upazilaId]
  );

  const villages = useMemo(
    () =>
      activeLocations.filter(
        (l) =>
          l.level === 'village' &&
          (unionId
            ? l.unionId === unionId || l.parentId === unionId
            : upazilaId && l.upazilaId === upazilaId)
      ),
    [activeLocations, unionId, upazilaId]
  );

  const findById = (id: string): LocationNode | undefined =>
    activeLocations.find((l) => l.id === id);

  const emitHierarchy = (
    nextDivId: string,
    nextDistId: string,
    nextUpaId: string,
    nextUniId: string,
    nextVilId: string
  ) => {
    const divNode = findById(nextDivId);
    const distNode = findById(nextDistId);
    const upaNode = findById(nextUpaId);
    const uniNode = findById(nextUniId);
    const vilNode = findById(nextVilId);

    const enParts: string[] = [];
    const bnParts: string[] = [];

    if (vilNode) {
      enParts.push(vilNode.name);
      bnParts.push(vilNode.nameBn || vilNode.name);
    }
    if (uniNode) {
      enParts.push(uniNode.name);
      bnParts.push(uniNode.nameBn || uniNode.name);
    }
    if (upaNode) {
      enParts.push(upaNode.name);
      bnParts.push(upaNode.nameBn || upaNode.name);
    }
    if (distNode) {
      enParts.push(distNode.name);
      bnParts.push(distNode.nameBn || distNode.name);
    } else if (divNode && enParts.length === 0) {
      enParts.push(divNode.name);
      bnParts.push(divNode.nameBn || divNode.name);
    }

    if (enParts.length === 0) {
      onChange(null);
      return;
    }

    onChange({
      en: clampLocationText(enParts.join(', ')),
      bn: clampLocationText(bnParts.join(', ')),
    });
  };

  const handleDivisionChange = (nextId: string) => {
    setDivisionId(nextId);
    setDistrictId('');
    setUpazilaId('');
    setUnionId('');
    setVillageId('');
    setSelectedAttractionId('');
    emitHierarchy(nextId, '', '', '', '');
  };

  const handleDistrictChange = (nextId: string) => {
    setDistrictId(nextId);
    setUpazilaId('');
    setUnionId('');
    setVillageId('');
    setSelectedAttractionId('');
    emitHierarchy(divisionId, nextId, '', '', '');
  };

  const handleUpazilaChange = (nextId: string) => {
    setUpazilaId(nextId);
    setUnionId('');
    setVillageId('');
    setSelectedAttractionId('');
    emitHierarchy(divisionId, districtId, nextId, '', '');
  };

  const handleUnionChange = (nextId: string) => {
    setUnionId(nextId);
    setVillageId('');
    setSelectedAttractionId('');
    emitHierarchy(divisionId, districtId, upazilaId, nextId, '');
  };

  const handleVillageChange = (nextId: string) => {
    setVillageId(nextId);
    setSelectedAttractionId('');
    emitHierarchy(divisionId, districtId, upazilaId, unionId, nextId);
  };

  const handleAttractionShortcut = (attrId: string) => {
    setSelectedAttractionId(attrId);
    if (!attrId) {
      emitHierarchy(divisionId, districtId, upazilaId, unionId, villageId);
      return;
    }
    const attr = activeAttractions.find((a) => a.id === attrId);
    if (!attr) return;
    if (attr.divisionId) setDivisionId(attr.divisionId);
    if (attr.districtId) setDistrictId(attr.districtId);
    if (attr.upazilaId) setUpazilaId(attr.upazilaId);
    setUnionId(attr.unionId || '');
    setVillageId('');

    onChange({
      en: clampLocationText(`${attr.name}, ${attr.upazilaName}, ${attr.districtName}`),
      bn: clampLocationText(
        `${attr.nameBn || attr.name}, ${attr.upazilaNameBn || attr.upazilaName}, ${attr.districtNameBn || attr.districtName}`
      ),
    });
  };

  const handleClear = () => {
    setDistrictId('');
    setUpazilaId('');
    setUnionId('');
    setVillageId('');
    setSelectedAttractionId('');
    onChange(null);
  };

  const labelText = language === 'bn' ? valueBn || valueEn : valueEn || valueBn;
  const selectClass =
    'w-full min-h-[40px] px-3 py-1.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-700 disabled:opacity-50';

  return (
    <div
      className={`rounded-xl border border-emerald-950/10 dark:border-emerald-200/10 bg-[#F8FAF8] dark:bg-[#0F1915] ${
        compact ? 'p-3 space-y-2.5' : 'p-3.5 space-y-3'
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800 dark:text-emerald-300 min-w-0">
          <MapPin className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">
            {labelText || (language === 'bn' ? 'বিভাগ → জেলা → উপজেলা → ইউনিয়ন → গ্রাম' : 'Division → District → Upazila → Union → Village')}
          </span>
        </div>
        {(valueEn || districtId) && (
          <button
            type="button"
            onClick={handleClear}
            className="text-xs font-medium text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 flex items-center gap-1 shrink-0 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
            <span>{t.locationsPage.clearFilters}</span>
          </button>
        )}
      </div>

      {includeAttractionShortcut && activeAttractions.length > 0 && (
        <div className="flex items-center gap-2">
          <Compass className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
          <select
            value={selectedAttractionId}
            onChange={(e) => handleAttractionShortcut(e.target.value)}
            aria-label={t.locationsPage.attractionLabel}
            className={selectClass}
          >
            <option value="">
              {language === 'bn'
                ? 'অথবা সরাসরি পর্যটন কেন্দ্র বেছে নিন...'
                : 'Quick-tag a tourist attraction (optional)...'}
            </option>
            {activeAttractions.map((attr) => (
              <option key={attr.id} value={attr.id}>
                {language === 'bn' ? attr.nameBn : attr.name} —{' '}
                {language === 'bn' ? attr.upazilaNameBn || attr.upazilaName : attr.upazilaName}
              </option>
            ))}
          </select>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <select
          value={divisionId}
          onChange={(e) => handleDivisionChange(e.target.value)}
          aria-label={t.locationsPage.divisionLabel}
          className={selectClass}
        >
          <option value="">{t.locationsPage.selectDivision}</option>
          {divisions.map((item) => (
            <option key={item.id} value={item.id}>
              {language === 'bn' ? item.nameBn : item.name}
            </option>
          ))}
        </select>

        <select
          value={districtId}
          onChange={(e) => handleDistrictChange(e.target.value)}
          aria-label={t.locationsPage.districtLabel}
          disabled={!divisionId}
          className={selectClass}
        >
          <option value="">{t.locationsPage.selectDistrict}</option>
          {districts.map((item) => (
            <option key={item.id} value={item.id}>
              {language === 'bn' ? item.nameBn : item.name}
            </option>
          ))}
        </select>

        <select
          value={upazilaId}
          onChange={(e) => handleUpazilaChange(e.target.value)}
          aria-label={t.locationsPage.upazilaLabel}
          disabled={!districtId}
          className={selectClass}
        >
          <option value="">{t.locationsPage.selectUpazila}</option>
          {upazilas.map((item) => (
            <option key={item.id} value={item.id}>
              {language === 'bn' ? item.nameBn : item.name}
            </option>
          ))}
        </select>

        <select
          value={unionId}
          onChange={(e) => handleUnionChange(e.target.value)}
          aria-label={t.locationsPage.unionLabel}
          disabled={!upazilaId || unions.length === 0}
          className={selectClass}
        >
          <option value="">{t.locationsPage.selectUnion}</option>
          {unions.map((item) => (
            <option key={item.id} value={item.id}>
              {language === 'bn' ? item.nameBn : item.name}
            </option>
          ))}
        </select>
      </div>

      {villages.length > 0 && (
        <select
          value={villageId}
          onChange={(e) => handleVillageChange(e.target.value)}
          aria-label={t.locationsPage.villageLabel}
          className={selectClass}
        >
          <option value="">{t.locationsPage.selectVillage}</option>
          {villages.map((item) => (
            <option key={item.id} value={item.id}>
              {language === 'bn' ? item.nameBn : item.name}
            </option>
          ))}
        </select>
      )}
    </div>
  );
};
