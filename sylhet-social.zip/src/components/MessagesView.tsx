import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  Ban,
  Bell,
  BellRing,
  Check,
  CheckCheck,
  Flag,
  Image as ImageIcon,
  Loader2,
  MessageSquarePlus,
  Mic,
  MoreVertical,
  Pause,
  Play,
  Search,
  Send,
  ShieldCheck,
  Trash2,
  User as UserIcon,
  Video,
  WifiOff,
  X,
} from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { Language, ReportReason } from '../types/social';
import {
  formatChatDateDivider,
  formatCount,
  formatDuration,
  formatFileSize,
  formatLastSeen,
  formatMessageTime,
  formatRelativeTime,
  getDisplayName,
} from '../utils/formatters';
import { Avatar } from './Avatar';

interface VoicePlayerProps {
  src: string;
  durationSec?: number;
  isMine: boolean;
  language: Language;
}

const VoiceMessagePlayer: React.FC<VoicePlayerProps> = ({
  src,
  durationSec,
  isMine,
  language,
}) => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(durationSec ?? 0);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onLoaded = () => {
      if (Number.isFinite(audio.duration) && audio.duration > 0) {
        setDuration(audio.duration);
      }
    };
    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };
    const onEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener('loadedmetadata', onLoaded);
    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('ended', onEnded);
    return () => {
      audio.removeEventListener('loadedmetadata', onLoaded);
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('ended', onEnded);
    };
  }, []);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => setIsPlaying(false));
    }
  };

  const totalSec = duration > 0 ? duration : durationSec ?? 0;
  const pct = totalSec > 0 ? Math.min(100, (currentTime / totalSec) * 100) : 0;

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current;
    if (!audio || !totalSec) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    audio.currentTime = ratio * totalSec;
    setCurrentTime(audio.currentTime);
  };

  return (
    <div className="flex items-center gap-2.5 min-w-[200px] sm:min-w-[230px]">
      <audio ref={audioRef} src={src} preload="metadata" />
      <button
        type="button"
        onClick={togglePlay}
        aria-label={isPlaying ? 'Pause' : 'Play'}
        className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-colors cursor-pointer ${
          isMine
            ? 'bg-white/20 hover:bg-white/30 text-white'
            : 'bg-[#0B6E4F] hover:bg-[#09583F] text-white'
        }`}
      >
        {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
      </button>

      <div className="flex-1 min-w-0 space-y-1">
        <div
          onClick={handleSeek}
          role="slider"
          aria-valuenow={Math.round(currentTime)}
          aria-valuemin={0}
          aria-valuemax={Math.round(totalSec)}
          tabIndex={0}
          className={`h-2 rounded-full cursor-pointer overflow-hidden ${
            isMine ? 'bg-white/25' : 'bg-emerald-950/15 dark:bg-emerald-200/15'
          }`}
        >
          <div
            className={`h-full transition-all ${
              isMine ? 'bg-white' : 'bg-[#0B6E4F] dark:bg-emerald-400'
            }`}
            style={{ width: `${pct}%` }}
          />
        </div>
        <div
          className={`flex items-center justify-between text-[11px] tabular-nums ${
            isMine ? 'text-emerald-50' : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <span>{formatDuration(isPlaying ? currentTime : totalSec, language)}</span>
        </div>
      </div>
    </div>
  );
};

export const MessagesView: React.FC = () => {
  const {
    t,
    language,
    currentUser,
    users,
    conversations,
    activeConversationId,
    setActiveConversationId,
    getUserById,
    sendMessage,
    sendMediaMessage,
    setTypingStatus,
    markConversationRead,
    openChatWith,
    openProfile,
    isOnlineNetwork,
    messagesLoading,
    messagingError,
    clearMessagingError,
    isPartnerTyping,
    isBlockedBetween,
    blockUser,
    unblockUser,
    reportUser,
    browserNotificationPermission,
    requestBrowserNotifications,
    showToast,
  } = useSocial();

  const [chatSearch, setChatSearch] = useState('');
  const [draft, setDraft] = useState('');
  const [newChatOpen, setNewChatOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const [pendingMedia, setPendingMedia] = useState<{
    mediaType: 'image' | 'video';
    file: File;
    previewUrl: string;
  } | null>(null);
  const [uploadPercent, setUploadPercent] = useState<number | null>(null);
  const [sending, setSending] = useState(false);

  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);

  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportReason, setReportReason] = useState<ReportReason>('harassment');
  const [reportDetails, setReportDetails] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<number | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<number | null>(null);
  const recordSecondsRef = useRef(0);
  const discardRecordingRef = useRef(false);

  const selectedConv = useMemo(() => {
    if (activeConversationId) {
      return conversations.find((c) => c.id === activeConversationId) ?? null;
    }
    return conversations[0] ?? null;
  }, [conversations, activeConversationId]);

  const activePartnerId = selectedConv?.participantIds.find((id) => id !== currentUser?.uid);
  const activePartner = activePartnerId ? getUserById(activePartnerId) : undefined;
  const partnerIsTyping =
    selectedConv && activePartner
      ? isPartnerTyping(selectedConv.id, activePartner.uid)
      : false;

  const blockState = activePartnerId
    ? isBlockedBetween(activePartnerId)
    : { blockedByMe: false, blockedByOther: false, anyBlocked: false };

  // Mark messages seen when viewing conversation
  useEffect(() => {
    if (!selectedConv || !currentUser) return;
    const hasUnreadFlag =
      selectedConv.unreadBy.includes(currentUser.uid) ||
      (selectedConv.unreadCounts?.[currentUser.uid] ?? 0) > 0;
    const hasUnseenMsgs = selectedConv.messages.some(
      (m) => m.senderId !== currentUser.uid && !m.seenBy.includes(currentUser.uid)
    );
    if (hasUnreadFlag || hasUnseenMsgs) {
      void markConversationRead(selectedConv.id);
    }
  }, [selectedConv, currentUser, markConversationRead]);

  // Smooth scroll on new messages or typing bubble
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [selectedConv?.messages.length, partnerIsTyping, selectedConv?.id]);

  // Close menus & clear pending preview when switching conversation
  useEffect(() => {
    setMenuOpen(false);
    setPendingMedia((prev) => {
      if (prev) URL.revokeObjectURL(prev.previewUrl);
      return null;
    });
  }, [selectedConv?.id]);

  // Cleanup recorder & object URLs on unmount
  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) window.clearTimeout(typingTimeoutRef.current);
      if (recordTimerRef.current) window.clearInterval(recordTimerRef.current);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        discardRecordingRef.current = true;
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  if (!currentUser) return null;

  const filteredConversations = conversations.filter((conv) => {
    const otherId = conv.participantIds.find((id) => id !== currentUser.uid);
    const other = otherId ? getUserById(otherId) : undefined;
    if (!other) return false;
    const q = chatSearch.trim().toLowerCase();
    if (!q) return true;
    return (
      other.name.toLowerCase().includes(q) ||
      other.nameBn.toLowerCase().includes(q) ||
      other.username.toLowerCase().includes(q)
    );
  });

  const handleDraftChange = (value: string) => {
    setDraft(value);
    if (!selectedConv || blockState.anyBlocked) return;

    if (value.trim().length > 0) {
      setTypingStatus(selectedConv.id, true);
      if (typingTimeoutRef.current) {
        window.clearTimeout(typingTimeoutRef.current);
      }
      typingTimeoutRef.current = window.setTimeout(() => {
        setTypingStatus(selectedConv.id, false);
      }, 2600);
    } else {
      setTypingStatus(selectedConv.id, false);
    }
  };

  const handlePickMedia = (
    e: React.ChangeEvent<HTMLInputElement>,
    mediaType: 'image' | 'video'
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (file.size > 25 * 1024 * 1024) {
      showToast(t.messagesPage.fileTooLarge);
      return;
    }
    const previewUrl = URL.createObjectURL(file);
    setPendingMedia((prev) => {
      if (prev) URL.revokeObjectURL(prev.previewUrl);
      return { mediaType, file, previewUrl };
    });
  };

  const clearPendingMedia = () => {
    setPendingMedia((prev) => {
      if (prev) URL.revokeObjectURL(prev.previewUrl);
      return null;
    });
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedConv || sending || blockState.anyBlocked) return;
    if (typingTimeoutRef.current) {
      window.clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = null;
    }
    setTypingStatus(selectedConv.id, false);

    if (pendingMedia) {
      setSending(true);
      setUploadPercent(0);
      const caption = draft;
      const targetMedia = pendingMedia;
      const ok = await sendMediaMessage(selectedConv.id, {
        mediaType: targetMedia.mediaType,
        file: targetMedia.file,
        fileName: targetMedia.file.name,
        caption,
        onProgress: setUploadPercent,
      });
      setSending(false);
      setUploadPercent(null);
      if (ok) {
        setDraft('');
        clearPendingMedia();
      }
      return;
    }

    if (!draft.trim()) return;
    const textToSend = draft;
    setDraft('');
    setSending(true);
    const ok = await sendMessage(selectedConv.id, textToSend);
    setSending(false);
    if (!ok) {
      setDraft(textToSend);
    }
  };

  const startVoiceRecording = async () => {
    if (!selectedConv || isRecording || sending || blockState.anyBlocked) return;
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      showToast(t.messagesPage.micDenied);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : MediaRecorder.isTypeSupported('audio/mp4')
        ? 'audio/mp4'
        : '';
      const recorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);

      audioChunksRef.current = [];
      discardRecordingRef.current = false;
      recordSecondsRef.current = 0;
      setRecordSeconds(0);
      setIsRecording(true);

      const convId = selectedConv.id;

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) {
          audioChunksRef.current.push(ev.data);
        }
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((tr) => tr.stop());
        if (recordTimerRef.current) {
          window.clearInterval(recordTimerRef.current);
          recordTimerRef.current = null;
        }
        setIsRecording(false);
        const duration = Math.max(1, recordSecondsRef.current);

        if (discardRecordingRef.current || audioChunksRef.current.length === 0) {
          return;
        }

        const blobType = recorder.mimeType || 'audio/webm';
        const ext = blobType.includes('mp4') ? 'm4a' : 'webm';
        const audioBlob = new Blob(audioChunksRef.current, { type: blobType });

        setSending(true);
        setUploadPercent(0);
        await sendMediaMessage(convId, {
          mediaType: 'voice',
          file: audioBlob,
          fileName: `voice_${Date.now()}.${ext}`,
          durationSec: duration,
          onProgress: setUploadPercent,
        });
        setSending(false);
        setUploadPercent(null);
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      recordTimerRef.current = window.setInterval(() => {
        recordSecondsRef.current += 1;
        setRecordSeconds(recordSecondsRef.current);
        if (recordSecondsRef.current >= 120) {
          recorder.stop();
        }
      }, 1000);
    } catch {
      showToast(t.messagesPage.micDenied);
      setIsRecording(false);
    }
  };

  const stopAndSendVoice = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      discardRecordingRef.current = false;
      mediaRecorderRef.current.stop();
    }
  };

  const cancelVoiceRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      discardRecordingRef.current = true;
      mediaRecorderRef.current.stop();
    } else {
      setIsRecording(false);
    }
  };

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePartner) return;
    await reportUser(activePartner.uid, reportReason, reportDetails);
    setReportDetails('');
    setReportModalOpen(false);
  };

  const mobileShowingThread = Boolean(activeConversationId && selectedConv);

  return (
    <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[560px] h-[calc(100vh-155px)] max-h-[760px]">
      {/* Conversations List Pane */}
      <aside
        className={`md:col-span-5 lg:col-span-4 border-r border-emerald-950/10 dark:border-emerald-200/10 flex flex-col min-h-0 ${
          mobileShowingThread ? 'hidden md:flex' : 'flex'
        }`}
      >
        <div className="p-3.5 sm:p-4 border-b border-emerald-950/10 dark:border-emerald-200/10 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h1 className="font-display text-lg font-bold text-slate-900 dark:text-white truncate">
              {t.messagesPage.title}
            </h1>
            <div className="flex items-center gap-1.5 shrink-0">
              {browserNotificationPermission !== 'unsupported' && (
                <button
                  type="button"
                  onClick={() => void requestBrowserNotifications()}
                  title={
                    browserNotificationPermission === 'granted'
                      ? t.messagesPage.browserAlertsEnabled
                      : t.messagesPage.enableBrowserAlerts
                  }
                  aria-label={
                    browserNotificationPermission === 'granted'
                      ? t.messagesPage.browserAlertsEnabled
                      : t.messagesPage.enableBrowserAlerts
                  }
                  className={`min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
                    browserNotificationPermission === 'granted'
                      ? 'bg-emerald-50 dark:bg-emerald-950/60 text-[#0B6E4F] dark:text-emerald-300'
                      : 'bg-[#F4F6F4] dark:bg-[#0D1512] text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white'
                  }`}
                >
                  {browserNotificationPermission === 'granted' ? (
                    <BellRing className="w-4 h-4" />
                  ) : (
                    <Bell className="w-4 h-4" />
                  )}
                </button>
              )}
              <button
                type="button"
                onClick={() => setNewChatOpen((prev) => !prev)}
                aria-label={t.messagesPage.newChat}
                title={t.messagesPage.newChat}
                className="min-w-[40px] min-h-[40px] rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-[#0B6E4F] dark:text-emerald-300 flex items-center justify-center hover:bg-emerald-100 dark:hover:bg-emerald-950 cursor-pointer"
              >
                <MessageSquarePlus className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={chatSearch}
              onChange={(e) => setChatSearch(e.target.value)}
              placeholder={t.messagesPage.searchChats}
              className="w-full min-h-[40px] pl-9 pr-3 py-1.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700"
            />
          </div>

          {newChatOpen && (
            <div className="p-2.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 space-y-1.5 max-h-48 overflow-y-auto">
              <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 px-1.5">
                {t.messagesPage.startChat}
              </p>
              {users
                .filter(
                  (u) =>
                    u.uid !== currentUser.uid &&
                    u.status === 'active' &&
                    !isBlockedBetween(u.uid).anyBlocked
                )
                .map((u) => (
                  <button
                    key={u.uid}
                    type="button"
                    onClick={() => {
                      void openChatWith(u.uid);
                      setNewChatOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 p-1.5 rounded-lg hover:bg-white dark:hover:bg-white/5 text-left cursor-pointer"
                  >
                    <Avatar
                      src={u.avatarUrl}
                      name={getDisplayName(u, language)}
                      size="xs"
                      showOnline
                      isOnline={u.isOnline}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate">
                        {getDisplayName(u, language)}
                      </p>
                      <p className="text-[11px] text-slate-400 truncate">
                        {u.isOnline
                          ? t.messagesPage.activeNow
                          : formatLastSeen(u.lastSeenAt, language)}
                      </p>
                    </div>
                  </button>
                ))}
            </div>
          )}
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-emerald-950/10 dark:divide-emerald-200/10">
          {messagesLoading && filteredConversations.length === 0 ? (
            <div className="p-6 flex items-center justify-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <Loader2 className="w-4 h-4 animate-spin text-[#0B6E4F]" />
              <span>{t.messagesPage.loadingMessages}</span>
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500 dark:text-slate-400">
              {t.messagesPage.selectConversation}
            </div>
          ) : (
            filteredConversations.map((conv) => {
              const partnerId = conv.participantIds.find((id) => id !== currentUser.uid);
              const partner = partnerId ? getUserById(partnerId) : undefined;
              if (!partner) return null;

              const lastMsg = conv.messages[conv.messages.length - 1];
              const unreadCount =
                conv.unreadCounts?.[currentUser.uid] ??
                (conv.unreadBy.includes(currentUser.uid) ? 1 : 0);
              const isUnread = unreadCount > 0;
              const isSelected = selectedConv?.id === conv.id;
              const partnerName = getDisplayName(partner, language);
              const typingNow = isPartnerTyping(conv.id, partner.uid);

              const lastMediaType = lastMsg?.messageType || conv.lastMessageType || 'text';
              const lastText = lastMsg?.text || conv.lastMessageText || '';
              const sentByMe =
                (lastMsg?.senderId || conv.lastMessageSenderId) === currentUser.uid;
              const mediaLabel =
                lastMediaType === 'image'
                  ? t.messagesPage.photoLabel
                  : lastMediaType === 'video'
                  ? t.messagesPage.videoLabel
                  : lastMediaType === 'voice'
                  ? t.messagesPage.voiceMessage
                  : '';

              const previewLine = typingNow
                ? t.messagesPage.typing
                : lastText || mediaLabel
                ? `${sentByMe ? `${t.messagesPage.youPrefix} ` : ''}${lastText || mediaLabel}`
                : t.messagesPage.startChat;

              const lastTimeIso = lastMsg?.createdAt || conv.lastMessageAt;

              return (
                <button
                  key={conv.id}
                  type="button"
                  onClick={() => {
                    setActiveConversationId(conv.id);
                    void markConversationRead(conv.id);
                  }}
                  className={`w-full p-3.5 flex items-center gap-3 text-left transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-50/75 dark:bg-emerald-950/40'
                      : 'hover:bg-slate-50 dark:hover:bg-white/5'
                  }`}
                >
                  <Avatar
                    src={partner.avatarUrl}
                    name={partnerName}
                    size="md"
                    showOnline
                    isOnline={partner.isOnline}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className={`text-sm truncate ${
                          isUnread
                            ? 'font-bold text-slate-900 dark:text-white'
                            : 'font-semibold text-slate-800 dark:text-slate-200'
                        }`}
                      >
                        {partnerName}
                      </span>
                      {lastTimeIso && (
                        <span className="text-[11px] text-slate-400 shrink-0 tabular-nums">
                          {formatRelativeTime(lastTimeIso, language)}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center justify-between gap-2 mt-0.5">
                      <p
                        className={`text-xs truncate ${
                          typingNow
                            ? 'font-medium text-[#0B6E4F] dark:text-emerald-400'
                            : isUnread
                            ? 'font-semibold text-slate-900 dark:text-slate-100'
                            : 'text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {previewLine}
                      </p>
                      {unreadCount > 0 && (
                        <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-[#0B6E4F] text-white text-[11px] font-bold flex items-center justify-center shrink-0 tabular-nums">
                          {formatCount(unreadCount, language)}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </aside>

      {/* Active Chat Thread */}
      <section
        className={`md:col-span-7 lg:col-span-8 flex flex-col min-h-0 ${
          mobileShowingThread ? 'flex' : 'hidden md:flex'
        }`}
      >
        {!isOnlineNetwork && (
          <div className="px-4 py-2 bg-amber-50 dark:bg-amber-950/50 border-b border-amber-200 dark:border-amber-800/50 flex items-center gap-2 text-xs font-medium text-amber-800 dark:text-amber-200">
            <WifiOff className="w-4 h-4 shrink-0" />
            <span>{t.messagesPage.offlineBanner}</span>
          </div>
        )}

        {messagingError && (
          <div className="px-4 py-2 bg-rose-50 dark:bg-rose-950/40 border-b border-rose-200 dark:border-rose-800/50 flex items-center justify-between gap-2 text-xs font-medium text-rose-800 dark:text-rose-200">
            <div className="flex items-center gap-2 min-w-0">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span className="truncate">{messagingError}</span>
            </div>
            <button
              type="button"
              onClick={clearMessagingError}
              aria-label={t.actions.cancel}
              className="p-1 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-900/40 shrink-0 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {selectedConv && activePartner ? (
          <>
            {/* Thread Header */}
            <div className="p-3 sm:px-5 border-b border-emerald-950/10 dark:border-emerald-200/10 flex items-center justify-between gap-3 relative">
              <div className="flex items-center gap-2.5 min-w-0">
                <button
                  type="button"
                  onClick={() => setActiveConversationId(null)}
                  aria-label={t.actions.back}
                  className="md:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={() => openProfile(activePartner.uid)}
                  className="flex items-center gap-3 min-w-0 text-left cursor-pointer"
                >
                  <Avatar
                    src={activePartner.avatarUrl}
                    name={getDisplayName(activePartner, language)}
                    size="sm"
                    showOnline
                    isOnline={activePartner.isOnline}
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                      {getDisplayName(activePartner, language)}
                    </p>
                    <p
                      className={`text-xs truncate ${
                        partnerIsTyping || activePartner.isOnline
                          ? 'text-[#0B6E4F] dark:text-emerald-400 font-medium'
                          : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {partnerIsTyping
                        ? t.messagesPage.typing
                        : activePartner.isOnline
                        ? t.messagesPage.activeNow
                        : formatLastSeen(activePartner.lastSeenAt, language)}
                    </p>
                  </div>
                </button>
              </div>

              {/* Conversation Actions Menu (Profile / Block / Report) */}
              <div className="relative shrink-0">
                <button
                  type="button"
                  onClick={() => setMenuOpen((prev) => !prev)}
                  aria-label="Conversation options"
                  className="min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
                >
                  <MoreVertical className="w-5 h-5" />
                </button>

                {menuOpen && (
                  <div className="absolute right-0 mt-1.5 w-52 bg-white dark:bg-[#192822] border border-emerald-950/15 dark:border-emerald-200/15 rounded-xl shadow-lg py-1.5 z-30">
                    <button
                      type="button"
                      onClick={() => {
                        setMenuOpen(false);
                        openProfile(activePartner.uid);
                      }}
                      className="w-full min-h-[40px] px-3.5 py-2 text-left text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-2.5 cursor-pointer"
                    >
                      <UserIcon className="w-4 h-4 text-slate-400" />
                      <span>{t.actions.viewProfile}</span>
                    </button>

                    {blockState.blockedByMe ? (
                      <button
                        type="button"
                        onClick={() => {
                          setMenuOpen(false);
                          void unblockUser(activePartner.uid);
                        }}
                        className="w-full min-h-[40px] px-3.5 py-2 text-left text-xs sm:text-sm font-medium text-[#0B6E4F] dark:text-emerald-400 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-2.5 cursor-pointer"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        <span>{t.messagesPage.unblockUser}</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setMenuOpen(false);
                          void blockUser(activePartner.uid);
                        }}
                        className="w-full min-h-[40px] px-3.5 py-2 text-left text-xs sm:text-sm font-medium text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-2.5 cursor-pointer"
                      >
                        <Ban className="w-4 h-4" />
                        <span>{t.messagesPage.blockUser}</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        setMenuOpen(false);
                        setReportModalOpen(true);
                      }}
                      className="w-full min-h-[40px] px-3.5 py-2 text-left text-xs sm:text-sm font-medium text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/30 flex items-center gap-2.5 cursor-pointer"
                    >
                      <Flag className="w-4 h-4" />
                      <span>{t.messagesPage.reportUser}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Messages Scroll Area */}
            <div className="flex-1 overflow-y-auto p-3.5 sm:p-5 space-y-2.5 bg-[#F8FAF8] dark:bg-[#0D1512]">
              {messagesLoading && selectedConv.messages.length === 0 ? (
                <div className="h-full flex items-center justify-center gap-2 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                  <Loader2 className="w-4 h-4 animate-spin text-[#0B6E4F]" />
                  <span>{t.messagesPage.loadingMessages}</span>
                </div>
              ) : selectedConv.messages.length === 0 ? (
                <div className="h-full flex items-center justify-center text-center p-6">
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                    {t.messagesPage.startChat} — {getDisplayName(activePartner, language)}
                  </p>
                </div>
              ) : (
                selectedConv.messages.map((msg, idx) => {
                  const isMine = msg.senderId === currentUser.uid;
                  const prevMsg = idx > 0 ? selectedConv.messages[idx - 1] : null;
                  const showDateDivider =
                    !prevMsg ||
                    new Date(prevMsg.createdAt).toDateString() !==
                      new Date(msg.createdAt).toDateString();

                  const isSeen = msg.seenBy.includes(activePartner.uid);
                  const isDelivered = isSeen || msg.deliveredTo.includes(activePartner.uid);
                  const receiptLabel = isSeen
                    ? t.messagesPage.seen
                    : isDelivered
                    ? t.messagesPage.delivered
                    : t.messagesPage.sent;

                  return (
                    <React.Fragment key={msg.id}>
                      {showDateDivider && (
                        <div className="flex items-center justify-center my-2">
                          <span className="px-3 py-1 rounded-full bg-white/90 dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 text-[11px] font-medium text-slate-500 dark:text-slate-400 tabular-nums">
                            {formatChatDateDivider(msg.createdAt, language)}
                          </span>
                        </div>
                      )}

                      <div
                        className={`flex flex-col ${isMine ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-[84%] sm:max-w-[74%] rounded-2xl overflow-hidden text-sm leading-relaxed ${
                            isMine
                              ? 'bg-[#0B6E4F] text-white rounded-br-sm'
                              : 'bg-white dark:bg-[#14201B] text-slate-800 dark:text-slate-100 border border-emerald-950/10 dark:border-emerald-200/10 rounded-bl-sm'
                          }`}
                        >
                          {msg.messageType === 'image' && msg.mediaUrl && (
                            <button
                              type="button"
                              onClick={() => setLightboxUrl(msg.mediaUrl || null)}
                              aria-label={t.messagesPage.viewFullImage}
                              className="block w-full text-left cursor-pointer"
                            >
                              <img
                                src={msg.mediaUrl}
                                alt={msg.mediaName || t.messagesPage.photoLabel}
                                className="max-h-72 w-full object-cover"
                              />
                            </button>
                          )}

                          {msg.messageType === 'video' && msg.mediaUrl && (
                            <video
                              src={msg.mediaUrl}
                              controls
                              playsInline
                              preload="metadata"
                              className="max-h-72 w-full bg-black"
                            />
                          )}

                          {msg.messageType === 'voice' && msg.mediaUrl && (
                            <div className="px-3.5 py-2.5">
                              <VoiceMessagePlayer
                                src={msg.mediaUrl}
                                durationSec={msg.mediaDurationSec}
                                isMine={isMine}
                                language={language}
                              />
                            </div>
                          )}

                          {msg.text && (
                            <p className="px-3.5 py-2 whitespace-pre-wrap break-words">
                              {msg.text}
                            </p>
                          )}
                        </div>

                        <div className="flex items-center gap-1 mt-1 px-1 text-[11px] text-slate-400 tabular-nums">
                          <span>{formatMessageTime(msg.createdAt, language)}</span>
                          {isMine && (
                            <span
                              title={receiptLabel}
                              aria-label={receiptLabel}
                              className="inline-flex items-center"
                            >
                              {isSeen ? (
                                <CheckCheck className="w-3.5 h-3.5 text-[#0B6E4F] dark:text-emerald-400" />
                              ) : isDelivered ? (
                                <CheckCheck className="w-3.5 h-3.5 text-slate-400" />
                              ) : (
                                <Check className="w-3.5 h-3.5 text-slate-400" />
                              )}
                            </span>
                          )}
                        </div>
                      </div>
                    </React.Fragment>
                  );
                })
              )}

              {partnerIsTyping && (
                <div className="flex items-start">
                  <div className="px-3.5 py-2.5 rounded-2xl rounded-bl-sm bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#0B6E4F] dark:bg-emerald-400 animate-bounce" />
                    <span
                      className="w-1.5 h-1.5 rounded-full bg-[#0B6E4F] dark:bg-emerald-400 animate-bounce"
                      style={{ animationDelay: '150ms' }}
                    />
                    <span
                      className="w-1.5 h-1.5 rounded-full bg-[#0B6E4F] dark:bg-emerald-400 animate-bounce"
                      style={{ animationDelay: '300ms' }}
                    />
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Staged Media Preview & Upload Progress */}
            {pendingMedia && (
              <div className="px-3.5 py-2.5 border-t border-emerald-950/10 dark:border-emerald-200/10 bg-[#F4F6F4] dark:bg-[#0D1512] flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {pendingMedia.mediaType === 'image' ? (
                    <img
                      src={pendingMedia.previewUrl}
                      alt={pendingMedia.file.name}
                      className="w-12 h-12 rounded-xl object-cover border border-emerald-950/10 shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-emerald-950 text-white flex items-center justify-center shrink-0">
                      <Video className="w-5 h-5" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                      {pendingMedia.file.name}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                      {uploadPercent !== null
                        ? `${t.messagesPage.uploadingMedia} ${formatCount(uploadPercent, language)}%`
                        : formatFileSize(pendingMedia.file.size, language)}
                    </p>
                  </div>
                </div>
                {!sending && (
                  <button
                    type="button"
                    onClick={clearPendingMedia}
                    aria-label={t.actions.removeMedia}
                    className="min-w-[36px] min-h-[36px] rounded-xl text-slate-500 hover:bg-white dark:hover:bg-white/5 flex items-center justify-center cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            )}

            {uploadPercent !== null && !pendingMedia && (
              <div className="px-4 py-1.5 bg-emerald-50 dark:bg-emerald-950/40 text-xs font-medium text-[#0B6E4F] dark:text-emerald-300 flex items-center gap-2 tabular-nums">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>
                  {t.messagesPage.uploadingMedia} {formatCount(uploadPercent, language)}%
                </span>
              </div>
            )}

            {/* Blocked / Suspended / Active Composer Footer */}
            {blockState.anyBlocked ? (
              <div className="p-3.5 sm:px-5 border-t border-emerald-950/10 dark:border-emerald-200/10 bg-[#F4F6F4] dark:bg-[#0D1512] flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
                <p className="text-slate-600 dark:text-slate-300 font-medium">
                  {blockState.blockedByMe
                    ? t.messagesPage.blockedByYouBanner
                    : t.messagesPage.blockedByOtherBanner}
                </p>
                {blockState.blockedByMe && (
                  <button
                    type="button"
                    onClick={() => void unblockUser(activePartner.uid)}
                    className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white font-semibold whitespace-nowrap self-start sm:self-auto cursor-pointer"
                  >
                    {t.messagesPage.unblockUser}
                  </button>
                )}
              </div>
            ) : currentUser.status === 'suspended' ? (
              <div className="p-3.5 border-t border-emerald-950/10 dark:border-emerald-200/10 bg-rose-50 dark:bg-rose-950/30 text-xs font-medium text-rose-800 dark:text-rose-200">
                {t.feed.suspendedNotice}
              </div>
            ) : isRecording ? (
              <div className="p-3 sm:p-3.5 border-t border-emerald-950/10 dark:border-emerald-200/10 bg-emerald-50/70 dark:bg-emerald-950/40 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 text-xs sm:text-sm font-semibold text-rose-700 dark:text-rose-300 tabular-nums">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-pulse" />
                  <span>{t.messagesPage.recording}</span>
                  <span>{formatDuration(recordSeconds, language)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={cancelVoiceRecording}
                    className="min-h-[42px] px-3 rounded-xl border border-rose-200 dark:border-rose-800/50 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>{t.messagesPage.cancelVoice}</span>
                  </button>
                  <button
                    type="button"
                    onClick={stopAndSendVoice}
                    className="min-h-[42px] px-4 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>{t.messagesPage.stopVoice}</span>
                  </button>
                </div>
              </div>
            ) : (
              <form
                onSubmit={(e) => void handleSend(e)}
                className="p-2.5 sm:p-3.5 border-t border-emerald-950/10 dark:border-emerald-200/10 flex items-center gap-1.5 sm:gap-2 bg-white dark:bg-[#14201B]"
              >
                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => handlePickMedia(e, 'image')}
                  className="hidden"
                />
                <input
                  ref={videoInputRef}
                  type="file"
                  accept="video/*"
                  onChange={(e) => handlePickMedia(e, 'video')}
                  className="hidden"
                />

                <button
                  type="button"
                  disabled={sending}
                  onClick={() => imageInputRef.current?.click()}
                  aria-label={t.messagesPage.sendImage}
                  title={t.messagesPage.sendImage}
                  className="min-w-[44px] min-h-[44px] rounded-xl text-slate-600 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-white/5 hover:text-[#0B6E4F] dark:hover:text-emerald-400 flex items-center justify-center shrink-0 cursor-pointer"
                >
                  <ImageIcon className="w-5 h-5" />
                </button>

                <button
                  type="button"
                  disabled={sending}
                  onClick={() => videoInputRef.current?.click()}
                  aria-label={t.messagesPage.sendVideo}
                  title={t.messagesPage.sendVideo}
                  className="min-w-[44px] min-h-[44px] rounded-xl text-slate-600 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-white/5 hover:text-[#0B6E4F] dark:hover:text-emerald-400 flex items-center justify-center shrink-0 cursor-pointer"
                >
                  <Video className="w-5 h-5" />
                </button>

                <button
                  type="button"
                  disabled={sending}
                  onClick={() => void startVoiceRecording()}
                  aria-label={t.messagesPage.recordVoice}
                  title={t.messagesPage.recordVoice}
                  className="min-w-[44px] min-h-[44px] rounded-xl text-slate-600 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-white/5 hover:text-[#0B6E4F] dark:hover:text-emerald-400 flex items-center justify-center shrink-0 cursor-pointer"
                >
                  <Mic className="w-5 h-5" />
                </button>

                <input
                  type="text"
                  value={draft}
                  onChange={(e) => handleDraftChange(e.target.value)}
                  onBlur={() => selectedConv && setTypingStatus(selectedConv.id, false)}
                  placeholder={t.messagesPage.typeMessage}
                  className="flex-1 min-w-0 min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700"
                />

                <button
                  type="submit"
                  disabled={sending || (!draft.trim() && !pendingMedia)}
                  aria-label={t.actions.send}
                  className="min-w-[44px] min-h-[44px] px-3.5 sm:px-4 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] disabled:opacity-40 text-white flex items-center justify-center gap-1.5 text-sm font-semibold transition-colors shrink-0 cursor-pointer"
                >
                  {sending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  <span className="hidden sm:inline">{t.actions.send}</span>
                </button>
              </form>
            )}
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center p-8 text-center text-sm text-slate-500 dark:text-slate-400">
            {t.messagesPage.selectConversation}
          </div>
        )}
      </section>

      {/* Fullscreen Image Lightbox */}
      {lightboxUrl && (
        <div
          onClick={() => setLightboxUrl(null)}
          className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4"
        >
          <button
            type="button"
            onClick={() => setLightboxUrl(null)}
            aria-label={t.actions.cancel}
            className="absolute top-4 right-4 min-w-[44px] min-h-[44px] rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          <img
            src={lightboxUrl}
            alt="Attachment preview"
            onClick={(e) => e.stopPropagation()}
            className="max-w-full max-h-[88vh] rounded-2xl object-contain"
          />
        </div>
      )}

      {/* Report User Modal */}
      {reportModalOpen && activePartner && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full sm:max-w-md bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                {t.messagesPage.reportUser}
              </h2>
              <button
                type="button"
                onClick={() => setReportModalOpen(false)}
                aria-label={t.actions.cancel}
                className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={(e) => void handleReportSubmit(e)} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                  {t.reportModal.reasonLabel}
                </label>
                <select
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value as ReportReason)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700"
                >
                  <option value="harassment">{t.reportModal.reasons.harassment}</option>
                  <option value="spam">{t.reportModal.reasons.spam}</option>
                  <option value="inappropriate">{t.reportModal.reasons.inappropriate}</option>
                  <option value="misinformation">{t.reportModal.reasons.misinformation}</option>
                  <option value="other">{t.reportModal.reasons.other}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                  {t.reportModal.detailsLabel}
                </label>
                <textarea
                  rows={3}
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder={t.reportModal.detailsPlaceholder}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setReportModalOpen(false)}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  {t.actions.cancel}
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold cursor-pointer"
                >
                  {t.actions.submitReport}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
