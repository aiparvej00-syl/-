import React, { useEffect, useRef, useState } from 'react';
import { Image as ImageIcon, MapPin, Palette, Video, X } from 'lucide-react';
import { ASSET_IMAGES } from '../data/seedData';
import { useSocial } from '../context/SocialContext';
import { PostMediaType } from '../types/social';
import { getDisplayName } from '../utils/formatters';
import { compressImageToDataUrl, fileToBoundedDataUrl } from '../utils/media';
import { Avatar } from './Avatar';
import { HierarchicalLocationSelect } from './HierarchicalLocationSelect';

const GALLERY_PRESETS = [
  { labelEn: 'Malnicherra Tea Garden', url: ASSET_IMAGES.teaGardenCover },
  { labelEn: 'Ratargul Forest', url: ASSET_IMAGES.ratargul },
  { labelEn: 'Madhabkunda Waterfall', url: ASSET_IMAGES.madhabkunda },
  { labelEn: 'Lawachara Rainforest', url: ASSET_IMAGES.lawachara },
];

const TEXT_CARD_THEMES: {
  id: 'none' | 'emerald' | 'surma' | 'tea';
  labelEn: string;
  swatchClass: string;
  cardClass: string;
}[] = [
  {
    id: 'none',
    labelEn: 'Plain',
    swatchClass: 'bg-slate-200 dark:bg-slate-700',
    cardClass: '',
  },
  {
    id: 'emerald',
    labelEn: 'Sylhet Emerald',
    swatchClass: 'bg-[#0B6E4F]',
    cardClass: 'bg-gradient-to-br from-[#0B6E4F] to-[#064E3B] text-white',
  },
  {
    id: 'surma',
    labelEn: 'Surma Dusk',
    swatchClass: 'bg-slate-800',
    cardClass: 'bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-800 text-white',
  },
  {
    id: 'tea',
    labelEn: 'Sunset Gold',
    swatchClass: 'bg-amber-700',
    cardClass: 'bg-gradient-to-br from-amber-700 to-amber-900 text-white',
  },
];

export const PostComposer: React.FC = () => {
  const {
    currentUser,
    isAdmin,
    appSettings,
    t,
    language,
    createPost,
    composerLocationPrefill,
    prefillComposerWithLocation,
    setAuthModalOpen,
    showToast,
  } = useSocial();

  const [text, setText] = useState('');
  const [mediaType, setMediaType] = useState<PostMediaType>('text');
  const [photoUrl, setPhotoUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [videoThumbnailUrl, setVideoThumbnailUrl] = useState('');
  const [textCardTheme, setTextCardTheme] = useState<'none' | 'emerald' | 'surma' | 'tea'>('none');
  const [selectedLoc, setSelectedLoc] = useState<{ en: string; bn: string } | null>(null);
  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const [showPresetTray, setShowPresetTray] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (composerLocationPrefill) {
      setSelectedLoc(composerLocationPrefill);
      setShowLocationPicker(true);
      prefillComposerWithLocation(null);
    }
  }, [composerLocationPrefill, prefillComposerWithLocation]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageToDataUrl(file, 1080, 0.78);
      if (compressed.length > 580000) {
        showToast(
          language === 'bn'
            ? 'ছবিটি অনেক বড়, অনুগ্রহ করে ছোট ছবি বেছে নিন।'
            : 'Image is too large for storage. Please choose a smaller photo.'
        );
        return;
      }
      setMediaType('photo');
      setPhotoUrl(compressed);
      setVideoUrl('');
      setVideoThumbnailUrl('');
      setTextCardTheme('none');
      setShowPresetTray(false);
    } catch {
      showToast(language === 'bn' ? 'ছবি পড়া যায়নি' : 'Could not load image file');
    }
  };

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const result = await fileToBoundedDataUrl(file, 450000);
    if (!result.ok || !result.dataUrl) {
      showToast(
        language === 'bn'
          ? 'ছোট ভিডিও (৪৫০ কেবি পর্যন্ত) আপলোড করুন অথবা সিলেট রিল বেছে নিন।'
          : 'Please upload a short clip under 450KB or select a Sylhet Reel preset.'
      );
      return;
    }
    setMediaType('video');
    setVideoUrl(result.dataUrl);
    setVideoThumbnailUrl('');
    setPhotoUrl('');
    setTextCardTheme('none');
    setShowPresetTray(false);
  };

  const handleClearMedia = () => {
    setMediaType('text');
    setPhotoUrl('');
    setVideoUrl('');
    setVideoThumbnailUrl('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    const hasContent = Boolean(text.trim() || photoUrl || videoUrl || videoThumbnailUrl);
    if (!hasContent || submitting) return;

    setSubmitting(true);
    try {
      await createPost({
        mediaType,
        text,
        photoUrl: mediaType === 'photo' ? photoUrl : undefined,
        videoUrl: mediaType === 'video' ? videoUrl : undefined,
        videoThumbnailUrl: mediaType === 'video' ? videoThumbnailUrl : undefined,
        videoDuration: mediaType === 'video' ? '0:20' : undefined,
        textCardTheme: mediaType === 'text' ? textCardTheme : 'none',
        location: selectedLoc?.en,
        locationBn: selectedLoc?.bn,
      });

      setText('');
      handleClearMedia();
      setTextCardTheme('none');
      setSelectedLoc(null);
      setShowLocationPicker(false);
      setShowPresetTray(false);
    } finally {
      setSubmitting(false);
    }
  };

  const isDisabledByMaintenance = appSettings.maintenanceMode && !isAdmin;
  const isSuspended = currentUser?.status === 'suspended';
  const activeThemeObj = TEXT_CARD_THEMES.find((item) => item.id === textCardTheme);
  const canSubmit =
    !submitting &&
    !isDisabledByMaintenance &&
    !isSuspended &&
    Boolean(text.trim() || photoUrl || videoUrl || videoThumbnailUrl);

  return (
    <section
      aria-label={t.actions.createPost}
      className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5"
    >
      {isSuspended && (
        <p className="mb-3 text-xs text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 px-3 py-2 rounded-xl">
          {t.feed.suspendedNotice}
        </p>
      )}
      {isDisabledByMaintenance && (
        <p className="mb-3 text-xs text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 px-3 py-2 rounded-xl">
          {t.feed.maintenanceNotice}
        </p>
      )}

      <form onSubmit={(e) => void handleSubmit(e)} className="space-y-3.5">
        <div className="flex items-start gap-3">
          <Avatar
            src={currentUser?.avatarUrl}
            name={currentUser ? getDisplayName(currentUser, language) : 'Sylhet Social'}
            size="md"
          />
          <div className="flex-1 min-w-0">
            {mediaType === 'text' && textCardTheme !== 'none' && activeThemeObj ? (
              <div className={`${activeThemeObj.cardClass} rounded-2xl p-5 min-h-[140px] flex items-center justify-center`}>
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  rows={3}
                  disabled={isDisabledByMaintenance || isSuspended}
                  placeholder={t.feed.whatsOnMind}
                  className="w-full bg-transparent text-center text-lg sm:text-xl font-semibold placeholder:text-white/70 focus:outline-none resize-none"
                />
              </div>
            ) : (
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                rows={2}
                disabled={isDisabledByMaintenance || isSuspended}
                placeholder={t.feed.whatsOnMind}
                className="w-full min-h-[52px] px-3.5 py-2.5 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm sm:text-base text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-700 resize-none"
              />
            )}
          </div>
        </div>

        {mediaType === 'photo' && photoUrl && (
          <div className="relative rounded-xl overflow-hidden border border-emerald-950/10 dark:border-emerald-200/10 bg-slate-100 dark:bg-black/30">
            <img
              src={photoUrl}
              alt="Post upload preview"
              referrerPolicy="no-referrer"
              className="w-full max-h-72 object-cover"
            />
            <button
              type="button"
              onClick={handleClearMedia}
              aria-label={t.actions.removeMedia}
              className="absolute top-2.5 right-2.5 min-w-[36px] min-h-[36px] rounded-full bg-black/65 text-white flex items-center justify-center hover:bg-black/80"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {mediaType === 'video' && (videoUrl || videoThumbnailUrl) && (
          <div className="relative rounded-xl overflow-hidden border border-emerald-950/10 dark:border-emerald-200/10 bg-black">
            {videoUrl ? (
              <video src={videoUrl} controls className="w-full max-h-72 object-contain" />
            ) : (
              <div className="relative aspect-video">
                <img
                  src={videoThumbnailUrl}
                  alt="Video reel preview"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/35 flex items-center justify-center text-white text-xs font-semibold">
                  Sylhet Video Reel Ready
                </div>
              </div>
            )}
            <button
              type="button"
              onClick={handleClearMedia}
              aria-label={t.actions.removeMedia}
              className="absolute top-2.5 right-2.5 min-w-[36px] min-h-[36px] rounded-full bg-black/65 text-white flex items-center justify-center hover:bg-black/80"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {showPresetTray && (
          <div className="p-3 rounded-xl bg-[#F6F8F6] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 space-y-2.5">
            <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
              <span className="font-medium">
                {language === 'bn'
                  ? 'ডিভাইস থেকে আপলোড অথবা সিলেটের ছবি বাছাই করুন'
                  : 'Upload from device or choose a Sylhet scene'}
              </span>
              <button
                type="button"
                onClick={() => photoInputRef.current?.click()}
                className="text-emerald-700 dark:text-emerald-400 font-semibold hover:underline cursor-pointer"
              >
                {t.actions.uploadPhoto}
              </button>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {GALLERY_PRESETS.map((preset) => (
                <button
                  key={preset.url}
                  type="button"
                  onClick={() => {
                    setMediaType('photo');
                    setPhotoUrl(preset.url);
                    setVideoUrl('');
                    setTextCardTheme('none');
                    setShowPresetTray(false);
                  }}
                  className="rounded-lg overflow-hidden aspect-[4/3] border border-emerald-950/10 hover:ring-2 hover:ring-emerald-700 transition-all cursor-pointer"
                >
                  <img
                    src={preset.url}
                    alt={preset.labelEn}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>
        )}

        {showLocationPicker && (
          <HierarchicalLocationSelect
            valueEn={selectedLoc?.en}
            valueBn={selectedLoc?.bn}
            includeAttractionShortcut
            compact
            onChange={(loc) => setSelectedLoc(loc)}
          />
        )}

        {mediaType === 'text' && (
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <Palette className="w-3.5 h-3.5 shrink-0" />
            <span>{t.feed.textCard}:</span>
            <div className="flex items-center gap-1.5">
              {TEXT_CARD_THEMES.map((themeItem) => (
                <button
                  key={themeItem.id}
                  type="button"
                  onClick={() => setTextCardTheme(themeItem.id)}
                  aria-label={themeItem.labelEn}
                  className={`w-6 h-6 rounded-full ${themeItem.swatchClass} transition-transform cursor-pointer ${
                    textCardTheme === themeItem.id
                      ? 'ring-2 ring-offset-2 ring-emerald-700 dark:ring-offset-[#14201B] scale-110'
                      : 'opacity-75 hover:opacity-100'
                  }`}
                />
              ))}
            </div>
          </div>
        )}

        <div className="pt-2.5 border-t border-emerald-950/10 dark:border-emerald-200/10 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1 sm:gap-1.5">
            <button
              type="button"
              onClick={() => setShowPresetTray((prev) => !prev)}
              className="min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-white/5 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <ImageIcon className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
              <span>{t.feed.addPhoto}</span>
            </button>

            <button
              type="button"
              onClick={() => videoInputRef.current?.click()}
              className="min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-white/5 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Video className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>{t.feed.addVideo}</span>
            </button>

            <button
              type="button"
              onClick={() => setShowLocationPicker((prev) => !prev)}
              className={`min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                selectedLoc
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                  : 'text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-white/5'
              }`}
            >
              <MapPin className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
              <span className="hidden sm:inline">{t.feed.locationLabel}</span>
            </button>

            <input
              ref={photoInputRef}
              type="file"
              accept="image/*"
              onChange={(e) => void handlePhotoUpload(e)}
              className="hidden"
            />
            <input
              ref={videoInputRef}
              type="file"
              accept="video/*"
              onChange={(e) => void handleVideoUpload(e)}
              className="hidden"
            />
          </div>

          <button
            type="submit"
            disabled={!canSubmit}
            className="min-h-[44px] px-5 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] disabled:opacity-45 disabled:cursor-not-allowed text-white text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer"
          >
            {t.actions.post}
          </button>
        </div>
      </form>
    </section>
  );
};
