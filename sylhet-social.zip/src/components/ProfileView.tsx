import React, { useRef, useState } from 'react';
import {
  Ban,
  Briefcase,
  Calendar,
  Camera,
  Check,
  Edit3,
  Flag,
  LogOut,
  MapPin,
  MessageCircle,
  ShieldCheck,
  UserCheck,
  UserPlus,
  X,
} from 'lucide-react';
import { ASSET_IMAGES } from '../data/seedData';
import { useSocial } from '../context/SocialContext';
import { ReportReason } from '../types/social';
import {
  formatCount,
  getDisplayBio,
  getDisplayLocation,
  getDisplayName,
  getDisplayWork,
} from '../utils/formatters';
import { compressImageToDataUrl } from '../utils/media';
import { Avatar } from './Avatar';
import { HierarchicalLocationSelect } from './HierarchicalLocationSelect';
import { PostCard } from './PostCard';

type ProfileTab = 'posts' | 'photos' | 'friends';

export const ProfileView: React.FC = () => {
  const {
    t,
    language,
    currentUser,
    viewedProfileId,
    getUserById,
    posts,
    users,
    openProfile,
    openChatWith,
    updateProfile,
    sendFriendRequest,
    acceptFriendRequest,
    removeFriend,
    toggleFollow,
    isBlockedBetween,
    blockUser,
    unblockUser,
    reportUser,
    logout,
    showToast,
  } = useSocial();

  const [tab, setTab] = useState<ProfileTab>('posts');
  const [editOpen, setEditOpen] = useState(false);
  const [reportUserOpen, setReportUserOpen] = useState(false);
  const [reportReason, setReportReason] = useState<ReportReason>('harassment');
  const [reportDetails, setReportDetails] = useState('');

  const profileUser = getUserById(viewedProfileId) ?? currentUser ?? users[0];

  const [editName, setEditName] = useState(profileUser?.name ?? '');
  const [editBio, setEditBio] = useState(profileUser?.bio ?? '');
  const [editLocation, setEditLocation] = useState(profileUser?.location ?? '');
  const [editLocationBn, setEditLocationBn] = useState(profileUser?.locationBn ?? '');
  const [editWork, setEditWork] = useState(profileUser?.workOrStudy ?? '');
  const [editAvatar, setEditAvatar] = useState(profileUser?.avatarUrl ?? '');
  const [editCover, setEditCover] = useState(profileUser?.coverUrl ?? '');

  const avatarFileRef = useRef<HTMLInputElement>(null);
  const coverFileRef = useRef<HTMLInputElement>(null);

  if (!profileUser) return null;

  const isOwnProfile = currentUser?.uid === profileUser.uid;
  const userPosts = posts.filter((p) => p.authorId === profileUser.uid);
  const photoPosts = userPosts.filter((p) => p.mediaType === 'photo' && p.photoUrl);
  const friendUsers = isOwnProfile
    ? currentUser.friends
        .map((id) => getUserById(id))
        .filter((u): u is NonNullable<typeof u> => Boolean(u))
    : [];

  const isFriend = currentUser ? currentUser.friends.includes(profileUser.uid) : false;
  const hasSentRequest = currentUser
    ? currentUser.friendRequestsSent.includes(profileUser.uid)
    : false;
  const hasReceivedRequest = currentUser
    ? currentUser.friendRequestsReceived.includes(profileUser.uid)
    : false;
  const isFollowing = currentUser ? currentUser.following.includes(profileUser.uid) : false;
  const profileBlockState = isBlockedBetween(profileUser.uid);

  const openEditModal = () => {
    setEditName(profileUser.name);
    setEditBio(profileUser.bio);
    setEditLocation(profileUser.location);
    setEditLocationBn(profileUser.locationBn);
    setEditWork(profileUser.workOrStudy);
    setEditAvatar(profileUser.avatarUrl);
    setEditCover(profileUser.coverUrl);
    setEditOpen(true);
  };

  const handleFileUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (url: string) => void,
    immediateField?: 'avatarUrl' | 'coverUrl'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageToDataUrl(
        file,
        immediateField === 'avatarUrl' ? 512 : 1200,
        0.78
      );
      if (compressed.length > 480000) {
        showToast(
          language === 'bn'
            ? 'ছবিটি অনেক বড়, ছোট ছবি নির্বাচন করুন'
            : 'Image too large. Please pick a smaller image.'
        );
        return;
      }
      setter(compressed);
      if (immediateField && isOwnProfile) {
        await updateProfile({ [immediateField]: compressed });
      }
    } catch {
      showToast('Failed to process image');
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfile({
      name: editName.trim() || profileUser.name,
      bio: editBio.trim(),
      location: editLocation.trim(),
      locationBn: editLocationBn.trim() || editLocation.trim(),
      workOrStudy: editWork.trim(),
      avatarUrl: editAvatar,
      coverUrl: editCover,
    });
    setEditOpen(false);
  };

  const displayName = getDisplayName(profileUser, language);
  const displayBio = getDisplayBio(profileUser, language);
  const displayLocation = getDisplayLocation(profileUser, language);
  const displayWork = getDisplayWork(profileUser, language);

  return (
    <div className="space-y-4">
      <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl overflow-hidden">
        <div className="relative h-44 sm:h-60 bg-emerald-950">
          <img
            src={profileUser.coverUrl || ASSET_IMAGES.teaGardenCover}
            alt={`${displayName} cover`}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
          {isOwnProfile && (
            <>
              <button
                type="button"
                onClick={() => coverFileRef.current?.click()}
                className="absolute bottom-3 right-3 min-h-[40px] px-3.5 py-2 rounded-xl bg-black/65 hover:bg-black/80 text-white text-xs font-semibold flex items-center gap-1.5 backdrop-blur-xs cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                <span>{t.profile.changeCover}</span>
              </button>
              <input
                ref={coverFileRef}
                type="file"
                accept="image/*"
                onChange={(e) => void handleFileUpload(e, setEditCover, 'coverUrl')}
                className="hidden"
              />
            </>
          )}
        </div>

        <div className="px-4 sm:px-6 pb-5">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-12 sm:-mt-14 relative z-10">
            <div className="flex items-end gap-4">
              <div className="relative">
                <div className="rounded-full ring-4 ring-white dark:ring-[#14201B] bg-white dark:bg-[#14201B]">
                  <Avatar src={profileUser.avatarUrl} name={displayName} size="xl" />
                </div>
                {isOwnProfile && (
                  <>
                    <button
                      type="button"
                      onClick={() => avatarFileRef.current?.click()}
                      aria-label={t.profile.changeAvatar}
                      className="absolute bottom-0 right-0 w-9 h-9 rounded-full bg-[#0B6E4F] hover:bg-[#09583F] text-white ring-2 ring-white dark:ring-[#14201B] flex items-center justify-center cursor-pointer"
                    >
                      <Camera className="w-4 h-4" />
                    </button>
                    <input
                      ref={avatarFileRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => void handleFileUpload(e, setEditAvatar, 'avatarUrl')}
                      className="hidden"
                    />
                  </>
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {isOwnProfile ? (
                <>
                  <button
                    type="button"
                    onClick={openEditModal}
                    className="min-h-[44px] px-4 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold flex items-center gap-2 whitespace-nowrap cursor-pointer"
                  >
                    <Edit3 className="w-4 h-4" />
                    <span>{t.actions.editProfile}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => void logout()}
                    aria-label={t.actions.signOut}
                    className="min-h-[44px] px-3.5 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-sm font-medium text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>{t.actions.signOut}</span>
                  </button>
                </>
              ) : (
                <>
                  {isFriend ? (
                    <button
                      type="button"
                      onClick={() => void removeFriend(profileUser.uid)}
                      className="min-h-[44px] px-4 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-sm font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                    >
                      <UserCheck className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                      <span>{t.actions.friendsLabel}</span>
                    </button>
                  ) : hasReceivedRequest ? (
                    <button
                      type="button"
                      onClick={() => void acceptFriendRequest(profileUser.uid)}
                      className="min-h-[44px] px-4 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                      <span>{t.actions.accept}</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={hasSentRequest}
                      onClick={() => void sendFriendRequest(profileUser.uid)}
                      className="min-h-[44px] px-4 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] disabled:opacity-60 text-white text-sm font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span>{hasSentRequest ? t.actions.requested : t.actions.addFriend}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => void toggleFollow(profileUser.uid)}
                    className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold border whitespace-nowrap cursor-pointer ${
                      isFollowing
                        ? 'border-emerald-700/30 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300'
                        : 'border-emerald-950/15 dark:border-emerald-200/15 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5'
                    }`}
                  >
                    {isFollowing ? t.actions.following : t.actions.follow}
                  </button>

                  <button
                    type="button"
                    onClick={() => void openChatWith(profileUser.uid)}
                    className="min-h-[44px] px-4 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-white/5 text-sm font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{t.actions.message}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      profileBlockState.blockedByMe
                        ? void unblockUser(profileUser.uid)
                        : void blockUser(profileUser.uid)
                    }
                    className={`min-h-[44px] px-3.5 py-2 rounded-xl border text-sm font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                      profileBlockState.blockedByMe
                        ? 'border-emerald-700/30 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300'
                        : 'border-rose-200 dark:border-rose-800/40 text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30'
                    }`}
                  >
                    {profileBlockState.blockedByMe ? (
                      <ShieldCheck className="w-4 h-4" />
                    ) : (
                      <Ban className="w-4 h-4" />
                    )}
                    <span>
                      {profileBlockState.blockedByMe
                        ? t.messagesPage.unblockUser
                        : t.messagesPage.blockUser}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setReportUserOpen(true)}
                    aria-label={t.messagesPage.reportUser}
                    title={t.messagesPage.reportUser}
                    className="min-w-[44px] min-h-[44px] px-3 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/30 text-sm font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Flag className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>
          </div>

          <div className="mt-4 space-y-2">
            <div>
              <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                {displayName}
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                @{profileUser.username}
              </p>
            </div>

            {displayBio && (
              <p className="text-sm sm:text-[15px] text-slate-700 dark:text-slate-300 leading-relaxed max-w-2xl">
                {displayBio}
              </p>
            )}

            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 pt-1 text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              {displayLocation && (
                <span className="inline-flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                  <span>{displayLocation}</span>
                </span>
              )}
              {displayWork && (
                <span className="inline-flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                  <span>{displayWork}</span>
                </span>
              )}
              <span className="inline-flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                <span>
                  {t.profile.joined} {profileUser.joinedDate}
                </span>
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-4 pt-2 text-sm tabular-nums">
              <span>
                <strong className="font-semibold text-slate-900 dark:text-white">
                  {formatCount(profileUser.friendsCount, language)}
                </strong>{' '}
                <span className="text-slate-500 dark:text-slate-400">{t.profile.friends}</span>
              </span>
              <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>
              <span>
                <strong className="font-semibold text-slate-900 dark:text-white">
                  {formatCount(profileUser.followersCount, language)}
                </strong>{' '}
                <span className="text-slate-500 dark:text-slate-400">{t.profile.followers}</span>
              </span>
              <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>
              <span>
                <strong className="font-semibold text-slate-900 dark:text-white">
                  {formatCount(profileUser.followingCount, language)}
                </strong>{' '}
                <span className="text-slate-500 dark:text-slate-400">{t.profile.following}</span>
              </span>
            </div>
          </div>

          <div className="mt-5 pt-2 border-t border-emerald-950/10 dark:border-emerald-200/10 flex items-center gap-1">
            {(['posts', 'photos', 'friends'] as ProfileTab[]).map((tabId) => {
              const label =
                tabId === 'posts'
                  ? t.profile.posts
                  : tabId === 'photos'
                  ? t.profile.photos
                  : t.profile.friends;
              return (
                <button
                  key={tabId}
                  type="button"
                  onClick={() => setTab(tabId)}
                  className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                    tab === tabId
                      ? 'bg-[#0B6E4F] text-white'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {tab === 'posts' && (
        <div className="space-y-4">
          {userPosts.length === 0 ? (
            <div className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-10 text-center text-sm text-slate-500 dark:text-slate-400">
              {t.profile.noPostsYet}
            </div>
          ) : (
            userPosts.map((post) => <PostCard key={post.id} post={post} />)
          )}
        </div>
      )}

      {tab === 'photos' && (
        <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5">
          {photoPosts.length === 0 ? (
            <p className="text-center py-8 text-sm text-slate-500 dark:text-slate-400">
              {t.profile.noPhotosYet}
            </p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {photoPosts.map((post) => (
                <div
                  key={post.id}
                  className="aspect-[4/3] rounded-xl overflow-hidden border border-emerald-950/10 dark:border-emerald-200/10"
                >
                  <img
                    src={post.photoUrl}
                    alt={post.text || displayName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {tab === 'friends' && (
        <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 sm:p-5">
          {friendUsers.length === 0 ? (
            <p className="text-center py-8 text-sm text-slate-500 dark:text-slate-400 tabular-nums">
              {formatCount(profileUser.friendsCount, language)} {t.profile.friends}
            </p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {friendUsers.map((friend) => (
                <button
                  key={friend.uid}
                  type="button"
                  onClick={() => openProfile(friend.uid)}
                  className="flex items-center gap-3 p-3 rounded-xl border border-emerald-950/10 dark:border-emerald-200/10 hover:bg-emerald-50/60 dark:hover:bg-white/5 text-left transition-colors cursor-pointer"
                >
                  <Avatar
                    src={friend.avatarUrl}
                    name={getDisplayName(friend, language)}
                    size="md"
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                      {getDisplayName(friend, language)}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {getDisplayLocation(friend, language)}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </section>
      )}

      {editOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full sm:max-w-lg bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                {t.actions.editProfile}
              </h2>
              <button
                type="button"
                onClick={() => setEditOpen(false)}
                aria-label={t.actions.cancel}
                className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={(e) => void handleSaveEdit(e)} className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar src={editAvatar} name={editName} size="lg" />
                <div className="flex flex-wrap gap-2">
                  {[ASSET_IMAGES.avatarTariq, ASSET_IMAGES.avatarNusrat, ASSET_IMAGES.avatarRafiq].map(
                    (preset, idx) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setEditAvatar(preset)}
                        className={`rounded-full p-0.5 ${
                          editAvatar === preset ? 'ring-2 ring-emerald-700' : 'opacity-75 hover:opacity-100'
                        }`}
                      >
                        <Avatar src={preset} name={`Preset ${idx + 1}`} size="sm" />
                      </button>
                    )
                  )}
                  <button
                    type="button"
                    onClick={() => avatarFileRef.current?.click()}
                    className="min-h-[38px] px-3 py-1.5 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-white/5"
                  >
                    {t.actions.uploadPhoto}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {t.profile.fullName}
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {t.profile.bio}
                </label>
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  rows={3}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                  {t.profile.neighborhood}
                </label>
                <HierarchicalLocationSelect
                  valueEn={editLocation}
                  valueBn={editLocationBn}
                  compact
                  onChange={(loc) => {
                    if (loc) {
                      setEditLocation(loc.en);
                      setEditLocationBn(loc.bn);
                    } else {
                      setEditLocation('');
                      setEditLocationBn('');
                    }
                  }}
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {t.profile.workStudy}
                </label>
                <input
                  type="text"
                  value={editWork}
                  onChange={(e) => setEditWork(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditOpen(false)}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-sm font-semibold text-slate-700 dark:text-slate-200"
                >
                  {t.actions.cancel}
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-sm font-semibold cursor-pointer"
                >
                  {t.actions.saveChanges}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {reportUserOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full sm:max-w-md bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                {t.messagesPage.reportUser}
              </h2>
              <button
                type="button"
                onClick={() => setReportUserOpen(false)}
                aria-label={t.actions.cancel}
                className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                void reportUser(profileUser.uid, reportReason, reportDetails);
                setReportDetails('');
                setReportUserOpen(false);
              }}
              className="space-y-3.5"
            >
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                  {t.reportModal.reasonLabel}
                </label>
                <select
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value as ReportReason)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700"
                >
                  <option value="harassment">{t.reportModal.reasons.harassment}</option>
                  <option value="spam">{t.reportModal.reasons.spam}</option>
                  <option value="inappropriate">{t.reportModal.reasons.inappropriate}</option>
                  <option value="misinformation">{t.reportModal.reasons.misinformation}</option>
                  <option value="other">{t.reportModal.reasons.other}</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                  {t.reportModal.detailsLabel}
                </label>
                <textarea
                  rows={3}
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder={t.reportModal.detailsPlaceholder}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#F4F6F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-700 resize-none"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setReportUserOpen(false)}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-emerald-950/15 dark:border-emerald-200/15 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  {t.actions.cancel}
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold cursor-pointer"
                >
                  {t.actions.submitReport}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
