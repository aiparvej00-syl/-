import React, { useState } from 'react';
import {
  Bell,
  Compass,
  Home,
  Megaphone,
  MessageCircle,
  Moon,
  Search,
  ShieldCheck,
  Sun,
  User,
  Users,
} from 'lucide-react';
import { useSocial } from '../context/SocialContext';
import { NavTab } from '../types/social';
import { formatCount, getDisplayName } from '../utils/formatters';
import { Avatar } from './Avatar';

export const TopNav: React.FC = () => {
  const {
    t,
    language,
    setLanguage,
    theme,
    toggleTheme,
    currentUser,
    isAdmin,
    activeTab,
    setActiveTab,
    openProfile,
    unreadNotificationsCount,
    unreadMessagesCount,
    setAuthModalOpen,
    navigateToSearch,
    searchQuery,
  } = useSocial();

  const [localSearch, setLocalSearch] = useState(searchQuery);

  const navItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'feed', label: t.nav.feed, icon: <Home className="w-5 h-5" /> },
    {
      id: 'friends',
      label: t.nav.friends,
      icon: <Users className="w-5 h-5" />,
      badge: currentUser?.friendRequestsReceived.length || undefined,
    },
    { id: 'search', label: t.nav.search, icon: <Search className="w-5 h-5" /> },
    {
      id: 'messages',
      label: t.nav.messages,
      icon: <MessageCircle className="w-5 h-5" />,
      badge: unreadMessagesCount || undefined,
    },
    {
      id: 'notifications',
      label: t.nav.notifications,
      icon: <Bell className="w-5 h-5" />,
      badge: unreadNotificationsCount || undefined,
    },
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigateToSearch(localSearch);
  };

  return (
    <header className="sticky top-0 z-40 h-14 md:h-16 bg-white/90 dark:bg-[#14201B]/90 backdrop-blur-md border-b border-emerald-950/10 dark:border-emerald-200/10">
      <div className="max-w-[1280px] mx-auto h-full px-3 sm:px-5 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Brand Title */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('feed')}
            className="flex items-center gap-2.5 min-h-[44px] focus-visible:outline-2 focus-visible:outline-emerald-700 rounded-xl cursor-pointer"
          >
            <svg
              aria-hidden="true"
              viewBox="0 0 36 36"
              className="w-8 h-8 shrink-0"
              fill="none"
            >
              <rect width="36" height="36" rx="10" fill="#0B6E4F" />
              <path
                d="M11 24C11 16.5 16.2 11 25 10C24 18.5 19.2 24 11 24Z"
                fill="#D1FAE5"
              />
              <path
                d="M11 24C15.5 19.5 19.5 15.5 24 11"
                stroke="#0B6E4F"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            </svg>
            <span className="font-display text-lg sm:text-xl font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0">
              Sylhet Social
            </span>
          </button>
        </div>

        {/* Zone 2: Desktop Primary Navigation Tabs */}
        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-1 lg:gap-1.5"
        >
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`relative min-h-[44px] px-3 lg:px-3.5 rounded-xl flex items-center gap-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'text-[#0B6E4F] dark:text-emerald-300 bg-emerald-50/90 dark:bg-emerald-950/60'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="ml-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-[#0B6E4F] text-white text-[11px] font-semibold tabular-nums flex items-center justify-center">
                    {formatCount(item.badge, language)}
                  </span>
                )}
              </button>
            );
          })}

          {/* Admin Console Nav Tab — Strictly hidden from regular users */}
          {isAdmin && (
            <button
              type="button"
              onClick={() => setActiveTab('admin')}
              className={`min-h-[44px] px-3 lg:px-3.5 rounded-xl flex items-center gap-2 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'admin'
                  ? 'text-white bg-slate-900 dark:bg-emerald-700'
                  : 'text-slate-700 dark:text-emerald-200 hover:bg-slate-100 dark:hover:bg-white/5'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{t.nav.admin}</span>
            </button>
          )}
        </nav>

        {/* Zone 3: Search, Language, Theme & Profile */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <form onSubmit={handleSearchSubmit} className="hidden xl:block relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder={t.nav.search}
              aria-label={t.nav.search}
              className="w-40 focus:w-52 transition-all min-h-[38px] pl-9 pr-3 py-1.5 rounded-xl bg-[#F3F5F4] dark:bg-[#0D1512] border border-emerald-950/10 dark:border-emerald-200/10 text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-700"
            />
          </form>

          {/* Mobile & Tablet Locations/Attractions trigger (LeftRail hidden below lg) */}
          <button
            type="button"
            onClick={() => setActiveTab('explore')}
            aria-label={t.nav.explore}
            title={t.nav.explore}
            className={`lg:hidden min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl transition-colors cursor-pointer ${
              activeTab === 'explore'
                ? 'bg-emerald-50 dark:bg-emerald-950/60 text-[#0B6E4F] dark:text-emerald-300'
                : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5'
            }`}
          >
            <Compass className="w-5 h-5" />
          </button>

          {/* Mobile & Tablet Local Business Ads trigger (LeftRail hidden below lg) */}
          <button
            type="button"
            onClick={() => setActiveTab('advertise')}
            aria-label={t.nav.advertise}
            title={t.nav.advertise}
            className={`lg:hidden min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl transition-colors cursor-pointer ${
              activeTab === 'advertise'
                ? 'bg-emerald-50 dark:bg-emerald-950/60 text-[#0B6E4F] dark:text-emerald-300'
                : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5'
            }`}
          >
            <Megaphone className="w-4 h-4" />
          </button>

          {/* Mobile quick search trigger */}
          <button
            type="button"
            onClick={() => setActiveTab('search')}
            aria-label={t.nav.search}
            className="md:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Mobile Admin trigger — Strictly hidden from regular users */}
          {isAdmin && (
            <button
              type="button"
              onClick={() => setActiveTab('admin')}
              aria-label={t.nav.admin}
              className={`md:hidden min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl transition-colors ${
                activeTab === 'admin'
                  ? 'bg-slate-900 text-white dark:bg-emerald-700'
                  : 'text-slate-700 dark:text-emerald-200 hover:bg-slate-100 dark:hover:bg-white/5'
              }`}
            >
              <ShieldCheck className="w-5 h-5" />
            </button>
          )}

          <button
            type="button"
            onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
            aria-label={t.settings.language}
            className="min-h-[40px] px-2.5 sm:px-3 py-1.5 rounded-xl border border-emerald-950/10 dark:border-emerald-200/15 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {language === 'en' ? 'বাংলা' : 'EN'}
          </button>

          <button
            type="button"
            onClick={toggleTheme}
            aria-label={t.settings.theme}
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors cursor-pointer"
          >
            {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>

          {currentUser ? (
            <button
              type="button"
              onClick={() => openProfile(currentUser.id)}
              aria-label={t.nav.profile}
              className={`min-h-[44px] pl-1 pr-2.5 py-1 rounded-xl flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'profile'
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                  : 'hover:bg-slate-100 dark:hover:bg-white/5'
              }`}
            >
              <Avatar
                src={currentUser.avatarUrl}
                name={getDisplayName(currentUser, language)}
                size="sm"
              />
              <span className="hidden lg:inline text-sm font-semibold max-w-[100px] truncate">
                {getDisplayName(currentUser, language).split(' ')[0]}
              </span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setAuthModalOpen(true)}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-[#0B6E4F] hover:bg-[#09583F] text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <User className="w-4 h-4" />
              <span>{t.actions.signIn}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
