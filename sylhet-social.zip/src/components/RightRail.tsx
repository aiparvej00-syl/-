import React from 'react';
import { Calendar, Compass, MapPin, Megaphone, MessageCircle, UserPlus } from 'lucide-react';
import { SYLHET_COMMUNITY_PULSE } from '../data/seedData';
import { useSocial } from '../context/SocialContext';
import { getDisplayLocation, getDisplayName } from '../utils/formatters';
import { Avatar } from './Avatar';
import { SponsoredAdCard } from './SponsoredAdCard';

export const RightRail: React.FC = () => {
  const {
    t,
    language,
    currentUser,
    users,
    attractions,
    activeLocalAds,
    setActiveTab,
    openProfile,
    openChatWith,
    sendFriendRequest,
    navigateToSearch,
  } = useSocial();

  const sidebarAd = activeLocalAds.find(
    (ad) => ad.placement === 'sidebar' || ad.placement === 'both'
  );

  const suggestions = currentUser
    ? users.filter(
        (u) =>
          u.status === 'active' &&
          u.uid !== currentUser.uid &&
          !currentUser.friends.includes(u.uid) &&
          !currentUser.friendRequestsReceived.includes(u.uid)
      )
    : [];

  const contacts = currentUser
    ? users.filter((u) => u.status === 'active' && currentUser.friends.includes(u.uid))
    : [];

  return (
    <aside className="hidden xl:block xl:col-span-3 space-y-4">
      <div className="sticky top-20 space-y-4">
        {/* Sylhet Community Pulse */}
        <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 space-y-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#0B6E4F] dark:text-emerald-400" />
            <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
              {t.feed.sylhetPulse}
            </h2>
          </div>

          <div className="divide-y divide-emerald-950/10 dark:divide-emerald-200/10">
            {SYLHET_COMMUNITY_PULSE.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateToSearch(item.query)}
                className="w-full py-2.5 first:pt-1 last:pb-1 text-left hover:opacity-80 transition-opacity cursor-pointer"
              >
                <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 leading-snug">
                  {language === 'bn' ? item.titleBn : item.titleEn}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {language === 'bn' ? item.metaBn : item.metaEn}
                </p>
              </button>
            ))}
          </div>
        </section>

        {/* Moulvibazar & Sylhet Explorer */}
        <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <Compass className="w-4 h-4 text-[#0B6E4F] dark:text-emerald-400 shrink-0" />
              <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white truncate">
                {t.nav.explore}
              </h2>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('explore')}
              className="text-xs font-semibold text-[#0B6E4F] dark:text-emerald-300 hover:underline shrink-0 cursor-pointer"
            >
              {language === 'bn' ? 'সব দেখুন' : 'Browse all'}
            </button>
          </div>
          <div className="space-y-1.5">
            {attractions
              .filter((a) => a.isActive && a.isFeatured)
              .slice(0, 4)
              .map((attr) => (
                <button
                  key={attr.id}
                  type="button"
                  onClick={() => setActiveTab('explore')}
                  className="w-full py-1.5 px-2 rounded-xl hover:bg-emerald-50/70 dark:hover:bg-white/5 text-left flex items-center gap-2 cursor-pointer"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#0B6E4F] dark:text-emerald-400 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                      {language === 'bn' ? attr.nameBn : attr.name}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {language === 'bn' ? attr.upazilaNameBn || attr.upazilaName : attr.upazilaName}
                    </p>
                  </div>
                </button>
              ))}
          </div>
        </section>

        {/* People in Sylhet */}
        {suggestions.length > 0 && (
          <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 space-y-3">
            <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
              {t.feed.peopleYouMayKnow}
            </h2>

            <div className="space-y-3">
              {suggestions.slice(0, 3).map((person) => {
                const isRequested = currentUser?.friendRequestsSent.includes(person.id);
                const displayName = getDisplayName(person, language);
                return (
                  <div key={person.id} className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => openProfile(person.id)}
                      className="flex items-center gap-2.5 min-w-0 text-left cursor-pointer"
                    >
                      <Avatar src={person.avatarUrl} name={displayName} size="sm" />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                          {displayName}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {getDisplayLocation(person, language)}
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      disabled={isRequested}
                      onClick={() => void sendFriendRequest(person.uid)}
                      aria-label={t.actions.addFriend}
                      className="min-h-[36px] px-2.5 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-950 disabled:opacity-50 text-[#0B6E4F] dark:text-emerald-300 text-xs font-semibold flex items-center gap-1 shrink-0 cursor-pointer"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>{isRequested ? t.actions.requested : t.actions.addFriend}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* Quick Contacts for Private Messaging */}
        {contacts.length > 0 && (
          <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 space-y-2.5">
            <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
              {t.feed.quickContacts}
            </h2>

            <div className="space-y-1">
              {contacts.map((friend) => {
                const displayName = getDisplayName(friend, language);
                return (
                  <button
                    key={friend.uid}
                    type="button"
                    onClick={() => void openChatWith(friend.uid)}
                    className="w-full min-h-[44px] px-2 py-1.5 rounded-xl flex items-center justify-between gap-2 hover:bg-slate-50 dark:hover:bg-white/5 text-left transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Avatar
                        src={friend.avatarUrl}
                        name={displayName}
                        size="sm"
                        showOnline
                        isOnline={friend.isOnline}
                      />
                      <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                        {displayName}
                      </span>
                    </div>
                    <MessageCircle className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  </button>
                );
              })}
            </div>
          </section>
        )}

        {/* Sponsored Sidebar Slot or Promote CTA */}
        {sidebarAd ? (
          <SponsoredAdCard ad={sidebarAd} compact />
        ) : (
          <section className="bg-white dark:bg-[#14201B] border border-emerald-950/10 dark:border-emerald-200/10 rounded-2xl p-4 space-y-2">
            <div className="flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-[#0B6E4F] dark:text-emerald-400 shrink-0" />
              <h2 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                {t.ads.portalTitle}
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              {t.ads.portalSubtitle}
            </p>
            <button
              type="button"
              onClick={() => setActiveTab('advertise')}
              className="w-full min-h-[40px] px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-[#0B6E4F] dark:text-emerald-300 text-xs font-semibold cursor-pointer"
            >
              {t.sponsoredCard.promoteBusiness}
            </button>
          </section>
        )}
      </div>
    </aside>
  );
};
