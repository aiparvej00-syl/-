import { Language } from '../types/social';

export interface TranslationSchema {
  appName: string;
  tagline: string;
  nav: {
    feed: string;
    explore: string;
    advertise: string;
    friends: string;
    search: string;
    messages: string;
    notifications: string;
    profile: string;
    saved: string;
    admin: string;
  };
  actions: {
    createPost: string;
    post: string;
    like: string;
    liked: string;
    comment: string;
    share: string;
    shared: string;
    save: string;
    saved: string;
    send: string;
    cancel: string;
    editProfile: string;
    saveChanges: string;
    signIn: string;
    signInWithGoogle: string;
    register: string;
    createAccount: string;
    signOut: string;
    switchAccount: string;
    addFriend: string;
    requested: string;
    accept: string;
    decline: string;
    friendsLabel: string;
    unfriend: string;
    follow: string;
    following: string;
    message: string;
    viewProfile: string;
    markAllRead: string;
    uploadPhoto: string;
    uploadVideo: string;
    removeMedia: string;
    copyLink: string;
    linkCopied: string;
    repostToFeed: string;
    back: string;
    reportPost: string;
    submitReport: string;
    deletePost: string;
  };
  feed: {
    allPosts: string;
    photos: string;
    videos: string;
    friendsOnly: string;
    whatsOnMind: string;
    addPhoto: string;
    addVideo: string;
    textCard: string;
    locationLabel: string;
    selectLocation: string;
    writeComment: string;
    noCommentsYet: string;
    noPostsFound: string;
    likesCount: string;
    commentsCount: string;
    sharesCount: string;
    sharedAPost: string;
    sylhetPulse: string;
    peopleYouMayKnow: string;
    quickContacts: string;
    teaGardenBanner: string;
    pendingReviewBadge: string;
    maintenanceNotice: string;
    suspendedNotice: string;
  };
  profile: {
    posts: string;
    photos: string;
    friends: string;
    followers: string;
    following: string;
    about: string;
    livesIn: string;
    worksOrStudies: string;
    joined: string;
    changeAvatar: string;
    changeCover: string;
    fullName: string;
    bio: string;
    neighborhood: string;
    workStudy: string;
    noPhotosYet: string;
    noPostsYet: string;
  };
  friendsPage: {
    allFriends: string;
    requests: string;
    followers: string;
    following: string;
    discover: string;
    mutualFriends: string;
    noRequests: string;
    noFriends: string;
  };
  searchPage: {
    placeholder: string;
    allResults: string;
    people: string;
    posts: string;
    popularTopics: string;
    noResults: string;
    searchPrompt: string;
  };
  notificationsPage: {
    title: string;
    unread: string;
    allCaughtUp: string;
    likedYourPost: string;
    commentedOnPost: string;
    sharedYourPost: string;
    sentFriendRequest: string;
    acceptedFriendRequest: string;
    startedFollowing: string;
    adminBroadcast: string;
    moderationAlert: string;
  };
  messagesPage: {
    title: string;
    searchChats: string;
    typeMessage: string;
    startChat: string;
    activeNow: string;
    offline: string;
    typing: string;
    sylhetMember: string;
    selectConversation: string;
    newChat: string;
    sent: string;
    delivered: string;
    seen: string;
    sendImage: string;
    sendVideo: string;
    recordVoice: string;
    stopVoice: string;
    cancelVoice: string;
    recording: string;
    voiceMessage: string;
    photoLabel: string;
    videoLabel: string;
    uploadingMedia: string;
    uploadFailed: string;
    micDenied: string;
    fileTooLarge: string;
    blockUser: string;
    unblockUser: string;
    reportUser: string;
    blockedByYouBanner: string;
    blockedByOtherBanner: string;
    userBlockedToast: string;
    userUnblockedToast: string;
    offlineBanner: string;
    loadingMessages: string;
    enableBrowserAlerts: string;
    browserAlertsEnabled: string;
    newMessageFrom: string;
    youPrefix: string;
    viewFullImage: string;
  };
  auth: {
    welcomeTitle: string;
    welcomeSubtitle: string;
    googleSignInTitle: string;
    googleSignInHint: string;
    registrationsPaused: string;
    authError: string;
    completeProfileTitle: string;
  };
  reportModal: {
    title: string;
    reasonLabel: string;
    detailsLabel: string;
    detailsPlaceholder: string;
    submitted: string;
    reasons: {
      spam: string;
      harassment: string;
      misinformation: string;
      inappropriate: string;
      other: string;
    };
  };
  admin: {
    title: string;
    subtitle: string;
    verifyTitle: string;
    verifyDesc: string;
    verifyButton: string;
    lockConsole: string;
    backToApp: string;
    tabs: {
      analytics: string;
      users: string;
      posts: string;
      media: string;
      reports: string;
      notifications: string;
      settings: string;
    };
    metrics: {
      totalUsers: string;
      totalPosts: string;
      pendingReports: string;
      totalEngagement: string;
      mediaDistribution: string;
      moderationStatus: string;
      recentAudit: string;
    };
    users: {
      searchPlaceholder: string;
      roleLabel: string;
      statusLabel: string;
      active: string;
      suspended: string;
      suspend: string;
      activate: string;
      makeAdmin: string;
      makeModerator: string;
      makeUser: string;
    };
    posts: {
      all: string;
      approved: string;
      pending: string;
      hidden: string;
      approve: string;
      hide: string;
      delete: string;
      notePlaceholder: string;
    };
    media: {
      allMedia: string;
      photosOnly: string;
      videosOnly: string;
      noMedia: string;
    };
    reports: {
      all: string;
      pending: string;
      resolved: string;
      dismissed: string;
      resolveHide: string;
      resolveKeep: string;
      dismiss: string;
      noReports: string;
    };
    broadcast: {
      titleLabel: string;
      messageLabel: string;
      sendBroadcast: string;
      sentSuccess: string;
      recentBroadcasts: string;
    };
    settings: {
      siteName: string;
      maintenanceMode: string;
      maintenanceDesc: string;
      allowRegistrations: string;
      allowRegistrationsDesc: string;
      requirePostReview: string;
      requirePostReviewDesc: string;
      maxUploadMb: string;
      bannerEn: string;
      bannerBn: string;
      saveSettings: string;
      seedStarterPosts: string;
    };
    locations: {
      tabLabel: string;
      locationsSubtab: string;
      attractionsSubtab: string;
      seedDefaults: string;
      addLocation: string;
      editLocation: string;
      addAttraction: string;
      editAttraction: string;
      levelLabel: string;
      parentLabel: string;
      nameEnLabel: string;
      nameBnLabel: string;
      activeLabel: string;
      featuredLabel: string;
      categoryLabel: string;
      locationSummaryEn: string;
      locationSummaryBn: string;
      descEn: string;
      descBn: string;
      saveItem: string;
      deleteConfirm: string;
      seededToast: string;
      savedToast: string;
      deletedToast: string;
    };
    monetization: {
      tabLabel: string;
      subtabs: {
        adsQueue: string;
        packages: string;
        admobSettings: string;
      };
      confirmedRevenueBdt: string;
      pendingRevenueBdt: string;
      activeAdsCount: string;
      pendingReviewCount: string;
      totalImpressions: string;
      totalClicks: string;
      exportCsv: string;
      seedDefaults: string;
      filterAll: string;
      approveAndPublish: string;
      pauseAd: string;
      rejectAd: string;
      confirmManualPayment: string;
      markRefunded: string;
      markUnpaid: string;
      paymentMethodLabel: string;
      adminNotePlaceholder: string;
      noAdsFound: string;
      addPackage: string;
      editPackage: string;
      packageNameEn: string;
      packageNameBn: string;
      packageDescEn: string;
      packageDescBn: string;
      durationDays: string;
      priceBdt: string;
      placementLabel: string;
      savePackage: string;
      admobArchitectureTitle: string;
      admobArchitectureDesc: string;
      admobEnvLabel: string;
      devTestMode: string;
      prodReadyMode: string;
      testIdsNotice: string;
      bannerToggle: string;
      nativeToggle: string;
      localAdsToggle: string;
      requireConsentToggle: string;
      feedIntervalLabel: string;
      paymentInstructionsEn: string;
      paymentInstructionsBn: string;
      saveConfig: string;
      configSavedToast: string;
      paymentConfirmedToast: string;
      statusUpdatedToast: string;
    };
  };
  ads: {
    portalTitle: string;
    portalSubtitle: string;
    packagesTitle: string;
    submitTab: string;
    myAdsTab: string;
    businessName: string;
    categoryLabel: string;
    titleEn: string;
    titleBn: string;
    descEn: string;
    descBn: string;
    imageLabel: string;
    uploadBanner: string;
    useSamplePhoto: string;
    phoneLabel: string;
    whatsappLabel: string;
    emailLabel: string;
    websiteLabel: string;
    ctaLabel: string;
    locationTitle: string;
    packageLabel: string;
    daysUnit: string;
    manualPaymentNoticeTitle: string;
    submitAdBtn: string;
    submittedToast: string;
    noMyAds: string;
    submitPaymentProofTitle: string;
    trxPlaceholder: string;
    submitProofBtn: string;
    proofSubmittedToast: string;
    pauseMyAd: string;
    deleteUnpaidAd: string;
    reviewStatusLabel: string;
    paymentStatusLabel: string;
    scheduleLabel: string;
    performanceLabel: string;
    impressions: string;
    clicks: string;
    statuses: {
      pending_review: string;
      approved: string;
      paused: string;
      rejected: string;
      expired: string;
    };
    paymentStatuses: {
      unpaid: string;
      pending_verification: string;
      paid: string;
      refunded: string;
    };
    paymentMethods: {
      manual_bkash: string;
      manual_nagad: string;
      bank_transfer: string;
      cash_office: string;
      none: string;
    };
    placements: {
      feed: string;
      sidebar: string;
      both: string;
    };
    ctas: {
      call_now: string;
      whatsapp: string;
      visit_website: string;
      learn_more: string;
    };
    categories: {
      restaurant: string;
      hotel_resort: string;
      retail: string;
      education: string;
      healthcare: string;
      tech_services: string;
      tourism: string;
      real_estate: string;
      other: string;
    };
  };
  sponsoredCard: {
    sponsored: string;
    paidAd: string;
    whyThisAd: string;
    hideAd: string;
    promoteBusiness: string;
    adHiddenToast: string;
    admobTestLabel: string;
    admobTestBannerTitle: string;
    admobTestBannerSubtitle: string;
    admobTestNativeTitle: string;
    admobAndroidBridgeReady: string;
    admobWebPreviewMode: string;
  };
  consent: {
    bannerTitle: string;
    bannerBody: string;
    acceptPersonalized: string;
    useNonPersonalized: string;
    essentialOnly: string;
    privacyLink: string;
    modalTitle: string;
    modalSubtitle: string;
    currentChoiceLabel: string;
    googleAdmobPolicyTitle: string;
    googleAdmobPolicyBody: string;
    localAdsPolicyTitle: string;
    localAdsPolicyBody: string;
    noAutoChargeTitle: string;
    noAutoChargeBody: string;
    savedToast: string;
    choices: {
      unset: string;
      personalized: string;
      non_personalized: string;
      essential_only: string;
    };
  };
  locationsPage: {
    title: string;
    subtitle: string;
    searchPlaceholder: string;
    allDistricts: string;
    allUpazilas: string;
    allCategories: string;
    divisionLabel: string;
    districtLabel: string;
    upazilaLabel: string;
    unionLabel: string;
    villageLabel: string;
    attractionLabel: string;
    attractionsTitle: string;
    hierarchyTitle: string;
    moulvibazarUpazilasTitle: string;
    featuredBadge: string;
    explorePosts: string;
    tagInPost: string;
    noAttractionsMatch: string;
    noLocationsMatch: string;
    clearFilters: string;
    selectDivision: string;
    selectDistrict: string;
    selectUpazila: string;
    selectUnion: string;
    selectVillage: string;
    categories: {
      waterfall: string;
      forest: string;
      lake: string;
      haor: string;
      tea_garden: string;
      cultural: string;
      river: string;
      heritage: string;
    };
  };
  settings: {
    language: string;
    theme: string;
    lightMode: string;
    darkMode: string;
  };
}

export const translations: Record<Language, TranslationSchema> = {
  en: {
    appName: 'Sylhet Social',
    tagline: 'Connecting tea-valley communities, creators, and friends across Sylhet.',
    nav: {
      feed: 'Feed',
      explore: 'Locations & Attractions',
      advertise: 'Advertise',
      friends: 'Friends',
      search: 'Search',
      messages: 'Messages',
      notifications: 'Alerts',
      profile: 'Profile',
      saved: 'Saved',
      admin: 'Admin',
    },
    actions: {
      createPost: 'Create Post',
      post: 'Publish',
      like: 'Like',
      liked: 'Liked',
      comment: 'Comment',
      share: 'Share',
      shared: 'Shared',
      save: 'Save',
      saved: 'Saved',
      send: 'Send',
      cancel: 'Cancel',
      editProfile: 'Edit Profile',
      saveChanges: 'Save Changes',
      signIn: 'Sign In',
      signInWithGoogle: 'Continue with Google',
      register: 'Register',
      createAccount: 'Create Account',
      signOut: 'Sign Out',
      switchAccount: 'Switch Account',
      addFriend: 'Add Friend',
      requested: 'Requested',
      accept: 'Accept',
      decline: 'Decline',
      friendsLabel: 'Friends',
      unfriend: 'Unfriend',
      follow: 'Follow',
      following: 'Following',
      message: 'Message',
      viewProfile: 'View Profile',
      markAllRead: 'Mark all read',
      uploadPhoto: 'Upload Photo',
      uploadVideo: 'Upload Video',
      removeMedia: 'Remove',
      copyLink: 'Copy Post Link',
      linkCopied: 'Post link copied',
      repostToFeed: 'Share to Your Feed',
      back: 'Back',
      reportPost: 'Report',
      submitReport: 'Submit Report',
      deletePost: 'Delete',
    },
    feed: {
      allPosts: 'All Posts',
      photos: 'Photos',
      videos: 'Videos',
      friendsOnly: 'Friends',
      whatsOnMind: 'Share a story from Sylhet...',
      addPhoto: 'Photo',
      addVideo: 'Video',
      textCard: 'Color Post',
      locationLabel: 'Location',
      selectLocation: 'Tag a Sylhet spot',
      writeComment: 'Write a comment...',
      noCommentsYet: 'Be the first to comment on this post.',
      noPostsFound: 'No posts match this view yet. Publish the first story from Sylhet!',
      likesCount: 'likes',
      commentsCount: 'comments',
      sharesCount: 'shares',
      sharedAPost: 'shared a post',
      sylhetPulse: 'Sylhet Community Pulse',
      peopleYouMayKnow: 'People in Sylhet',
      quickContacts: 'Contacts',
      teaGardenBanner: 'Explore Ratargul, Jaflong & Surma stories today',
      pendingReviewBadge: 'Pending Admin Review',
      maintenanceNotice: 'Sylhet Social is currently in scheduled maintenance mode. Posting is temporarily limited to administrators.',
      suspendedNotice: 'Your account is currently suspended. Contact an administrator for assistance.',
    },
    profile: {
      posts: 'Posts',
      photos: 'Photos',
      friends: 'Friends',
      followers: 'Followers',
      following: 'Following',
      about: 'About',
      livesIn: 'Lives in',
      worksOrStudies: 'Works / Studies at',
      joined: 'Joined',
      changeAvatar: 'Change Profile Photo',
      changeCover: 'Change Cover Photo',
      fullName: 'Full Name',
      bio: 'Bio',
      neighborhood: 'Neighborhood in Sylhet',
      workStudy: 'Work or University',
      noPhotosYet: 'No photos shared yet.',
      noPostsYet: 'No posts shared yet.',
    },
    friendsPage: {
      allFriends: 'All Friends',
      requests: 'Requests',
      followers: 'Followers',
      following: 'Following',
      discover: 'Discover',
      mutualFriends: 'mutual friends',
      noRequests: 'No pending friend requests right now.',
      noFriends: 'Connect with people from Sylhet to build your circle.',
    },
    searchPage: {
      placeholder: 'Search people, posts, Ratargul, SUST...',
      allResults: 'All',
      people: 'People',
      posts: 'Posts',
      popularTopics: 'Popular in Sylhet',
      noResults: 'No matching people or posts found.',
      searchPrompt: 'Search Sylhet Social by name, neighborhood, or post topic.',
    },
    notificationsPage: {
      title: 'Notifications',
      unread: 'unread',
      allCaughtUp: 'You are all caught up.',
      likedYourPost: 'liked your post',
      commentedOnPost: 'commented on your post',
      sharedYourPost: 'shared your post',
      sentFriendRequest: 'sent you a friend request',
      acceptedFriendRequest: 'accepted your friend request',
      startedFollowing: 'started following you',
      adminBroadcast: 'Sylhet Social Announcement',
      moderationAlert: 'Moderation update on your content',
    },
    messagesPage: {
      title: 'Private Messages',
      searchChats: 'Search conversations...',
      typeMessage: 'Write a message...',
      startChat: 'Start a conversation',
      activeNow: 'Active now',
      offline: 'Offline',
      typing: 'typing...',
      sylhetMember: 'Sylhet Community',
      selectConversation: 'Choose a conversation or start a new chat.',
      newChat: 'New Message',
      sent: 'Sent',
      delivered: 'Delivered',
      seen: 'Seen',
      sendImage: 'Send photo',
      sendVideo: 'Send video',
      recordVoice: 'Record voice message',
      stopVoice: 'Send voice',
      cancelVoice: 'Cancel',
      recording: 'Recording',
      voiceMessage: 'Voice message',
      photoLabel: 'Photo',
      videoLabel: 'Video',
      uploadingMedia: 'Uploading media...',
      uploadFailed: 'Media upload failed. Check storage permissions and try again.',
      micDenied: 'Microphone access denied or unavailable.',
      fileTooLarge: 'File exceeds the allowed upload size limit.',
      blockUser: 'Block User',
      unblockUser: 'Unblock User',
      reportUser: 'Report User',
      blockedByYouBanner: 'You blocked this user. Unblock them to send or receive messages.',
      blockedByOtherBanner: 'You cannot send messages to this user.',
      userBlockedToast: 'User blocked',
      userUnblockedToast: 'User unblocked',
      offlineBanner: 'You are currently offline. Messages will sync automatically when reconnected.',
      loadingMessages: 'Loading messages...',
      enableBrowserAlerts: 'Enable Chat Alerts',
      browserAlertsEnabled: 'Chat Alerts On',
      newMessageFrom: 'New message from',
      youPrefix: 'You:',
      viewFullImage: 'View full image',
    },
    auth: {
      welcomeTitle: 'Welcome to Sylhet Social',
      welcomeSubtitle: 'Share moments from the Surma River, tea estates, campuses, and neighborhoods across Sylhet.',
      googleSignInTitle: 'Sign in to Sylhet Social',
      googleSignInHint: 'Use your verified Google account to connect with friends, post photos & videos, and sync across devices.',
      registrationsPaused: 'New member registrations are temporarily paused by an administrator.',
      authError: 'Sign-in could not be completed. Please allow popups and try again.',
      completeProfileTitle: 'Customize Your Sylhet Profile',
    },
    reportModal: {
      title: 'Report Content',
      reasonLabel: 'Why are you reporting this post?',
      detailsLabel: 'Additional details (optional)',
      detailsPlaceholder: 'Provide context for the moderation team...',
      submitted: 'Report submitted to Sylhet Social moderators.',
      reasons: {
        spam: 'Spam or misleading promotion',
        harassment: 'Harassment or abusive language',
        misinformation: 'False information',
        inappropriate: 'Inappropriate media or content',
        other: 'Other policy concern',
      },
    },
    admin: {
      title: 'Admin Console',
      subtitle: 'Role-based moderation, user governance, analytics, and platform controls for Sylhet Social.',
      verifyTitle: 'Verify Admin Identity',
      verifyDesc: 'For security, confirm your authorized Google administrator session before unlocking management controls.',
      verifyButton: 'Verify with Google',
      lockConsole: 'Lock Console',
      backToApp: 'Back to Feed',
      tabs: {
        analytics: 'Analytics',
        users: 'Users',
        posts: 'Posts',
        media: 'Photos & Videos',
        reports: 'Reports',
        notifications: 'Broadcasts',
        settings: 'App Settings',
      },
      metrics: {
        totalUsers: 'Total Members',
        totalPosts: 'Total Posts',
        pendingReports: 'Pending Reports',
        totalEngagement: 'Total Engagement',
        mediaDistribution: 'Content Type Breakdown',
        moderationStatus: 'Moderation Health',
        recentAudit: 'Recent Admin Audit Trail',
      },
      users: {
        searchPlaceholder: 'Search members by name, username, or area...',
        roleLabel: 'Role',
        statusLabel: 'Status',
        active: 'Active',
        suspended: 'Suspended',
        suspend: 'Suspend',
        activate: 'Activate',
        makeAdmin: 'Set Admin',
        makeModerator: 'Set Moderator',
        makeUser: 'Set User',
      },
      posts: {
        all: 'All',
        approved: 'Approved',
        pending: 'Pending',
        hidden: 'Hidden',
        approve: 'Approve',
        hide: 'Hide',
        delete: 'Delete',
        notePlaceholder: 'Moderation note (optional)...',
      },
      media: {
        allMedia: 'All Media',
        photosOnly: 'Photos',
        videosOnly: 'Videos',
        noMedia: 'No photo or video posts uploaded yet.',
      },
      reports: {
        all: 'All',
        pending: 'Pending',
        resolved: 'Resolved',
        dismissed: 'Dismissed',
        resolveHide: 'Hide Post & Resolve',
        resolveKeep: 'Keep Post & Resolve',
        dismiss: 'Dismiss',
        noReports: 'No moderation reports found.',
      },
      broadcast: {
        titleLabel: 'Announcement Title',
        messageLabel: 'Notification Message',
        sendBroadcast: 'Send to All Members',
        sentSuccess: 'Broadcast notification delivered to all members.',
        recentBroadcasts: 'Sent Broadcasts & Alerts',
      },
      settings: {
        siteName: 'Platform Name',
        maintenanceMode: 'Maintenance Mode',
        maintenanceDesc: 'Pause regular member posting while admins perform updates.',
        allowRegistrations: 'Allow New Member Profiles',
        allowRegistrationsDesc: 'Enable new Google users to initialize member profiles.',
        requirePostReview: 'Require Post Moderation Review',
        requirePostReviewDesc: 'New posts enter pending queue for admin approval before appearing publicly.',
        maxUploadMb: 'Max Media Size (MB)',
        bannerEn: 'Featured Community Banner (English)',
        bannerBn: 'Featured Community Banner (Bengali)',
        saveSettings: 'Save App Settings',
        seedStarterPosts: 'Publish Sylhet Starter Showcase Posts',
      },
      locations: {
        tabLabel: 'Locations & Attractions',
        locationsSubtab: 'Hierarchical Locations',
        attractionsSubtab: 'Tourist Attractions',
        seedDefaults: 'Sync Official Moulvibazar Data',
        addLocation: 'Add Location Node',
        editLocation: 'Edit Location Node',
        addAttraction: 'Add Tourist Attraction',
        editAttraction: 'Edit Tourist Attraction',
        levelLabel: 'Hierarchy Level',
        parentLabel: 'Parent Administrative Unit',
        nameEnLabel: 'Name (English)',
        nameBnLabel: 'Name (Bengali)',
        activeLabel: 'Active & Visible',
        featuredLabel: 'Featured Attraction',
        categoryLabel: 'Category',
        locationSummaryEn: 'Location Summary (English)',
        locationSummaryBn: 'Location Summary (Bengali)',
        descEn: 'Description (English)',
        descBn: 'Description (Bengali)',
        saveItem: 'Save Changes',
        deleteConfirm: 'Remove',
        seededToast: 'Official Moulvibazar locations & attractions synced to Firestore',
        savedToast: 'Saved to directory',
        deletedToast: 'Removed from directory',
      },
      monetization: {
        tabLabel: 'Monetization & Ads',
        subtabs: {
          adsQueue: 'Ad Records & Payments',
          packages: 'Pricing & Durations',
          admobSettings: 'AdMob & Placements',
        },
        confirmedRevenueBdt: 'Confirmed Paid Revenue',
        pendingRevenueBdt: 'Pending / Unverified Fee',
        activeAdsCount: 'Live Approved Ads',
        pendingReviewCount: 'Pending Review / Payment',
        totalImpressions: 'Total Ad Views',
        totalClicks: 'Total Ad Clicks',
        exportCsv: 'Export Revenue CSV',
        seedDefaults: 'Sync Default Packages & Config',
        filterAll: 'All Ads',
        approveAndPublish: 'Approve & Activate',
        pauseAd: 'Pause Ad',
        rejectAd: 'Reject',
        confirmManualPayment: 'Confirm Manual Payment',
        markRefunded: 'Mark Refunded',
        markUnpaid: 'Reset to Unpaid',
        paymentMethodLabel: 'Payment Channel',
        adminNotePlaceholder: 'Review or payment verification note...',
        noAdsFound: 'No local business advertisements submitted yet.',
        addPackage: 'Add Pricing Package',
        editPackage: 'Edit Pricing Package',
        packageNameEn: 'Package Name (English)',
        packageNameBn: 'Package Name (Bengali)',
        packageDescEn: 'Description (English)',
        packageDescBn: 'Description (Bengali)',
        durationDays: 'Duration (Days)',
        priceBdt: 'Price (BDT ৳)',
        placementLabel: 'Feed / Sidebar Placement',
        savePackage: 'Save Package',
        admobArchitectureTitle: 'Android Google AdMob Integration Architecture',
        admobArchitectureDesc: 'Development uses Google Official Test Ad Unit IDs only. Production AdMob unit IDs remain marked placeholders until explicit release approval.',
        admobEnvLabel: 'AdMob Runtime Mode',
        devTestMode: 'Development Test Units Only (Active Lock)',
        prodReadyMode: 'Production Placeholders Check (Falls back to Test IDs while placeholder)',
        testIdsNotice: 'Official Google Test IDs are enforced automatically whenever production constants still start with REPLACE_WITH_PRODUCTION_.',
        bannerToggle: 'Enable AdMob Test Banner Slot Preview',
        nativeToggle: 'Enable AdMob Test Native Card Slot Preview',
        localAdsToggle: 'Show Approved Paid Local Business Ads in Feed & Rail',
        requireConsentToggle: 'Require Ad Privacy Consent Prompt (UMP Compliant)',
        feedIntervalLabel: 'Insert Sponsored Slot After Every N Organic Posts',
        paymentInstructionsEn: 'Manual Payment Instructions (English)',
        paymentInstructionsBn: 'Manual Payment Instructions (Bengali)',
        saveConfig: 'Save Monetization Settings',
        configSavedToast: 'Monetization & AdMob configuration saved',
        paymentConfirmedToast: 'Manual payment status updated and logged',
        statusUpdatedToast: 'Advertisement status updated',
      },
    },
    ads: {
      portalTitle: 'Sylhet Division Local Business Ads',
      portalSubtitle: 'Promote your restaurant, tea resort, shop, coaching center, or local service across Sylhet, Moulvibazar, Sunamganj & Habiganj.',
      packagesTitle: 'Transparent Duration & Pricing Tiers',
      submitTab: 'Submit New Ad',
      myAdsTab: 'My Campaigns & Payment Status',
      businessName: 'Business Name',
      categoryLabel: 'Business Category',
      titleEn: 'Ad Headline (English)',
      titleBn: 'Ad Headline (Bengali - Optional)',
      descEn: 'Offer & Details (English)',
      descBn: 'Offer & Details (Bengali - Optional)',
      imageLabel: 'Promotional Image (Optional)',
      uploadBanner: 'Upload Business Photo',
      useSamplePhoto: 'Use Sylhet Preset Image',
      phoneLabel: 'Contact Phone Number',
      whatsappLabel: 'WhatsApp Number (Optional)',
      emailLabel: 'Business Email (Optional)',
      websiteLabel: 'Website or Page URL (Optional)',
      ctaLabel: 'Action Button',
      locationTitle: 'Target Business Location (Sylhet Division)',
      packageLabel: 'Select Ad Package',
      daysUnit: 'days',
      manualPaymentNoticeTitle: 'Manual Review & Payment Verification Required',
      submitAdBtn: 'Submit Ad for Review (No Auto-Charge)',
      submittedToast: 'Ad submitted for admin review. Next, submit your manual payment TrxID.',
      noMyAds: 'You have not submitted any local business advertisements yet.',
      submitPaymentProofTitle: 'Submit Manual Payment Reference',
      trxPlaceholder: 'Enter bKash/Nagad TrxID or Bank Reference...',
      submitProofBtn: 'Send Reference for Admin Verification',
      proofSubmittedToast: 'Payment reference submitted. Waiting for manual admin confirmation.',
      pauseMyAd: 'Pause Campaign',
      deleteUnpaidAd: 'Withdraw Unpaid Ad',
      reviewStatusLabel: 'Review Status',
      paymentStatusLabel: 'Payment Status',
      scheduleLabel: 'Active Window',
      performanceLabel: 'Engagement',
      impressions: 'views',
      clicks: 'clicks',
      statuses: {
        pending_review: 'Pending Admin Review',
        approved: 'Approved',
        paused: 'Paused',
        rejected: 'Rejected',
        expired: 'Expired',
      },
      paymentStatuses: {
        unpaid: 'Unpaid (Not Charged)',
        pending_verification: 'Pending Admin Verification',
        paid: 'Manually Confirmed Paid',
        refunded: 'Refunded',
      },
      paymentMethods: {
        manual_bkash: 'Manual bKash',
        manual_nagad: 'Manual Nagad',
        bank_transfer: 'Bank Transfer',
        cash_office: 'Cash / In-Person Office',
        none: 'Not Selected',
      },
      placements: {
        feed: 'News Feed',
        sidebar: 'Desktop Rail',
        both: 'News Feed & Rail',
      },
      ctas: {
        call_now: 'Call Business',
        whatsapp: 'Message on WhatsApp',
        visit_website: 'Visit Website',
        learn_more: 'View Contact Info',
      },
      categories: {
        restaurant: 'Restaurant & Dining',
        hotel_resort: 'Hotel & Tea Resort',
        retail: 'Shop & Retail',
        education: 'Education & Coaching',
        healthcare: 'Clinic & Healthcare',
        tech_services: 'Tech & Local Services',
        tourism: 'Tour & Travel',
        real_estate: 'Property & Housing',
        other: 'Local Enterprise',
      },
    },
    sponsoredCard: {
      sponsored: 'Sponsored',
      paidAd: 'Paid Advertisement',
      whyThisAd: 'Why this ad?',
      hideAd: 'Hide ad',
      promoteBusiness: 'Advertise Here',
      adHiddenToast: 'Ad hidden for this session',
      admobTestLabel: 'Google AdMob · Test Ad Unit',
      admobTestBannerTitle: 'Android AdMob Test Slot (Development Only)',
      admobTestBannerSubtitle: 'Uses official Google test unit IDs cleanly separated from organic posts. No real ad revenue or charges occur.',
      admobTestNativeTitle: 'Google AdMob Test Native Ad Slot',
      admobAndroidBridgeReady: 'Android Bridge Ready',
      admobWebPreviewMode: 'Web Test Preview',
    },
    consent: {
      bannerTitle: 'Ad Privacy & Consent Preferences',
      bannerBody: 'Sylhet Social cleanly separates sponsored local ads and future Android AdMob test slots from community posts. Choose how ad personalization works for your account.',
      acceptPersonalized: 'Allow Relevant Local Ads',
      useNonPersonalized: 'Non-Personalized Only',
      essentialOnly: 'Essential Only (Disable AdMob Test Slots)',
      privacyLink: 'Ad Privacy & Policy',
      modalTitle: 'Advertising Privacy, Consent & Google Policy Compliance',
      modalSubtitle: 'Transparent controls aligned with Google AdMob UMP & local advertising standards.',
      currentChoiceLabel: 'Your Current Consent Setting',
      googleAdmobPolicyTitle: '1. Google AdMob & Android App Policy',
      googleAdmobPolicyBody: 'During development, only official Google AdMob Test Ad Unit IDs (ca-app-pub-3940256099942544/*) are configured. Non-personalized ad requests pass npa=1 automatically when you decline personalization. Sponsored units are always clearly labeled and never mimic likes, comments, or friend posts.',
      localAdsPolicyTitle: '2. Local Sylhet Business Ads & User Control',
      localAdsPolicyBody: 'Local businesses may display approved, paid promotions tagged to Sylhet Division locations. You may hide any sponsored card or adjust your privacy preference at any time.',
      noAutoChargeTitle: '3. Manual Verification & No Hidden Charges',
      noAutoChargeBody: 'Sylhet Social does not auto-charge cards or mobile wallets in-app. Every local ad campaign requires manual admin moderation and explicit manual payment confirmation before appearing in the feed.',
      savedToast: 'Ad privacy preference saved',
      choices: {
        unset: 'Not Chosen Yet',
        personalized: 'Personalized & Local Ads',
        non_personalized: 'Non-Personalized Ads (npa=1)',
        essential_only: 'Essential Only (No AdMob Test Slots)',
      },
    },
    locationsPage: {
      title: 'Sylhet & Moulvibazar Explorer',
      subtitle: 'Browse hierarchical administrative regions and iconic tourist attractions across Sylhet Division.',
      searchPlaceholder: 'Search districts, upazilas, unions, villages, or attractions...',
      allDistricts: 'All Districts',
      allUpazilas: 'All Upazilas',
      allCategories: 'All Categories',
      divisionLabel: 'Division',
      districtLabel: 'District',
      upazilaLabel: 'Upazila',
      unionLabel: 'Union',
      villageLabel: 'Village / Area',
      attractionLabel: 'Tourist Attraction',
      attractionsTitle: 'Tourist Attractions',
      hierarchyTitle: 'Hierarchical Directory',
      moulvibazarUpazilasTitle: '7 Official Upazilas of Moulvibazar District',
      featuredBadge: 'Featured',
      explorePosts: 'Find Posts',
      tagInPost: 'Use Location',
      noAttractionsMatch: 'No tourist attractions match your current search or filter.',
      noLocationsMatch: 'No locations match your current filter.',
      clearFilters: 'Clear Filters',
      selectDivision: 'Select Division',
      selectDistrict: 'Select District',
      selectUpazila: 'Select Upazila',
      selectUnion: 'Select Union (Optional)',
      selectVillage: 'Select Village / Area (Optional)',
      categories: {
        waterfall: 'Waterfall',
        forest: 'National Park & Forest',
        lake: 'Lake',
        haor: 'Haor & Wetland',
        tea_garden: 'Tea Gardens',
        cultural: 'Cultural Heritage',
        river: 'River & Barrage',
        heritage: 'Heritage Site',
      },
    },
    settings: {
      language: 'Language',
      theme: 'Appearance',
      lightMode: 'Light',
      darkMode: 'Dark',
    },
  },
  bn: {
    appName: 'Sylhet Social',
    tagline: 'চা-বাগান, সুরমা পাড় ও সিলেটের মানুষের আধুনিক সামাজিক যোগাযোগ মাধ্যম।',
    nav: {
      feed: 'ফিড',
      explore: 'অবস্থান ও পর্যটন',
      advertise: 'বিজ্ঞাপন দিন',
      friends: 'বন্ধু',
      search: 'খুঁজুন',
      messages: 'বার্তা',
      notifications: 'বিজ্ঞপ্তি',
      profile: 'প্রোফাইল',
      saved: 'সংরক্ষিত',
      admin: 'অ্যাডমিন',
    },
    actions: {
      createPost: 'পোস্ট করুন',
      post: 'প্রকাশ করুন',
      like: 'লাইক',
      liked: 'লাইকড',
      comment: 'মন্তব্য',
      share: 'শেয়ার',
      shared: 'শেয়ার করা হয়েছে',
      save: 'সংরক্ষণ',
      saved: 'সংরক্ষিত',
      send: 'পাঠান',
      cancel: 'বাতিল',
      editProfile: 'প্রোফাইল সম্পাদনা',
      saveChanges: 'পরিবর্তন সংরক্ষণ',
      signIn: 'সাইন ইন',
      signInWithGoogle: 'গুগল দিয়ে প্রবেশ করুন',
      register: 'নিবন্ধন করুন',
      createAccount: 'নতুন অ্যাকাউন্ট তৈরি',
      signOut: 'সাইন আউট',
      switchAccount: 'অ্যাকাউন্ট পরিবর্তন',
      addFriend: 'বন্ধু যোগ করুন',
      requested: 'অনুরোধ পাঠানো হয়েছে',
      accept: 'গ্রহণ করুন',
      decline: 'প্রত্যাখ্যান',
      friendsLabel: 'বন্ধু',
      unfriend: 'বন্ধু তালিকা থেকে সরান',
      follow: 'অনুসরণ করুন',
      following: 'অনুসরণ করছেন',
      message: 'বার্তা পাঠান',
      viewProfile: 'প্রোফাইল দেখুন',
      markAllRead: 'সব পড়া হয়েছে',
      uploadPhoto: 'ছবি আপলোড',
      uploadVideo: 'ভিডিও আপলোড',
      removeMedia: 'সরান',
      copyLink: 'লিংক কপি করুন',
      linkCopied: 'পোস্ট লিংক কপি হয়েছে',
      repostToFeed: 'আপনার ফিডে শেয়ার করুন',
      back: 'ফিরে যান',
      reportPost: 'রিপোর্ট',
      submitReport: 'রিপোর্ট পাঠান',
      deletePost: 'মুছে ফেলুন',
    },
    feed: {
      allPosts: 'সব পোস্ট',
      photos: 'ছবি',
      videos: 'ভিডিও',
      friendsOnly: 'বন্ধুদের পোস্ট',
      whatsOnMind: 'সিলেটের কোনো গল্প বা অনুভূতি শেয়ার করুন...',
      addPhoto: 'ছবি',
      addVideo: 'ভিডিও',
      textCard: 'রঙিন পোস্ট',
      locationLabel: 'স্থান',
      selectLocation: 'সিলেটের স্থান যোগ করুন',
      writeComment: 'মন্তব্য লিখুন...',
      noCommentsYet: 'প্রথম মন্তব্যটি আপনি করুন।',
      noPostsFound: 'এখনো কোনো পোস্ট নেই। সিলেটের প্রথম গল্পটি শেয়ার করুন!',
      likesCount: 'লাইক',
      commentsCount: 'মন্তব্য',
      sharesCount: 'শেয়ার',
      sharedAPost: 'একটি পোস্ট শেয়ার করেছেন',
      sylhetPulse: 'সিলেট কমিউনিটি বার্তা',
      peopleYouMayKnow: 'সিলেটের পরিচিত মুখ',
      quickContacts: 'যোগাযোগ',
      teaGardenBanner: 'রাতারগুল, জাফলং ও সুরমা নদীর আজকের গল্প দেখুন',
      pendingReviewBadge: 'অ্যাডমিন অনুমোদনের অপেক্ষায়',
      maintenanceNotice: 'Sylhet Social বর্তমানে রক্ষণাবেক্ষণ মোডে রয়েছে। সাময়িকভাবে শুধুমাত্র অ্যাডমিনরা পোস্ট করতে পারবেন।',
      suspendedNotice: 'আপনার অ্যাকাউন্টটি সাময়িকভাবে স্থগিত করা হয়েছে। অনুগ্রহ করে অ্যাডমিনের সাথে যোগাযোগ করুন।',
    },
    profile: {
      posts: 'পোস্টসমূহ',
      photos: 'ছবিসমূহ',
      friends: 'বন্ধু',
      followers: 'অনুসারী',
      following: 'অনুসরণ',
      about: 'পরিচিতি',
      livesIn: 'বসবাস',
      worksOrStudies: 'কর্মস্থল / শিক্ষাপ্রতিষ্ঠান',
      joined: 'যোগদান',
      changeAvatar: 'প্রোফাইল ছবি পরিবর্তন',
      changeCover: 'কভার ছবি পরিবর্তন',
      fullName: 'পুরো নাম',
      bio: 'পরিচিতি (Bio)',
      neighborhood: 'সিলেটের এলাকা',
      workStudy: 'পেশা বা বিশ্ববিদ্যালয়',
      noPhotosYet: 'এখনো কোনো ছবি শেয়ার করা হয়নি।',
      noPostsYet: 'এখনো কোনো পোস্ট নেই।',
    },
    friendsPage: {
      allFriends: 'সকল বন্ধু',
      requests: 'বন্ধুত্বের অনুরোধ',
      followers: 'অনুসারী',
      following: 'অনুসরণ করছেন',
      discover: 'নতুন বন্ধু খুঁজুন',
      mutualFriends: 'পারস্পরিক বন্ধু',
      noRequests: 'এই মুহূর্তে কোনো নতুন বন্ধুত্বের অনুরোধ নেই।',
      noFriends: 'সিলেটের বন্ধুদের সাথে যুক্ত হয়ে আপনার তালিকা তৈরি করুন।',
    },
    searchPage: {
      placeholder: 'মানুষ, পোস্ট, রাতারগুল, শাবিপ্রবি খুঁজুন...',
      allResults: 'সব ফলাফল',
      people: 'মানুষ',
      posts: 'পোস্ট',
      popularTopics: 'সিলেটে জনপ্রিয়',
      noResults: 'কোনো মানুষ বা পোস্ট পাওয়া যায়নি।',
      searchPrompt: 'নাম, এলাকা অথবা পোস্টের বিষয় লিখে খুঁজুন।',
    },
    notificationsPage: {
      title: 'বিজ্ঞপ্তি',
      unread: 'অপঠিত',
      allCaughtUp: 'সব বিজ্ঞপ্তি দেখা হয়ে গেছে।',
      likedYourPost: 'আপনার পোস্টে লাইক দিয়েছেন',
      commentedOnPost: 'আপনার পোস্টে মন্তব্য করেছেন',
      sharedYourPost: 'আপনার পোস্ট শেয়ার করেছেন',
      sentFriendRequest: 'আপনাকে বন্ধুত্বের অনুরোধ পাঠিয়েছেন',
      acceptedFriendRequest: 'আপনার বন্ধুত্বের অনুরোধ গ্রহণ করেছেন',
      startedFollowing: 'আপনাকে অনুসরণ করা শুরু করেছেন',
      adminBroadcast: 'Sylhet Social ঘোষণা',
      moderationAlert: 'আপনার পোস্টের মডারেশন আপডেট',
    },
    messagesPage: {
      title: 'ব্যক্তিগত বার্তা',
      searchChats: 'আলাপচারিতা খুঁজুন...',
      typeMessage: 'বার্তা লিখুন...',
      startChat: 'কথোপকথন শুরু করুন',
      activeNow: 'সক্রিয় আছেন',
      offline: 'অফলাইন',
      typing: 'লিখছেন...',
      sylhetMember: 'সিলেট কমিউনিটি',
      selectConversation: 'বার্তা বিনিময় শুরু করতে তালিকা থেকে একজন সদস্য নির্বাচন করুন।',
      newChat: 'নতুন বার্তা',
      sent: 'পাঠানো হয়েছে',
      delivered: 'পৌঁছেছে',
      seen: 'দেখা হয়েছে',
      sendImage: 'ছবি পাঠান',
      sendVideo: 'ভিডিও পাঠান',
      recordVoice: 'ভয়েস বার্তা রেকর্ড করুন',
      stopVoice: 'ভয়েস পাঠান',
      cancelVoice: 'বাতিল',
      recording: 'রেকর্ড হচ্ছে',
      voiceMessage: 'ভয়েস বার্তা',
      photoLabel: 'ছবি',
      videoLabel: 'ভিডিও',
      uploadingMedia: 'মিডিয়া আপলোড হচ্ছে...',
      uploadFailed: 'মিডিয়া আপলোড ব্যর্থ হয়েছে। স্টোরেজ অনুমতি পরীক্ষা করে আবার চেষ্টা করুন।',
      micDenied: 'মাইক্রোফোনের অনুমতি পাওয়া যায়নি।',
      fileTooLarge: 'ফাইলটি নির্ধারিত সর্বোচ্চ সাইজের চেয়ে বড়।',
      blockUser: 'ব্লক করুন',
      unblockUser: 'আনব্লক করুন',
      reportUser: 'ব্যবহারকারী রিপোর্ট করুন',
      blockedByYouBanner: 'আপনি এই ব্যবহারকারীকে ব্লক করেছেন। বার্তা পাঠাতে আনব্লক করুন।',
      blockedByOtherBanner: 'এই ব্যবহারকারীর সাথে বার্তা বিনিময় করা সম্ভব নয়।',
      userBlockedToast: 'ব্যবহারকারীকে ব্লক করা হয়েছে',
      userUnblockedToast: 'ব্যবহারকারীকে আনব্লক করা হয়েছে',
      offlineBanner: 'আপনি বর্তমানে অফলাইনে আছেন। ইন্টারনেট সংযোগ ফিরলে বার্তা সিঙ্ক হবে।',
      loadingMessages: 'বার্তা লোড হচ্ছে...',
      enableBrowserAlerts: 'চ্যাট নোটিফিকেশন চালু করুন',
      browserAlertsEnabled: 'চ্যাট অ্যালার্ট চালু',
      newMessageFrom: 'নতুন বার্তা পাঠিয়েছেন',
      youPrefix: 'আপনি:',
      viewFullImage: 'সম্পূর্ণ ছবি দেখুন',
    },
    auth: {
      welcomeTitle: 'Sylhet Social-এ স্বাগতম',
      welcomeSubtitle: 'সুরমা নদী, চা-বাগান, ক্যাম্পাস এবং সিলেটের প্রতিটি পাড়া-মহল্লার গল্প সবার সাথে ভাগাভাগি করুন।',
      googleSignInTitle: 'Sylhet Social-এ সাইন ইন করুন',
      googleSignInHint: 'বন্ধুদের সাথে যুক্ত হতে এবং ছবি ও ভিডিও শেয়ার করতে আপনার গুগল অ্যাকাউন্ট দিয়ে প্রবেশ করুন।',
      registrationsPaused: 'নতুন সদস্য নিবন্ধন সাময়িকভাবে অ্যাডমিন দ্বারা বন্ধ রাখা হয়েছে।',
      authError: 'সাইন ইন সম্পন্ন করা যায়নি। পপআপ অনুমতি দিয়ে আবার চেষ্টা করুন।',
      completeProfileTitle: 'আপনার সিলেট প্রোফাইল সাজান',
    },
    reportModal: {
      title: 'রিপোর্ট করুন',
      reasonLabel: 'পোস্টটি রিপোর্ট করার কারণ কী?',
      detailsLabel: 'বিস্তারিত তথ্য (ঐচ্ছিক)',
      detailsPlaceholder: 'মডারেশন টিমের জন্য সংক্ষিপ্ত বিবরণ লিখুন...',
      submitted: 'আপনার রিপোর্ট Sylhet Social মডারেটরদের কাছে পাঠানো হয়েছে।',
      reasons: {
        spam: 'স্প্যাম বা বিভ্রান্তিকর প্রচারণা',
        harassment: 'হয়রানি বা অশালীন ভাষা',
        misinformation: 'ভুল তথ্য',
        inappropriate: 'অনুপযুক্ত ছবি বা বিষয়বস্তু',
        other: 'অন্যান্য নীতিমালা লঙ্ঘন',
      },
    },
    admin: {
      title: 'অ্যাডমিন কনসোল',
      subtitle: 'Sylhet Social-এর ভূমিকা-ভিত্তিক মডারেশন, ব্যবহারকারী ব্যবস্থাপনা, অ্যানালিটিক্স ও সেটিংস।',
      verifyTitle: 'অ্যাডমিন পরিচয় যাচাই করুন',
      verifyDesc: 'নিরাপত্তার জন্য, অ্যাডমিন কন্ট্রোল আনলক করতে আপনার অনুমোদিত গুগল সেশন পুনরায় যাচাই করুন।',
      verifyButton: 'গুগল দিয়ে যাচাই করুন',
      lockConsole: 'কনসোল লক করুন',
      backToApp: 'ফিডে ফিরে যান',
      tabs: {
        analytics: 'অ্যানালিটিক্স',
        users: 'ব্যবহারকারী',
        posts: 'পোস্ট মডারেশন',
        media: 'ছবি ও ভিডিও',
        reports: 'রিপোর্টসমূহ',
        notifications: 'ঘোষণা ও বার্তা',
        settings: 'অ্যাপ সেটিংস',
      },
      metrics: {
        totalUsers: 'মোট সদস্য',
        totalPosts: 'মোট পোস্ট',
        pendingReports: 'অপেক্ষমান রিপোর্ট',
        totalEngagement: 'মোট এনগেজমেন্ট',
        mediaDistribution: 'মিডিয়া বিভাজন',
        moderationStatus: 'মডারেশন অবস্থা',
        recentAudit: 'সাম্প্রতিক অ্যাডমিন অডিট লগ',
      },
      users: {
        searchPlaceholder: 'নাম, ইউজারনেম বা এলাকা দিয়ে খুঁজুন...',
        roleLabel: 'ভূমিকা',
        statusLabel: 'অবস্থা',
        active: 'সক্রিয়',
        suspended: 'স্থগিত',
        suspend: 'স্থগিত করুন',
        activate: 'সক্রিয় করুন',
        makeAdmin: 'অ্যাডমিন করুন',
        makeModerator: 'মডারেটর করুন',
        makeUser: 'সাধারণ সদস্য',
      },
      posts: {
        all: 'সব',
        approved: 'অনুমোদিত',
        pending: 'অপেক্ষমান',
        hidden: 'লুকানো',
        approve: 'অনুমোদন করুন',
        hide: 'লুকান',
        delete: 'মুছে ফেলুন',
        notePlaceholder: 'মডারেশন নোট (ঐচ্ছিক)...',
      },
      media: {
        allMedia: 'সব মিডিয়া',
        photosOnly: 'ছবি',
        videosOnly: 'ভিডিও',
        noMedia: 'এখনো কোনো ছবি বা ভিডিও পোস্ট করা হয়নি।',
      },
      reports: {
        all: 'সব',
        pending: 'অপেক্ষমান',
        resolved: 'সমাধানকৃত',
        dismissed: 'বাতিলকৃত',
        resolveHide: 'পোস্ট লুকিয়ে সমাধান করুন',
        resolveKeep: 'পোস্ট রেখে সমাধান করুন',
        dismiss: 'বাতিল করুন',
        noReports: 'কোনো রিপোর্ট পাওয়া যায়নি।',
      },
      broadcast: {
        titleLabel: 'ঘোষণার শিরোনাম',
        messageLabel: 'বিজ্ঞপ্তির বার্তা',
        sendBroadcast: 'সকল সদস্যকে পাঠান',
        sentSuccess: 'সকল সদস্যের কাছে বিজ্ঞপ্তি পাঠানো হয়েছে।',
        recentBroadcasts: 'প্রেরিত ঘোষণা ও বিজ্ঞপ্তি',
      },
      settings: {
        siteName: 'প্ল্যাটফর্মের নাম',
        maintenanceMode: 'রক্ষণাবেক্ষণ মোড',
        maintenanceDesc: 'অ্যাডমিন আপডেটের সময় সাধারণ সদস্যদের পোস্ট সাময়িকভাবে বন্ধ রাখুন।',
        allowRegistrations: 'নতুন সদস্য নিবন্ধন চালু',
        allowRegistrationsDesc: 'নতুন গুগল ব্যবহারকারীদের প্রোফাইল তৈরির অনুমতি দিন।',
        requirePostReview: 'পোস্ট প্রকাশের আগে অনুমোদন প্রয়োজন',
        requirePostReviewDesc: 'নতুন পোস্ট প্রকাশের আগে অ্যাডমিন রিভিউতে যাবে।',
        maxUploadMb: 'সর্বোচ্চ মিডিয়া সাইজ (MB)',
        bannerEn: 'ফিচার্ড কমিউনিটি ব্যানার (ইংরেজি)',
        bannerBn: 'ফিচার্ড কমিউনিটি ব্যানার (বাংলা)',
        saveSettings: 'অ্যাপ সেটিংস সংরক্ষণ করুন',
        seedStarterPosts: 'সিলেট স্টার্টার পোস্ট প্রকাশ করুন',
      },
      locations: {
        tabLabel: 'অবস্থান ও পর্যটন কেন্দ্র',
        locationsSubtab: 'স্তরভিত্তিক অবস্থান',
        attractionsSubtab: 'পর্যটন আকর্ষণসমূহ',
        seedDefaults: 'মৌলভীবাজারের তথ্য সিঙ্ক করুন',
        addLocation: 'নতুন অবস্থান যোগ করুন',
        editLocation: 'অবস্থান সম্পাদনা করুন',
        addAttraction: 'নতুন পর্যটন কেন্দ্র যোগ',
        editAttraction: 'পর্যটন কেন্দ্র সম্পাদনা',
        levelLabel: 'স্তর (Level)',
        parentLabel: 'মূল প্রশাসনিক এলাকা',
        nameEnLabel: 'নাম (ইংরেজি)',
        nameBnLabel: 'নাম (বাংলা)',
        activeLabel: 'সক্রিয় ও দৃশ্যমান',
        featuredLabel: 'বিশেষ আকর্ষণ',
        categoryLabel: 'ধরন',
        locationSummaryEn: 'অবস্থানের সংক্ষিপ্ত ঠিকানা (ইংরেজি)',
        locationSummaryBn: 'অবস্থানের সংক্ষিপ্ত ঠিকানা (বাংলা)',
        descEn: 'বিবরণ (ইংরেজি)',
        descBn: 'বিবরণ (বাংলা)',
        saveItem: 'সংরক্ষণ করুন',
        deleteConfirm: 'মুছুন',
        seededToast: 'মৌলভীবাজারের অবস্থান ও পর্যটন কেন্দ্রসমূহ ডাটাবেসে সংরক্ষিত হয়েছে',
        savedToast: 'ডিরেক্টরিতে সংরক্ষিত হয়েছে',
        deletedToast: 'ডিরেক্টরি থেকে মুছে ফেলা হয়েছে',
      },
      monetization: {
        tabLabel: 'বিজ্ঞাপন ও মনিটাইজেশন',
        subtabs: {
          adsQueue: 'বিজ্ঞাপন ও পেমেন্ট যাচাই',
          packages: 'প্যাকেজ মূল্য ও মেয়াদ',
          admobSettings: 'AdMob ও প্লেসমেন্ট',
        },
        confirmedRevenueBdt: 'নিশ্চিতকৃত আয় (Paid)',
        pendingRevenueBdt: 'অপেক্ষমান / যাচাই বাকি',
        activeAdsCount: 'সক্রিয় পেইড বিজ্ঞাপন',
        pendingReviewCount: 'রিভিউ / যাচাই বাকি',
        totalImpressions: 'মোট বিজ্ঞাপন ভিউ',
        totalClicks: 'মোট ক্লিক',
        exportCsv: 'আয় রিপোর্ট (CSV) ডাউনলোড',
        seedDefaults: 'ডিফল্ট প্যাকেজ ও সেটিংস সিঙ্ক',
        filterAll: 'সকল বিজ্ঞাপন',
        approveAndPublish: 'অনুমোদন ও প্রকাশ',
        pauseAd: 'বিরতি দিন',
        rejectAd: 'প্রত্যাখ্যান',
        confirmManualPayment: 'পেমেন্ট নিশ্চিত করুন',
        markRefunded: 'রিফান্ড চিহ্নিত করুন',
        markUnpaid: 'অপরিশোধিত করুন',
        paymentMethodLabel: 'পেমেন্ট মাধ্যম',
        adminNotePlaceholder: 'রিভিউ বা পেমেন্ট যাচাইয়ের নোট...',
        noAdsFound: 'এখনো কোনো স্থানীয় ব্যবসার বিজ্ঞাপন জমা পড়েনি।',
        addPackage: 'নতুন প্যাকেজ যোগ করুন',
        editPackage: 'প্যাকেজ সম্পাদনা',
        packageNameEn: 'প্যাকেজের নাম (ইংরেজি)',
        packageNameBn: 'প্যাকেজের নাম (বাংলা)',
        packageDescEn: 'বিবরণ (ইংরেজি)',
        packageDescBn: 'বিবরণ (বাংলা)',
        durationDays: 'মেয়াদ (দিন)',
        priceBdt: 'মূল্য (টাকা ৳)',
        placementLabel: 'প্রদর্শনের স্থান',
        savePackage: 'প্যাকেজ সংরক্ষণ করুন',
        admobArchitectureTitle: 'অ্যান্ড্রয়েড গুগল AdMob ইন্টিগ্রেশন আর্কিটেকচার',
        admobArchitectureDesc: 'ডেভেলপমেন্ট অবস্থায় শুধুমাত্র গুগলের অফিসিয়াল টেস্ট ইউনিট আইডি ব্যবহৃত হচ্ছে। প্রোডাকশন আইডিগুলো প্লেসহোল্ডার হিসেবে সংরক্ষিত।',
        admobEnvLabel: 'AdMob রানটাইম মোড',
        devTestMode: 'শুধুমাত্র ডেভেলপমেন্ট টেস্ট ইউনিট (নিরাপদ লক)',
        prodReadyMode: 'প্রোডাকশন প্লেসহোল্ডার চেক (প্লেসহোল্ডার থাকলে টেস্ট আইডি চলবে)',
        testIdsNotice: 'প্রোডাকশন কনস্ট্যান্টে REPLACE_WITH_PRODUCTION_ থাকলে স্বয়ংক্রিয়ভাবে গুগল টেস্ট আইডি ব্যবহৃত হয়।',
        bannerToggle: 'AdMob টেস্ট ব্যানার প্রিভিউ স্লট চালু',
        nativeToggle: 'AdMob টেস্ট নেটিভ কার্ড স্লট চালু',
        localAdsToggle: 'ফিড ও সাইডবারে অনুমোদিত পেইড বিজ্ঞাপন দেখান',
        requireConsentToggle: 'বিজ্ঞাপন গোপনীয়তা সম্মতি (Consent) চালু রাখুন',
        feedIntervalLabel: 'প্রতি কতটি সাধারণ পোস্টের পর স্পন্সরড কার্ড দেখাবে',
        paymentInstructionsEn: 'ম্যানুয়াল পেমেন্ট নির্দেশনা (ইংরেজি)',
        paymentInstructionsBn: 'ম্যানুয়াল পেমেন্ট নির্দেশনা (বাংলা)',
        saveConfig: 'মনিটাইজেশন সেটিংস সংরক্ষণ করুন',
        configSavedToast: 'মনিটাইজেশন ও AdMob কনফিগারেশন সংরক্ষিত হয়েছে',
        paymentConfirmedToast: 'ম্যানুয়াল পেমেন্টের অবস্থা হালনাগাদ ও লগ করা হয়েছে',
        statusUpdatedToast: 'বিজ্ঞাপনের অবস্থা হালনাগাদ হয়েছে',
      },
    },
    ads: {
      portalTitle: 'সিলেট বিভাগ স্থানীয় ব্যবসা বিজ্ঞাপন',
      portalSubtitle: 'সিলেট, মৌলভীবাজার, সুনামগঞ্জ ও হবিগঞ্জে আপনার রেস্তোরাঁ, টি রিসোর্ট, দোকান বা স্থানীয় সেবা প্রচার করুন।',
      packagesTitle: 'নির্ধারিত মেয়াদ ও মূল্য প্যাকেজ',
      submitTab: 'নতুন বিজ্ঞাপন দিন',
      myAdsTab: 'আমার বিজ্ঞাপন ও পেমেন্ট অবস্থা',
      businessName: 'প্রতিষ্ঠানের নাম',
      categoryLabel: 'ব্যবসার ধরন',
      titleEn: 'বিজ্ঞাপনের শিরোনাম (ইংরেজি)',
      titleBn: 'বিজ্ঞাপনের শিরোনাম (বাংলা - ঐচ্ছিক)',
      descEn: 'অফার ও বিস্তারিত (ইংরেজি)',
      descBn: 'অফার ও বিস্তারিত (বাংলা - ঐচ্ছিক)',
      imageLabel: 'বিজ্ঞাপনের ছবি (ঐচ্ছিক)',
      uploadBanner: 'ব্যবসার ছবি আপলোড করুন',
      useSamplePhoto: 'সিলেট প্রিসেট ছবি ব্যবহার করুন',
      phoneLabel: 'যোগাযোগের ফোন নম্বর',
      whatsappLabel: 'হোয়াটসঅ্যাপ নম্বর (ঐচ্ছিক)',
      emailLabel: 'ব্যবসায়িক ইমেইল (ঐচ্ছিক)',
      websiteLabel: 'ওয়েবসাইট বা পেজ লিংক (ঐচ্ছিক)',
      ctaLabel: 'অ্যাকশন বাটন',
      locationTitle: 'ব্যবসার এলাকা (সিলেট বিভাগ)',
      packageLabel: 'প্যাকেজ নির্বাচন করুন',
      daysUnit: 'দিন',
      manualPaymentNoticeTitle: 'অ্যাডমিন রিভিউ ও ম্যানুয়াল পেমেন্ট যাচাই আবশ্যক',
      submitAdBtn: 'রিভিউয়ের জন্য জমা দিন (স্বয়ংক্রিয় চার্জ নেই)',
      submittedToast: 'বিজ্ঞাপনটি অ্যাডমিন রিভিউতে পাঠানো হয়েছে। এবার ম্যানুয়াল পেমেন্ট রেফারেন্স দিন।',
      noMyAds: 'আপনি এখনো কোনো স্থানীয় ব্যবসার বিজ্ঞাপন জমা দেননি।',
      submitPaymentProofTitle: 'ম্যানুয়াল পেমেন্ট রেফারেন্স জমা দিন',
      trxPlaceholder: 'বিকাশ/নগদ TrxID বা ব্যাংক রেফারেন্স লিখুন...',
      submitProofBtn: 'যাচাইয়ের জন্য রেফারেন্স পাঠান',
      proofSubmittedToast: 'পেমেন্ট রেফারেন্স পাঠানো হয়েছে। অ্যাডমিনের ম্যানুয়াল নিশ্চিতকরণের অপেক্ষায়।',
      pauseMyAd: 'প্রচারণা বিরতি দিন',
      deleteUnpaidAd: 'অপরিশোধিত বিজ্ঞাপন মুছুন',
      reviewStatusLabel: 'রিভিউ অবস্থা',
      paymentStatusLabel: 'পেমেন্ট অবস্থা',
      scheduleLabel: 'প্রচারের মেয়াদ',
      performanceLabel: 'পারফরম্যান্স',
      impressions: 'ভিউ',
      clicks: 'ক্লিক',
      statuses: {
        pending_review: 'রিভিউ অপেক্ষমান',
        approved: 'অনুমোদিত',
        paused: 'বিরতিতে',
        rejected: 'প্রত্যাখ্যাত',
        expired: 'মেয়াদ শেষ',
      },
      paymentStatuses: {
        unpaid: 'অপরিশোধিত (চার্জ হয়নি)',
        pending_verification: 'পেমেন্ট যাচাই অপেক্ষমান',
        paid: 'ম্যানুয়ালি নিশ্চিত পেইড',
        refunded: 'রিফান্ডকৃত',
      },
      paymentMethods: {
        manual_bkash: 'ম্যানুয়াল বিকাশ',
        manual_nagad: 'ম্যানুয়াল নগদ',
        bank_transfer: 'ব্যাংক ট্রান্সফার',
        cash_office: 'সরাসরি ক্যাশ',
        none: 'নির্বাচিত নয়',
      },
      placements: {
        feed: 'নিউজ ফিড',
        sidebar: 'ডেস্কটপ সাইডবার',
        both: 'নিউজ ফিড ও সাইডবার',
      },
      ctas: {
        call_now: 'কল করুন',
        whatsapp: 'হোয়াটসঅ্যাপে বার্তা',
        visit_website: 'ওয়েবসাইট দেখুন',
        learn_more: 'যোগাযোগের তথ্য',
      },
      categories: {
        restaurant: 'রেস্তোরাঁ ও খাবার',
        hotel_resort: 'হোটেল ও টি রিসোর্ট',
        retail: 'দোকান ও শপিং',
        education: 'শিক্ষা ও কোচিং',
        healthcare: 'স্বাস্থ্যসেবা ও ক্লিনিক',
        tech_services: 'প্রযুক্তি ও স্থানীয় সেবা',
        tourism: 'ভ্রমণ ও ট্যুরিজম',
        real_estate: 'আবাসন ও প্রপার্টি',
        other: 'স্থানীয় প্রতিষ্ঠান',
      },
    },
    sponsoredCard: {
      sponsored: 'স্পন্সরড',
      paidAd: 'পেইড বিজ্ঞাপন',
      whyThisAd: 'এই বিজ্ঞাপন কেন?',
      hideAd: 'বিজ্ঞাপন লুকান',
      promoteBusiness: 'এখানে বিজ্ঞাপন দিন',
      adHiddenToast: 'এই সেশনের জন্য বিজ্ঞাপনটি লুকানো হয়েছে',
      admobTestLabel: 'গুগল AdMob · টেস্ট বিজ্ঞাপন ইউনিট',
      admobTestBannerTitle: 'অ্যান্ড্রয়েড AdMob টেস্ট স্লট (শুধুমাত্র ডেভেলপমেন্ট)',
      admobTestBannerSubtitle: 'সাধারণ পোস্ট থেকে সম্পূর্ণ আলাদা করে গুগল অফিসিয়াল টেস্ট ইউনিট ব্যবহার করে। কোনো প্রকৃত চার্জ বা আয় হয় না।',
      admobTestNativeTitle: 'গুগল AdMob টেস্ট নেটিভ বিজ্ঞাপন স্লট',
      admobAndroidBridgeReady: 'অ্যান্ড্রয়েড ব্রিজ প্রস্তুত',
      admobWebPreviewMode: 'ওয়েব টেস্ট প্রিভিউ',
    },
    consent: {
      bannerTitle: 'বিজ্ঞাপন গোপনীয়তা ও সম্মতি পছন্দ',
      bannerBody: 'Sylhet Social সাধারণ পোস্ট থেকে স্পন্সরড বিজ্ঞাপন এবং ভবিষ্যতের অ্যান্ড্রয়েড AdMob টেস্ট স্লট সম্পূর্ণ আলাদা রাখে। আপনার পছন্দ নির্ধারণ করুন।',
      acceptPersonalized: 'প্রাসঙ্গিক স্থানীয় বিজ্ঞাপন চালু',
      useNonPersonalized: 'শুধু সাধারণ বিজ্ঞাপন (Non-Personalized)',
      essentialOnly: 'শুধু আবশ্যকীয় (AdMob টেস্ট স্লট বন্ধ)',
      privacyLink: 'বিজ্ঞাপন গোপনীয়তা ও নীতিমালা',
      modalTitle: 'বিজ্ঞাপন গোপনীয়তা, সম্মতি ও গুগল নীতিমালা',
      modalSubtitle: 'Google AdMob UMP এবং স্থানীয় বিজ্ঞাপন নীতিমালার সাথে সামঞ্জস্যপূর্ণ স্বচ্ছ নিয়ন্ত্রণ।',
      currentChoiceLabel: 'আপনার বর্তমান সম্মতি',
      googleAdmobPolicyTitle: '১. গুগল AdMob ও অ্যান্ড্রয়েড অ্যাপ নীতিমালা',
      googleAdmobPolicyBody: 'ডেভেলপমেন্ট পর্যায়ে শুধুমাত্র গুগলের অফিসিয়াল টেস্ট ইউনিট আইডি (ca-app-pub-3940256099942544/*) ব্যবহৃত হয়। ব্যক্তিগতকৃত বিজ্ঞাপন বন্ধ করলে স্বয়ংক্রিয়ভাবে npa=1 পাঠানো হয়। স্পন্সরড কার্ড কখনোই সাধারণ পোস্ট বা লাইক/কমেন্টের ছদ্মবেশ ধারণ করে না।',
      localAdsPolicyTitle: '২. সিলেটের স্থানীয় বিজ্ঞাপন ও ব্যবহারকারীর নিয়ন্ত্রণ',
      localAdsPolicyBody: 'সিলেট বিভাগের অনুমোদিত ও পেমেন্ট নিশ্চিতকৃত ব্যবসাগুলোর প্রচারণা স্পষ্ট "স্পন্সরড" লেবেলসহ দেখানো হয়। আপনি যেকোনো সময় বিজ্ঞাপন লুকাতে বা গোপনীয়তা পছন্দ পরিবর্তন করতে পারবেন।',
      noAutoChargeTitle: '৩. ম্যানুয়াল যাচাই ও স্বচ্ছ পেমেন্ট',
      noAutoChargeBody: 'অ্যাপের ভেতর থেকে স্বয়ংক্রিয়ভাবে কোনো কার্ড বা মোবাইল ওয়ালেট থেকে টাকা কাটা হয় না। অ্যাডমিন ম্যানুয়ালি পেমেন্ট ও বিজ্ঞাপন যাচাই করে নিশ্চিত করার পরেই বিজ্ঞাপন প্রকাশিত হয়।',
      savedToast: 'বিজ্ঞাপন গোপনীয়তা পছন্দ সংরক্ষিত হয়েছে',
      choices: {
        unset: 'এখনো নির্বাচিত হয়নি',
        personalized: 'ব্যক্তিগতকৃত ও স্থানীয় বিজ্ঞাপন',
        non_personalized: 'সাধারণ বিজ্ঞাপন (npa=1)',
        essential_only: 'শুধু আবশ্যকীয় (AdMob টেস্ট বন্ধ)',
      },
    },
    locationsPage: {
      title: 'সিলেট ও মৌলভীবাজার ভ্রমণ নির্দেশিকা',
      subtitle: 'সিলেট বিভাগের জেলা, উপজেলা, ইউনিয়ন, গ্রাম এবং উল্লেখযোগ্য পর্যটন কেন্দ্রসমূহ খুঁজুন।',
      searchPlaceholder: 'জেলা, উপজেলা, ইউনিয়ন, গ্রাম বা পর্যটন কেন্দ্র খুঁজুন...',
      allDistricts: 'সকল জেলা',
      allUpazilas: 'সকল উপজেলা',
      allCategories: 'সকল ধরন',
      divisionLabel: 'বিভাগ',
      districtLabel: 'জেলা',
      upazilaLabel: 'উপজেলা',
      unionLabel: 'ইউনিয়ন',
      villageLabel: 'গ্রাম / এলাকা',
      attractionLabel: 'পর্যটন কেন্দ্র',
      attractionsTitle: 'পর্যটন আকর্ষণসমূহ',
      hierarchyTitle: 'স্তরভিত্তিক ডিরেক্টরি',
      moulvibazarUpazilasTitle: 'মৌলভীবাজার জেলার ৭টি সরকারি উপজেলা',
      featuredBadge: 'বিশেষ',
      explorePosts: 'পোস্ট খুঁজুন',
      tagInPost: 'অবস্থান ব্যবহার করুন',
      noAttractionsMatch: 'আপনার খোঁজা বা ফিল্টারের সাথে কোনো পর্যটন কেন্দ্র মেলেনি।',
      noLocationsMatch: 'এই ফিল্টারে কোনো অবস্থান পাওয়া যায়নি।',
      clearFilters: 'ফিল্টার মুছুন',
      selectDivision: 'বিভাগ নির্বাচন করুন',
      selectDistrict: 'জেলা নির্বাচন করুন',
      selectUpazila: 'উপজেলা নির্বাচন করুন',
      selectUnion: 'ইউনিয়ন নির্বাচন করুন (ঐচ্ছিক)',
      selectVillage: 'গ্রাম / এলাকা নির্বাচন করুন (ঐচ্ছিক)',
      categories: {
        waterfall: 'জলপ্রপাত',
        forest: 'জাতীয় উদ্যান ও বন',
        lake: 'লেক / হ্রদ',
        haor: 'হাওর ও জলাভূমি',
        tea_garden: 'চা-বাগান',
        cultural: 'সাংস্কৃতিক ঐতিহ্য',
        river: 'নদী ও ব্যারাজ',
        heritage: 'ঐতিহ্যবাহী স্থান',
      },
    },
    settings: {
      language: 'ভাষা',
      theme: 'থিম',
      lightMode: 'লাইট',
      darkMode: 'ডার্ক',
    },
  },
};

export const SYLHET_LOCATIONS = [
  { en: 'Zindabazar, Sylhet', bn: 'জিন্দাবাজার, সিলেট' },
  { en: 'Amberkhana, Sylhet', bn: 'আম্বরখানা, সিলেট' },
  { en: 'Malnicherra Tea Estate', bn: 'মালনিছড়া চা-বাগান' },
  { en: 'Ratargul Swamp Forest', bn: 'রাতারগুল জলারবন' },
  { en: 'Jaflong, Gowainghat', bn: 'জাফলং, গোয়াইনঘাট' },
  { en: 'Keane Bridge & Surma Bank', bn: 'ক্বিন ব্রিজ ও সুরমা পাড়' },
  { en: 'SUST Campus, Akhalia', bn: 'শাবিপ্রবি ক্যাম্পাস, আখালিয়া' },
  { en: 'Shibganj, Sylhet', bn: 'শিবগঞ্জ, সিলেট' },
  { en: 'Sreemangal, Moulvibazar', bn: 'শ্রীমঙ্গল, মৌলভীবাজার' },
];
