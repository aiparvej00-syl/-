import { AdPackage, MonetizationConfig } from '../types/social';

const BASE_ISO = '2026-01-01T00:00:00.000Z';

export const DEFAULT_AD_PACKAGES: AdPackage[] = [
  {
    id: 'pkg_starter_7d',
    name: 'Sylhet Starter (7 Days)',
    nameBn: 'সিলেট স্টার্টার (৭ দিন)',
    description: 'Clean Sponsored card inside the main Sylhet Social News Feed.',
    descriptionBn: 'Sylhet Social মূল নিউজ ফিডে স্পন্সরড কার্ড প্রদর্শন।',
    durationDays: 7,
    priceBdt: 500,
    placement: 'feed',
    isActive: true,
    sortOrder: 1,
    createdAt: BASE_ISO,
    updatedAt: BASE_ISO,
  },
  {
    id: 'pkg_district_14d',
    name: 'District Spotlight (14 Days)',
    nameBn: 'জেলা স্পটলাইট (১৪ দিন)',
    description: 'Featured placement in both News Feed and Desktop Community Rail.',
    descriptionBn: 'নিউজ ফিড এবং ডেস্কটপ কমিউনিটি সাইডবার উভয় স্থানে প্রচারণা।',
    durationDays: 14,
    priceBdt: 950,
    placement: 'both',
    isActive: true,
    sortOrder: 2,
    createdAt: BASE_ISO,
    updatedAt: BASE_ISO,
  },
  {
    id: 'pkg_division_30d',
    name: 'Sylhet Division Campaign (30 Days)',
    nameBn: 'সিলেট বিভাগীয় ক্যাম্পেইন (৩০ দিন)',
    description: 'Full-month local business visibility across Sylhet, Moulvibazar, Sunamganj & Habiganj.',
    descriptionBn: 'সিলেট, মৌলভীবাজার, সুনামগঞ্জ ও হবিগঞ্জ জুড়ে ৩০ দিনের পূর্ণ প্রচারণা।',
    durationDays: 30,
    priceBdt: 1800,
    placement: 'both',
    isActive: true,
    sortOrder: 3,
    createdAt: BASE_ISO,
    updatedAt: BASE_ISO,
  },
];

export const DEFAULT_MONETIZATION_CONFIG: MonetizationConfig = {
  admobEnvironment: 'development_test',
  admobBannerEnabled: true,
  admobNativeEnabled: true,
  localAdsEnabled: true,
  feedAdInterval: 4,
  requireAdConsent: true,
  manualPaymentInstructionsEn:
    'No automatic charge is made here. After submitting your ad, send the package fee via bKash/Nagad Merchant or Bank Transfer, submit your Transaction ID (TrxID), and wait for manual Admin verification.',
  manualPaymentInstructionsBn:
    'এখানে কোনো স্বয়ংক্রিয় চার্জ কাটা হয় না। বিজ্ঞাপন জমা দেওয়ার পর বিকাশ/নগদ বা ব্যাংক ট্রান্সফারের মাধ্যমে ফি পাঠিয়ে ট্রানজেকশন আইডি (TrxID) জমা দিন এবং অ্যাডমিনের ম্যানুয়াল যাচাইয়ের জন্য অপেক্ষা করুন।',
  updatedBy: 'system',
  updatedAt: BASE_ISO,
};
