import { ASSET_IMAGES } from './seedData';
import { LocationNode, TouristAttraction } from '../types/social';

const BASE_TIME = '2026-01-01T00:00:00.000Z';

function divNode(id: string, name: string, nameBn: string, sortOrder: number): LocationNode {
  return {
    id,
    level: 'division',
    name,
    nameBn,
    parentId: '',
    divisionId: id,
    districtId: '',
    upazilaId: '',
    unionId: '',
    isActive: true,
    sortOrder,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  };
}

function distNode(
  id: string,
  divisionId: string,
  name: string,
  nameBn: string,
  sortOrder: number
): LocationNode {
  return {
    id,
    level: 'district',
    name,
    nameBn,
    parentId: divisionId,
    divisionId,
    districtId: id,
    upazilaId: '',
    unionId: '',
    isActive: true,
    sortOrder,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  };
}

function upaNode(
  id: string,
  divisionId: string,
  districtId: string,
  name: string,
  nameBn: string,
  sortOrder: number
): LocationNode {
  return {
    id,
    level: 'upazila',
    name,
    nameBn,
    parentId: districtId,
    divisionId,
    districtId,
    upazilaId: id,
    unionId: '',
    isActive: true,
    sortOrder,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  };
}

function uniNode(
  id: string,
  divisionId: string,
  districtId: string,
  upazilaId: string,
  name: string,
  nameBn: string,
  sortOrder: number
): LocationNode {
  return {
    id,
    level: 'union',
    name,
    nameBn,
    parentId: upazilaId,
    divisionId,
    districtId,
    upazilaId,
    unionId: id,
    isActive: true,
    sortOrder,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  };
}

function vilNode(
  id: string,
  divisionId: string,
  districtId: string,
  upazilaId: string,
  unionId: string,
  name: string,
  nameBn: string,
  sortOrder: number
): LocationNode {
  return {
    id,
    level: 'village',
    name,
    nameBn,
    parentId: unionId,
    divisionId,
    districtId,
    upazilaId,
    unionId,
    isActive: true,
    sortOrder,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  };
}

export const DIV_SYLHET = 'div_sylhet';
export const DIST_MOULVIBAZAR = 'dist_moulvibazar';
export const DIST_SYLHET = 'dist_sylhet';

export const OFFICIAL_LOCATIONS: LocationNode[] = [
  // Division
  divNode(DIV_SYLHET, 'Sylhet Division', 'সিলেট বিভাগ', 1),

  // Districts
  distNode(DIST_MOULVIBAZAR, DIV_SYLHET, 'Moulvibazar', 'মৌলভীবাজার', 1),
  distNode(DIST_SYLHET, DIV_SYLHET, 'Sylhet', 'সিলেট', 2),

  // =========================================================================
  // ALL 7 OFFICIAL UPAZILAS OF MOULVIBAZAR DISTRICT
  // =========================================================================
  upaNode('upa_moulvibazar_sadar', DIV_SYLHET, DIST_MOULVIBAZAR, 'Moulvibazar Sadar', 'মৌলভীবাজার সদর', 1),
  upaNode('upa_kamalganj', DIV_SYLHET, DIST_MOULVIBAZAR, 'Kamalganj', 'কমলগঞ্জ', 2),
  upaNode('upa_kulaura', DIV_SYLHET, DIST_MOULVIBAZAR, 'Kulaura', 'কুলাউড়া', 3),
  upaNode('upa_sreemangal', DIV_SYLHET, DIST_MOULVIBAZAR, 'Sreemangal', 'শ্রীমঙ্গল', 4),
  upaNode('upa_barlekha', DIV_SYLHET, DIST_MOULVIBAZAR, 'Barlekha', 'বড়লেখা', 5),
  upaNode('upa_juri', DIV_SYLHET, DIST_MOULVIBAZAR, 'Juri', 'জুড়ী', 6),
  upaNode('upa_rajnagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'Rajnagar', 'রাজনগর', 7),

  // Sylhet District Upazilas (preserving existing locations cleanly)
  upaNode('upa_sylhet_sadar', DIV_SYLHET, DIST_SYLHET, 'Sylhet Sadar', 'সিলেট সদর', 8),
  upaNode('upa_gowainghat', DIV_SYLHET, DIST_SYLHET, 'Gowainghat', 'গোয়াইনঘাট', 9),

  // =========================================================================
  // UNIONS & VILLAGES: MOULVIBAZAR SADAR (12 official unions)
  // =========================================================================
  uniNode('uni_ms_khalilpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Khalilpur', 'খলিলপুর', 1),
  uniNode('uni_ms_monumukh', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Monumukh', 'মনুমুখ', 2),
  uniNode('uni_ms_kamolpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Kamolpur', 'কামালপুর', 3),
  uniNode('uni_ms_kagabala', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Kagabala', 'কাগাবলা', 4),
  uniNode('uni_ms_akhailkura', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Akhailkura', 'আখাইলকুড়া', 5),
  uniNode('uni_ms_ekatuna', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Ekatuna', 'একাটুনা', 6),
  uniNode('uni_ms_chandnighat', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Chandnighat', 'চাঁদনীঘাট', 7),
  uniNode('uni_ms_konokpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Konokpur', 'কনকপুর', 8),
  uniNode('uni_ms_amtail', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Amtail', 'আমতৈল', 9),
  uniNode('uni_ms_nazirabad', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Nazirabad', 'নাজিরাবাদ', 10),
  uniNode('uni_ms_mostofapur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Mostofapur', 'মোস্তফাপুর', 11),
  uniNode('uni_ms_giasnagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'Giasnagar', 'গিয়াসনগর', 12),

  vilNode('vil_ms_sherpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_khalilpur', 'Sherpur', 'শেরপুর', 1),
  vilNode('vil_ms_khalilpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_khalilpur', 'Khalilpur', 'খলিলপুর', 2),
  vilNode('vil_ms_monumukh', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_monumukh', 'Monumukh', 'মনুমুখ', 3),
  vilNode('vil_ms_kamolpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_kamolpur', 'Kamolpur', 'কামালপুর', 4),
  vilNode('vil_ms_kagabala', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_kagabala', 'Kagabala', 'কাগাবলা', 5),
  vilNode('vil_ms_akhailkura', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_akhailkura', 'Akhailkura', 'আখাইলকুড়া', 6),
  vilNode('vil_ms_ekatuna', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_ekatuna', 'Ekatuna', 'একাটুনা', 7),
  vilNode('vil_ms_chandnighat', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_chandnighat', 'Chandnighat', 'চাঁদনীঘাট', 8),
  vilNode('vil_ms_manu_barrage', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_chandnighat', 'Manu Barrage Point', 'মনু ব্যারাজ এলাকা', 9),
  vilNode('vil_ms_konokpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_konokpur', 'Konokpur', 'কনকপুর', 10),
  vilNode('vil_ms_amtail', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_amtail', 'Amtail', 'আমতৈল', 11),
  vilNode('vil_ms_nazirabad', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_nazirabad', 'Nazirabad', 'নাজিরাবাদ', 12),
  vilNode('vil_ms_mostofapur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_mostofapur', 'Mostofapur', 'মোস্তফাপুর', 13),
  vilNode('vil_ms_giasnagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_moulvibazar_sadar', 'uni_ms_giasnagar', 'Giasnagar', 'গিয়াসনগর', 14),

  // =========================================================================
  // UNIONS & VILLAGES: KAMALGANJ (9 official unions)
  // =========================================================================
  uniNode('uni_km_rahimpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'Rahimpur', 'রহিমপুর', 1),
  uniNode('uni_km_patanushar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'Patanushar', 'পতনঊষার', 2),
  uniNode('uni_km_munshibazar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'Munshibazar', 'মুন্সীবাজার', 3),
  uniNode('uni_km_shamshernagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'Shamshernagar', 'শমশেরনগর', 4),
  uniNode('uni_km_sadar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'Kamalganj Sadar', 'কমলগঞ্জ সদর', 5),
  uniNode('uni_km_alinagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'Alinagar', 'আলীনগর', 6),
  uniNode('uni_km_adampur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'Adampur', 'আদমপুর', 7),
  uniNode('uni_km_madhabpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'Madhabpur', 'মাধবপুর', 8),
  uniNode('uni_km_islampur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'Islampur', 'ইসলামপুর', 9),

  vilNode('vil_km_rahimpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_rahimpur', 'Rahimpur', 'রহিমপুর', 1),
  vilNode('vil_km_patanushar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_patanushar', 'Patanushar', 'পতনঊষার', 2),
  vilNode('vil_km_munshibazar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_munshibazar', 'Munshibazar', 'মুন্সীবাজার', 3),
  vilNode('vil_km_shamshernagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_shamshernagar', 'Shamshernagar', 'শমশেরনগর', 4),
  vilNode('vil_km_bhanugachh', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_sadar', 'Bhanugachh', 'ভানুগাছ', 5),
  vilNode('vil_km_lawachara', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_sadar', 'Lawachara', 'লাউয়াছড়া', 6),
  vilNode('vil_km_alinagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_alinagar', 'Alinagar', 'আলীনগর', 7),
  vilNode('vil_km_tetaigaon', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_adampur', 'Tetaigaon (Manipuri Para)', 'তেতইগাঁও (মণিপুরী পাড়া)', 8),
  vilNode('vil_km_adampur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_adampur', 'Adampur', 'আদমপুর', 9),
  vilNode('vil_km_madhabpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_madhabpur', 'Madhabpur', 'মাধবপুর', 10),
  vilNode('vil_km_patrakhola', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_madhabpur', 'Patrakhola', 'পাত্রখোলা', 11),
  vilNode('vil_km_islampur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_islampur', 'Islampur', 'ইসলামপুর', 12),
  vilNode('vil_km_kurma', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kamalganj', 'uni_km_islampur', 'Kurma (Hum Hum Trail)', 'কুরমা (হামহাম পথ)', 13),

  // =========================================================================
  // UNIONS & VILLAGES: KULAURA (13 official unions)
  // =========================================================================
  uniNode('uni_ku_baramchal', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Baramchal', 'বরমচাল', 1),
  uniNode('uni_ku_bhukshimail', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Bhukshimail', 'ভুকশিমইল', 2),
  uniNode('uni_ku_bhatera', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Bhatera', 'ভাটেরা', 3),
  uniNode('uni_ku_joychandi', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Joychandi', 'জয়চণ্ডী', 4),
  uniNode('uni_ku_brahmonbazar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Brahmonbazar', 'ব্রাহ্মণবাজার', 5),
  uniNode('uni_ku_kadirpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Kadirpur', 'কাদিরপুর', 6),
  uniNode('uni_ku_sadar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Kulaura Sadar', 'কুলাউড়া সদর', 7),
  uniNode('uni_ku_rauthgaon', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Rauthgaon', 'রাউৎগাঁও', 8),
  uniNode('uni_ku_tilagaon', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Tilagaon', 'টিলাগাঁও', 9),
  uniNode('uni_ku_hazipur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Hazipur', 'হাজীপুর', 10),
  uniNode('uni_ku_sharifpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Sharifpur', 'শরীফপুর', 11),
  uniNode('uni_ku_prithimpasha', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Prithimpasha', 'পৃথিমপাশা', 12),
  uniNode('uni_ku_karmadha', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'Karmadha', 'কর্মধা', 13),

  vilNode('vil_ku_baramchal', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_baramchal', 'Baramchal', 'বরমচাল', 1),
  vilNode('vil_ku_bhukshimail', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_bhukshimail', 'Bhukshimail (Hakaluki Haor)', 'ভুকশিমইল (হাকালুকি হাওর)', 2),
  vilNode('vil_ku_bhatera', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_bhatera', 'Bhatera', 'ভাটেরা', 3),
  vilNode('vil_ku_joychandi', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_joychandi', 'Joychandi', 'জয়চণ্ডী', 4),
  vilNode('vil_ku_brahmonbazar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_brahmonbazar', 'Brahmonbazar', 'ব্রাহ্মণবাজার', 5),
  vilNode('vil_ku_kadirpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_kadirpur', 'Kadirpur', 'কাদিরপুর', 6),
  vilNode('vil_ku_kulaura', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_sadar', 'Kulaura', 'কুলাউড়া', 7),
  vilNode('vil_ku_rauthgaon', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_rauthgaon', 'Rauthgaon', 'রাউৎগাঁও', 8),
  vilNode('vil_ku_tilagaon', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_tilagaon', 'Tilagaon', 'টিলাগাঁও', 9),
  vilNode('vil_ku_hazipur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_hazipur', 'Hazipur', 'হাজীপুর', 10),
  vilNode('vil_ku_sharifpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_sharifpur', 'Sharifpur', 'শরীফপুর', 11),
  vilNode('vil_ku_prithimpasha', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_prithimpasha', 'Prithimpasha', 'পৃথিমপাশা', 12),
  vilNode('vil_ku_karmadha', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_kulaura', 'uni_ku_karmadha', 'Karmadha', 'কর্মধা', 13),

  // =========================================================================
  // UNIONS & VILLAGES: SREEMANGAL (9 official unions)
  // =========================================================================
  uniNode('uni_sr_mirzapur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'Mirzapur', 'মির্জাপুর', 1),
  uniNode('uni_sr_bhunabir', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'Bhunabir', 'ভুনবীর', 2),
  uniNode('uni_sr_sadar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'Sreemangal Sadar', 'শ্রীমঙ্গল সদর', 3),
  uniNode('uni_sr_sindurkhan', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'Sindurkhan', 'সিন্দুরখান', 4),
  uniNode('uni_sr_kalapur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'Kalapur', 'কালাপুর', 5),
  uniNode('uni_sr_ashidron', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'Ashidron', 'আশিদ্রোন', 6),
  uniNode('uni_sr_rajghat', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'Rajghat', 'রাজঘাট', 7),
  uniNode('uni_sr_kalighat', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'Kalighat', 'কালীঘাট', 8),
  uniNode('uni_sr_satgaon', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'Satgaon', 'সাতগাঁও', 9),

  vilNode('vil_sr_mirzapur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'uni_sr_mirzapur', 'Mirzapur', 'মির্জাপুর', 1),
  vilNode('vil_sr_baikka_beel', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'uni_sr_bhunabir', 'Baikka Beel', 'বাইক্কা বিল', 2),
  vilNode('vil_sr_bhunabir', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'uni_sr_bhunabir', 'Bhunabir', 'ভুনবীর', 3),
  vilNode('vil_sr_ramnagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'uni_sr_sadar', 'Ramnagar', 'রামনগর', 4),
  vilNode('vil_sr_sindurkhan', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'uni_sr_sindurkhan', 'Sindurkhan', 'সিন্দুরখান', 5),
  vilNode('vil_sr_kalapur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'uni_sr_kalapur', 'Kalapur (Hail Haor)', 'কালাপুর (হাইল হাওর)', 6),
  vilNode('vil_sr_ashidron', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'uni_sr_ashidron', 'Ashidron', 'আশিদ্রোন', 7),
  vilNode('vil_sr_rajghat', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'uni_sr_rajghat', 'Rajghat', 'রাজঘাট', 8),
  vilNode('vil_sr_kalighat', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'uni_sr_kalighat', 'Kalighat (Tea Gardens)', 'কালীঘাট (চা-বাগান)', 9),
  vilNode('vil_sr_satgaon', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_sreemangal', 'uni_sr_satgaon', 'Satgaon', 'সাতগাঁও', 10),

  // =========================================================================
  // UNIONS & VILLAGES: BARLEKHA (10 official unions)
  // =========================================================================
  uniNode('uni_ba_barni', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'Barni', 'বর্ণি', 1),
  uniNode('uni_ba_dakhinbhag_uttar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'Dakhinbhag Uttar', 'দক্ষিণভাগ উত্তর', 2),
  uniNode('uni_ba_dakhinbhag_dakshin', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'Dakhinbhag Dakshin', 'দক্ষিণভাগ দক্ষিণ', 3),
  uniNode('uni_ba_nij_bahadurpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'Nij Bahadurpur', 'নিজ বাহাদুরপুর', 4),
  uniNode('uni_ba_uttar_shahbazpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'Uttar Shahbazpur', 'উত্তর শাহবাজপুর', 5),
  uniNode('uni_ba_dakshin_shahbazpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'Dakshin Shahbazpur', 'দক্ষিণ শাহবাজপুর', 6),
  uniNode('uni_ba_sadar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'Barlekha Sadar', 'বড়লেখা সদর', 7),
  uniNode('uni_ba_talimpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'Talimpur', 'তালিমপুর', 8),
  uniNode('uni_ba_dasherbazar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'Dasherbazar', 'দাসেরবাজার', 9),
  uniNode('uni_ba_sujanagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'Sujanagar', 'সুজানগর', 10),

  vilNode('vil_ba_barni', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'uni_ba_barni', 'Barni', 'বর্ণি', 1),
  vilNode('vil_ba_kathaltali', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'uni_ba_dakhinbhag_uttar', 'Kathaltali', 'কাঁঠালতলী', 2),
  vilNode('vil_ba_madhabkunda', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'uni_ba_dakhinbhag_dakshin', 'Madhabkunda', 'মাধবকুণ্ড', 3),
  vilNode('vil_ba_nij_bahadurpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'uni_ba_nij_bahadurpur', 'Nij Bahadurpur', 'নিজ বাহাদুরপুর', 4),
  vilNode('vil_ba_shahbazpur_n', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'uni_ba_uttar_shahbazpur', 'Shahbazpur', 'শাহবাজপুর', 5),
  vilNode('vil_ba_ghona', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'uni_ba_dakshin_shahbazpur', 'Ghona', 'ঘোনা', 6),
  vilNode('vil_ba_barlekha', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'uni_ba_sadar', 'Barlekha', 'বড়লেখা', 7),
  vilNode('vil_ba_talimpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'uni_ba_talimpur', 'Talimpur', 'তালিমপুর', 8),
  vilNode('vil_ba_dasherbazar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'uni_ba_dasherbazar', 'Dasherbazar', 'দাসেরবাজার', 9),
  vilNode('vil_ba_sujanagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_barlekha', 'uni_ba_sujanagar', 'Sujanagar', 'সুজানগর', 10),

  // =========================================================================
  // UNIONS & VILLAGES: JURI (6 official unions)
  // =========================================================================
  uniNode('uni_ju_purbo_juri', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'Purbo Juri', 'পূর্ব জুড়ী', 1),
  uniNode('uni_ju_paschim_juri', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'Paschim Juri', 'পশ্চিম জুড়ী', 2),
  uniNode('uni_ju_joyfornagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'Joyfornagar', 'জায়ফরনগর', 3),
  uniNode('uni_ju_goalbari', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'Goalbari', 'গোয়ালবাড়ী', 4),
  uniNode('uni_ju_sagornal', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'Sagornal', 'সাগরনাল', 5),
  uniNode('uni_ju_fultola', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'Fultola', 'ফুলতলা', 6),

  vilNode('vil_ju_purbo_juri', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'uni_ju_purbo_juri', 'Purbo Juri', 'পূর্ব জুড়ী', 1),
  vilNode('vil_ju_kaminiganj', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'uni_ju_paschim_juri', 'Kaminiganj', 'কামিনীগঞ্জ', 2),
  vilNode('vil_ju_joyfornagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'uni_ju_joyfornagar', 'Joyfornagar', 'জায়ফরনগর', 3),
  vilNode('vil_ju_lathitila', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'uni_ju_goalbari', 'Lathitila', 'লাঠিটিলা', 4),
  vilNode('vil_ju_sagornal', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'uni_ju_sagornal', 'Sagornal', 'সাগরনাল', 5),
  vilNode('vil_ju_fultola', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_juri', 'uni_ju_fultola', 'Fultola', 'ফুলতলা', 6),

  // =========================================================================
  // UNIONS & VILLAGES: RAJNAGAR (8 official unions)
  // =========================================================================
  uniNode('uni_ra_fatehpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'Fatehpur', 'ফতেপুর', 1),
  uniNode('uni_ra_uttarbhag', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'Uttarbhag', 'উত্তরভাগ', 2),
  uniNode('uni_ra_munshibazar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'Munshibazar', 'মুন্সীবাজার', 3),
  uniNode('uni_ra_panchgaon', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'Panchgaon', 'পাঁচগাঁও', 4),
  uniNode('uni_ra_sadar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'Rajnagar Sadar', 'রাজনগর সদর', 5),
  uniNode('uni_ra_tengra', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'Tengra', 'টেংরা', 6),
  uniNode('uni_ra_kamarchak', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'Kamarchak', 'কামারচাক', 7),
  uniNode('uni_ra_mansurnagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'Mansurnagar', 'মনসুরনগর', 8),

  vilNode('vil_ra_fatehpur', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'uni_ra_fatehpur', 'Fatehpur', 'ফতেপুর', 1),
  vilNode('vil_ra_kawadighi', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'uni_ra_uttarbhag', 'Kawadighi Haor Area', 'কাওয়াদিঘি হাওর এলাকা', 2),
  vilNode('vil_ra_munshibazar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'uni_ra_munshibazar', 'Munshibazar', 'মুন্সীবাজার', 3),
  vilNode('vil_ra_panchgaon', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'uni_ra_panchgaon', 'Panchgaon', 'পাঁচগাঁও', 4),
  vilNode('vil_ra_rajnagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'uni_ra_sadar', 'Rajnagar', 'রাজনগর', 5),
  vilNode('vil_ra_tengra', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'uni_ra_tengra', 'Tengra', 'টেংরা', 6),
  vilNode('vil_ra_kamarchak', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'uni_ra_kamarchak', 'Kamarchak', 'কামারচাক', 7),
  vilNode('vil_ra_mansurnagar', DIV_SYLHET, DIST_MOULVIBAZAR, 'upa_rajnagar', 'uni_ra_mansurnagar', 'Mansurnagar', 'মনসুরনগর', 8),

  // =========================================================================
  // SYLHET DISTRICT UNIONS & NEIGHBORHOODS (Backward Compatibility)
  // =========================================================================
  uniNode('uni_sy_khadimnagar', DIV_SYLHET, DIST_SYLHET, 'upa_sylhet_sadar', 'Khadimnagar', 'খাদিমনগর', 1),
  uniNode('uni_sy_khadimpara', DIV_SYLHET, DIST_SYLHET, 'upa_sylhet_sadar', 'Khadimpara', 'খাদিমপাড়া', 2),
  uniNode('uni_sy_tuker_bazar', DIV_SYLHET, DIST_SYLHET, 'upa_sylhet_sadar', 'Tuker Bazar', 'টুকের বাজার', 3),

  vilNode('vil_sy_zindabazar', DIV_SYLHET, DIST_SYLHET, 'upa_sylhet_sadar', 'uni_sy_khadimpara', 'Zindabazar', 'জিন্দাবাজার', 1),
  vilNode('vil_sy_amberkhana', DIV_SYLHET, DIST_SYLHET, 'upa_sylhet_sadar', 'uni_sy_khadimnagar', 'Amberkhana', 'আম্বরখানা', 2),
  vilNode('vil_sy_malnicherra', DIV_SYLHET, DIST_SYLHET, 'upa_sylhet_sadar', 'uni_sy_khadimnagar', 'Malnicherra Tea Estate', 'মালনিছড়া চা-বাগান', 3),
  vilNode('vil_sy_sust', DIV_SYLHET, DIST_SYLHET, 'upa_sylhet_sadar', 'uni_sy_tuker_bazar', 'SUST Campus, Akhalia', 'শাবিপ্রবি ক্যাম্পাস, আখালিয়া', 4),
  vilNode('vil_sy_keane', DIV_SYLHET, DIST_SYLHET, 'upa_sylhet_sadar', 'uni_sy_khadimpara', 'Keane Bridge & Surma Bank', 'ক্বিন ব্রিজ ও সুরমা পাড়', 5),
  vilNode('vil_sy_shibganj', DIV_SYLHET, DIST_SYLHET, 'upa_sylhet_sadar', 'uni_sy_khadimpara', 'Shibganj', 'শিবগঞ্জ', 6),

  uniNode('uni_gw_fatehpur', DIV_SYLHET, DIST_SYLHET, 'upa_gowainghat', 'Fatehpur', 'ফতেপুর', 1),
  uniNode('uni_gw_purbo_jaflong', DIV_SYLHET, DIST_SYLHET, 'upa_gowainghat', 'Purbo Jaflong', 'পূর্ব জাফলং', 2),
  vilNode('vil_gw_ratargul', DIV_SYLHET, DIST_SYLHET, 'upa_gowainghat', 'uni_gw_fatehpur', 'Ratargul Swamp Forest', 'রাতারগুল জলারবন', 1),
  vilNode('vil_gw_jaflong', DIV_SYLHET, DIST_SYLHET, 'upa_gowainghat', 'uni_gw_purbo_jaflong', 'Jaflong', 'জাফলং', 2),
];

// =========================================================================
// ALL 10 OFFICIAL TOURIST ATTRACTIONS IN MOULVIBAZAR
// =========================================================================
export const OFFICIAL_ATTRACTIONS: TouristAttraction[] = [
  {
    id: 'attr_madhabkunda_waterfall',
    name: 'Madhabkunda Waterfall',
    nameBn: 'মাধবকুণ্ড জলপ্রপাত',
    category: 'waterfall',
    divisionId: DIV_SYLHET,
    districtId: DIST_MOULVIBAZAR,
    districtName: 'Moulvibazar',
    districtNameBn: 'মৌলভীবাজার',
    upazilaId: 'upa_barlekha',
    upazilaName: 'Barlekha',
    upazilaNameBn: 'বড়লেখা',
    unionId: 'uni_ba_dakhinbhag_dakshin',
    unionName: 'Dakhinbhag Dakshin',
    unionNameBn: 'দক্ষিণভাগ দক্ষিণ',
    villageName: 'Madhabkunda',
    villageNameBn: 'মাধবকুণ্ড',
    locationSummary: 'Barlekha, Moulvibazar',
    locationSummaryBn: 'বড়লেখা, মৌলভীবাজার',
    description:
      'Bangladesh’s iconic 200-foot waterfall surrounded by Patharia Hill forests and mossy boulders in Barlekha Upazila.',
    descriptionBn:
      'বড়লেখা উপজেলার পাথারিয়া পাহাড় ও সবুজ অরণ্যে ঘেরা বাংলাদেশের অন্যতম পরিচিত ২০০ ফুট উঁচু প্রাকৃতিক জলপ্রপাত।',
    imageUrl: ASSET_IMAGES.madhabkunda,
    isFeatured: true,
    isActive: true,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  },
  {
    id: 'attr_lawachara_national_park',
    name: 'Lawachara National Park',
    nameBn: 'লাউয়াছড়া জাতীয় উদ্যান',
    category: 'forest',
    divisionId: DIV_SYLHET,
    districtId: DIST_MOULVIBAZAR,
    districtName: 'Moulvibazar',
    districtNameBn: 'মৌলভীবাজার',
    upazilaId: 'upa_kamalganj',
    upazilaName: 'Kamalganj',
    upazilaNameBn: 'কমলগঞ্জ',
    unionId: 'uni_km_sadar',
    unionName: 'Kamalganj Sadar',
    unionNameBn: 'কমলগঞ্জ সদর',
    villageName: 'Lawachara',
    villageNameBn: 'লাউয়াছড়া',
    locationSummary: 'Kamalganj, Moulvibazar',
    locationSummaryBn: 'কমলগঞ্জ, মৌলভীবাজার',
    description:
      'Protected semi-evergreen rainforest in Kamalganj famed for western hoolock gibbons, shaded nature trails, and biodiversity.',
    descriptionBn:
      'কমলগঞ্জে অবস্থিত চিরসবুজ ও অর্ধ-চিরসবুজ বনাঞ্চল, যেখানে উল্লুকসহ বিরল বন্যপ্রাণী ও শান্ত বনপথ রয়েছে।',
    imageUrl: ASSET_IMAGES.lawachara,
    isFeatured: true,
    isActive: true,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  },
  {
    id: 'attr_madhabpur_lake',
    name: 'Madhabpur Lake',
    nameBn: 'মাধবপুর লেক',
    category: 'lake',
    divisionId: DIV_SYLHET,
    districtId: DIST_MOULVIBAZAR,
    districtName: 'Moulvibazar',
    districtNameBn: 'মৌলভীবাজার',
    upazilaId: 'upa_kamalganj',
    upazilaName: 'Kamalganj',
    upazilaNameBn: 'কমলগঞ্জ',
    unionId: 'uni_km_madhabpur',
    unionName: 'Madhabpur',
    unionNameBn: 'মাধবপুর',
    villageName: 'Madhabpur Tea Estate',
    villageNameBn: 'মাধবপুর চা-বাগান',
    locationSummary: 'Kamalganj, Moulvibazar',
    locationSummaryBn: 'কমলগঞ্জ, মৌলভীবাজার',
    description:
      'Serene freshwater hill lake framed by emerald tea-estate ridges and seasonal water lilies in Madhabpur Union.',
    descriptionBn:
      'মাধবপুর ইউনিয়নের সবুজ চা-বাগানের টিলার মাঝে অবস্থিত শাপলা-পদ্বে ভরা মনোরম পাহাড়ি লেক।',
    imageUrl: ASSET_IMAGES.madhabpurLake,
    isFeatured: true,
    isActive: true,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  },
  {
    id: 'attr_hum_hum_waterfall',
    name: 'Hum Hum Waterfall',
    nameBn: 'হামহাম জলপ্রপাত',
    category: 'waterfall',
    divisionId: DIV_SYLHET,
    districtId: DIST_MOULVIBAZAR,
    districtName: 'Moulvibazar',
    districtNameBn: 'মৌলভীবাজার',
    upazilaId: 'upa_kamalganj',
    upazilaName: 'Kamalganj',
    upazilaNameBn: 'কমলগঞ্জ',
    unionId: 'uni_km_islampur',
    unionName: 'Islampur',
    unionNameBn: 'ইসলামপুর',
    villageName: 'Kurma (Rajkandi Forest)',
    villageNameBn: 'কুরমা (রাজকান্দি বন)',
    locationSummary: 'Kamalganj, Moulvibazar',
    locationSummaryBn: 'কমলগঞ্জ, মৌলভীবাজার',
    description:
      'Deep-forest adventure cascade inside Rajkandi Reserve Forest, reached by trekking along bamboo streams from Kurma in Kamalganj.',
    descriptionBn:
      'কমলগঞ্জের ইসলামপুর ইউনিয়নের রাজকান্দি সংরক্ষিত বনের ভেতরে ঝিরিপথ পেরিয়ে পৌঁছানোর রোমাঞ্চকর জলপ্রপাত।',
    imageUrl: ASSET_IMAGES.madhabkunda,
    isFeatured: true,
    isActive: true,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  },
  {
    id: 'attr_hakaluki_haor',
    name: 'Hakaluki Haor',
    nameBn: 'হাকালুকি হাওর',
    category: 'haor',
    divisionId: DIV_SYLHET,
    districtId: DIST_MOULVIBAZAR,
    districtName: 'Moulvibazar',
    districtNameBn: 'মৌলভীবাজার',
    upazilaId: 'upa_kulaura',
    upazilaName: 'Kulaura',
    upazilaNameBn: 'কুলাউড়া',
    unionId: 'uni_ku_bhukshimail',
    unionName: 'Bhukshimail',
    unionNameBn: 'ভুকশিমইল',
    villageName: 'Bhukshimail Haor Basin',
    villageNameBn: 'ভুকশিমইল হাওর পাড়',
    locationSummary: 'Kulaura and surrounding areas, Moulvibazar',
    locationSummaryBn: 'কুলাউড়া ও আশপাশের এলাকা, মৌলভীবাজার',
    description:
      'Bangladesh’s largest freshwater haor wetland spanning Kulaura, Barlekha, and Juri, renowned for winter migratory birds and swamp reeds.',
    descriptionBn:
      'কুলাউড়া, বড়লেখা ও জুড়ী জুড়ে বিস্তৃত বাংলাদেশের বৃহত্তম মিঠাপানির হাওর, শীতকালীন অতিথি পাখি ও হিজল-করচ বনের জন্য খ্যাত।',
    imageUrl: ASSET_IMAGES.haorWetland,
    isFeatured: true,
    isActive: true,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  },
  {
    id: 'attr_baikka_beel',
    name: 'Baikka Beel',
    nameBn: 'বাইক্কা বিল',
    category: 'haor',
    divisionId: DIV_SYLHET,
    districtId: DIST_MOULVIBAZAR,
    districtName: 'Moulvibazar',
    districtNameBn: 'মৌলভীবাজার',
    upazilaId: 'upa_sreemangal',
    upazilaName: 'Sreemangal',
    upazilaNameBn: 'শ্রীমঙ্গল',
    unionId: 'uni_sr_bhunabir',
    unionName: 'Bhunabir',
    unionNameBn: 'ভুনবীর',
    villageName: 'Baikka Beel Sanctuary',
    villageNameBn: 'বাইক্কা বিল অভয়াশ্রম',
    locationSummary: 'Sreemangal, Moulvibazar',
    locationSummaryBn: 'শ্রীমঙ্গল, মৌলভীবাজার',
    description:
      'Protected wetland bird and fish sanctuary in the eastern part of Hail Haor, featuring watchtowers and lotus blooms.',
    descriptionBn:
      'হাইল হাওরের পূর্ব প্রান্তে শ্রীমঙ্গলের সংরক্ষিত পাখি ও মৎস্য অভয়াশ্রম, ওয়াচটাওয়ার ও পদ্মফুলের জন্য জনপ্রিয়।',
    imageUrl: ASSET_IMAGES.haorWetland,
    isFeatured: true,
    isActive: true,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  },
  {
    id: 'attr_sreemangal_tea_gardens',
    name: 'Sreemangal Tea Gardens',
    nameBn: 'শ্রীমঙ্গলের চা-বাগানসমূহ',
    category: 'tea_garden',
    divisionId: DIV_SYLHET,
    districtId: DIST_MOULVIBAZAR,
    districtName: 'Moulvibazar',
    districtNameBn: 'মৌলভীবাজার',
    upazilaId: 'upa_sreemangal',
    upazilaName: 'Sreemangal',
    upazilaNameBn: 'শ্রীমঙ্গল',
    unionId: 'uni_sr_kalighat',
    unionName: 'Kalighat',
    unionNameBn: 'কালীঘাট',
    villageName: 'Balishira & Kalighat Tea Valley',
    villageNameBn: 'বালিশিরা ও কালীঘাট চা উপত্যকা',
    locationSummary: 'Sreemangal, Moulvibazar',
    locationSummaryBn: 'শ্রীমঙ্গল, মৌলভীবাজার',
    description:
      'Rolling manicured tea terraces across Kalighat, Rajghat, and Satgaon in Bangladesh’s famed Tea Capital.',
    descriptionBn:
      'চায়ের রাজধানী শ্রীমঙ্গলের কালীঘাট, রাজঘাট ও সাতগাঁও জুড়ে বিস্তৃত সবুজ পাহাড়ি চা-বাগান।',
    imageUrl: ASSET_IMAGES.teaGardenCover,
    isFeatured: true,
    isActive: true,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  },
  {
    id: 'attr_hail_haor',
    name: 'Hail Haor',
    nameBn: 'হাইল হাওর',
    category: 'haor',
    divisionId: DIV_SYLHET,
    districtId: DIST_MOULVIBAZAR,
    districtName: 'Moulvibazar',
    districtNameBn: 'মৌলভীবাজার',
    upazilaId: 'upa_sreemangal',
    upazilaName: 'Sreemangal',
    upazilaNameBn: 'শ্রীমঙ্গল',
    unionId: 'uni_sr_kalapur',
    unionName: 'Kalapur',
    unionNameBn: 'কালাপুর',
    villageName: 'Kalapur Haor Basin',
    villageNameBn: 'কালাপুর হাওর এলাকা',
    locationSummary: 'Sreemangal and surrounding areas, Moulvibazar',
    locationSummaryBn: 'শ্রীমঙ্গল ও আশপাশের এলাকা, মৌলভীবাজার',
    description:
      'Vast seasonal wetland basin between Sreemangal and Moulvibazar Sadar supporting fisheries, water lilies, and migratory waterfowl.',
    descriptionBn:
      'শ্রীমঙ্গল ও মৌলভীবাজার সদর সংলগ্ন বিস্তীর্ণ জলাভূমি, দেশি মাছ, শাপলা ও পাখির প্রাকৃতিক আবাসস্থল।',
    imageUrl: ASSET_IMAGES.ratargul,
    isFeatured: false,
    isActive: true,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  },
  {
    id: 'attr_manipuri_para',
    name: 'Manipuri Para',
    nameBn: 'মণিপুরী পাড়া',
    category: 'cultural',
    divisionId: DIV_SYLHET,
    districtId: DIST_MOULVIBAZAR,
    districtName: 'Moulvibazar',
    districtNameBn: 'মৌলভীবাজার',
    upazilaId: 'upa_kamalganj',
    upazilaName: 'Kamalganj',
    upazilaNameBn: 'কমলগঞ্জ',
    unionId: 'uni_km_adampur',
    unionName: 'Adampur',
    unionNameBn: 'আদমপুর',
    villageName: 'Tetaigaon & Madhabpur',
    villageNameBn: 'তেতইগাঁও ও মাধবপুর',
    locationSummary: 'Kamalganj, Moulvibazar',
    locationSummaryBn: 'কমলগঞ্জ, মৌলভীবাজার',
    description:
      'Vibrant cultural villages in Adampur and Madhabpur known for traditional Manipuri handloom weaving, Ras Leela dance, and heritage architecture.',
    descriptionBn:
      'কমলগঞ্জের আদমপুর ও মাধবপুরে অবস্থিত ঐতিহ্যবাহী মণিপুরী জনপদ, তাঁতশিল্প ও রাসলীলা উৎসবের জন্য সুপরিচিত।',
    imageUrl: ASSET_IMAGES.manipuriPara,
    isFeatured: true,
    isActive: true,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  },
  {
    id: 'attr_manu_river_barrage',
    name: 'Manu River and Manu Barrage',
    nameBn: 'মনু নদী ও মনু ব্যারাজ',
    category: 'river',
    divisionId: DIV_SYLHET,
    districtId: DIST_MOULVIBAZAR,
    districtName: 'Moulvibazar',
    districtNameBn: 'মৌলভীবাজার',
    upazilaId: 'upa_moulvibazar_sadar',
    upazilaName: 'Moulvibazar Sadar',
    upazilaNameBn: 'মৌলভীবাজার সদর',
    unionId: 'uni_ms_chandnighat',
    unionName: 'Chandnighat',
    unionNameBn: 'চাঁদনীঘাট',
    villageName: 'Manu Barrage Point',
    villageNameBn: 'মনু ব্যারাজ এলাকা',
    locationSummary: 'Moulvibazar area (Moulvibazar Sadar)',
    locationSummaryBn: 'মৌলভীবাজার এলাকা (মৌলভীবাজার সদর)',
    description:
      'Scenic riverside embankment and irrigation barrage along the Manu River near Chandnighat, popular for evening breezes and sunset views.',
    descriptionBn:
      'চাঁদনীঘাট সংলগ্ন মনু নদীর তীরে অবস্থিত মনোরম ব্যারাজ ও নদীর পাড়, বিকেলের ভ্রমণ ও সূর্যাস্ত দেখার জন্য জনপ্রিয়।',
    imageUrl: ASSET_IMAGES.jaflong,
    isFeatured: false,
    isActive: true,
    createdAt: BASE_TIME,
    updatedAt: BASE_TIME,
  },
];
