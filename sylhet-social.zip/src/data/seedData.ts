import { PostMediaType } from '../types/social';

export const ASSET_IMAGES = {
  teaGardenCover: '/src/assets/images/sylhet_tea_garden_cover_1794860733303.jpg',
  ratargul: '/src/assets/images/sylhet_ratargul_forest_1794860733592.jpg',
  keaneBridge: '/src/assets/images/sylhet_keane_bridge_1794860734961.jpg',
  jaflong: '/src/assets/images/sylhet_jaflong_river_1794860734546.jpg',
  madhabkunda: '/src/assets/images/madhabkunda_waterfall_1794864497489.jpg',
  lawachara: '/src/assets/images/lawachara_rainforest_1794864503633.jpg',
  madhabpurLake: '/src/assets/images/madhabpur_lake_1794864498043.jpg',
  haorWetland: '/src/assets/images/haor_baikka_beel_1794864499203.jpg',
  manipuriPara: '/src/assets/images/manipuri_para_village_1794864519437.jpg',
  avatarTariq: '/src/assets/images/avatar_tariq_sylhet_1794860734980.jpg',
  avatarNusrat: '/src/assets/images/avatar_nusrat_sylhet_1794860734425.jpg',
  avatarRafiq: '/src/assets/images/avatar_rafiq_sylhet_1794860735973.jpg',
};

export interface StarterPostTemplate {
  mediaType: PostMediaType;
  text: string;
  textBn: string;
  photoUrl?: string;
  videoThumbnailUrl?: string;
  videoDuration?: string;
  textCardTheme?: 'none' | 'emerald' | 'surma' | 'tea';
  location: string;
  locationBn: string;
}

export const STARTER_POST_TEMPLATES: StarterPostTemplate[] = [
  {
    mediaType: 'photo',
    text: 'Early morning boat ride through Ratargul Swamp Forest. The koroch canopy turns the entire water surface into a quiet emerald mirror after monsoon rains.',
    textBn: 'ভোরের আলোয় রাতারগুল জলারবনে নৌকা ভ্রমণ। বর্ষার পর করচ গাছের ছায়ায় পুরো পানি যেন সবুজ আয়না হয়ে ওঠে।',
    photoUrl: ASSET_IMAGES.ratargul,
    location: 'Ratargul Swamp Forest',
    locationBn: 'রাতারগুল জলারবন',
  },
  {
    mediaType: 'video',
    text: 'Golden hour reel along Keane Bridge and Ali Amjad’s Clock Tower. Evening tea stalls along the Surma embankment always bring the whole city together.',
    textBn: 'ক্বিন ব্রিজ আর আলী আমজদের ঘড়ির পাশে গোধূলির ভিডিও রিল। সুরমা নদীর পাড়ের চায়ের আড্ডা পুরো সিলেটকে এক করে।',
    videoThumbnailUrl: ASSET_IMAGES.keaneBridge,
    videoDuration: '0:24',
    location: 'Keane Bridge & Surma Bank',
    locationBn: 'ক্বিন ব্রিজ ও সুরমা পাড়',
  },
  {
    mediaType: 'photo',
    text: 'Nothing beats sunrise mist rolling across Malnicherra Tea Estate before the morning shift begins. Proud to call Sylhet home.',
    textBn: 'সকালের কুয়াশায় মোড়ানো মালনিছড়া চা-বাগানের সূর্যোদয়। সিলেটের এই শান্ত পরিবেশের তুলনা হয় না।',
    photoUrl: ASSET_IMAGES.teaGardenCover,
    location: 'Malnicherra Tea Estate',
    locationBn: 'মালনিছড়া চা-বাগান',
  },
  {
    mediaType: 'photo',
    text: 'Crystal-clear Piyain river water at Jaflong today. Local boatmen are preparing for the winter travel season with fresh bamboo seating.',
    textBn: 'আজকের জাফলংয়ের পিয়াইন নদীর স্বচ্ছ পানি। শীতের ভ্রমণ মৌসুমের জন্য মাঝিরা নতুন করে নৌকা সাজাচ্ছেন।',
    photoUrl: ASSET_IMAGES.jaflong,
    location: 'Jaflong, Gowainghat',
    locationBn: 'জাফলং, গোয়াইনঘাট',
  },
];

export const SYLHET_COMMUNITY_PULSE = [
  {
    id: 'pulse-1',
    titleEn: 'Surma Sunset Photography Walk',
    titleBn: 'সুরমা নদীর পাড়ে আলোকচিত্র ভ্রমণ',
    metaEn: 'Keane Bridge · Friday 4:30 PM',
    metaBn: 'ক্বিন ব্রিজ · শুক্রবার বিকাল ৪:৩০',
    query: 'Keane Bridge',
  },
  {
    id: 'pulse-2',
    titleEn: 'Ratargul Eco-Boat & Clean Forest Drive',
    titleBn: 'রাতারগুল পরিচ্ছন্নতা ও নৌকা ভ্রমণ',
    metaEn: 'Ratargul · Saturday 7:00 AM',
    metaBn: 'রাতারগুল · শনিবার সকাল ৭:০০',
    query: 'Ratargul',
  },
  {
    id: 'pulse-3',
    titleEn: 'Malnicherra Tea Harvest & Sketch Meet',
    titleBn: 'মালনিছড়া চা-বাগান স্কেচ আড্ডা',
    metaEn: 'Malnicherra · Sunday 8:00 AM',
    metaBn: 'মালনিছড়া · রবিবার সকাল ৮:০০',
    query: 'Malnicherra',
  },
];
