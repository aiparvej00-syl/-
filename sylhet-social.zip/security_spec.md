# Sylhet Social Security Specification (Phase 0 TDD)

## 1. Data Invariants
1. **Identity Integrity**: A user cannot create or modify a `users_public` profile with a `uid` different from `request.auth.uid`, nor self-assign `role: 'admin'` or `role: 'moderator'` on create or update.
2. **PII Isolation**: `users_private/{userId}` (containing `email`) is readable and writable only by the owning user or an authorized admin.
3. **Admin RBAC Enforcement**: Only verified admins (`admins/{uid}` or verified runtime admin email) may read/update `reports`, moderate other users' `posts`, manage `appSettings/global`, write `auditLogs`, or change user roles/statuses.
4. **Post Ownership & Moderation**: Only the post author may create a post with `authorId == request.auth.uid` and `moderationStatus` matching `'approved'` or `'pending'`; only admins may hide/approve arbitrary posts or edit `moderationNote`.
5. **Relational Containment**: Private conversation messages can only be read or written by the two users listed in `participantIds` on the parent `/conversations/{conversationId}` document.
6. **Temporal Integrity**: `createdAt` and `updatedAt` are server timestamps (`request.time`), and `createdAt` / `authorId` / `uid` are immutable after creation.
7. **Directory Integrity (Locations & Tourist Attractions)**: `/locations/{locationId}` and `/attractions/{attractionId}` may only be created, modified, or deleted by verified admins (`isAdmin()`). Active items (`isActive == true`) are queryable by signed-in users via rule-enforced filters.
8. **Monetization & Manual Payment Integrity**: `/localAds/{adId}` may only be created with `status: 'pending_review'`, `paymentStatus: 'unpaid'`, `advertiserUid == request.auth.uid`, and pricing/duration matching an existing active `/adPackages/{packageId}` document. Only verified admins (`isAdmin()`) may mark `paymentStatus: 'paid'` / `'refunded'`, approve/reject ads, or mutate `/adPackages` and `/monetizationConfig/global`. Unapproved or unpaid ads are readable only by the submitting advertiser and verified admins.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Self-Escalation on Registration**: Creating `/users_public/{uid}` with `role: "admin"` -> MUST return `PERMISSION_DENIED`.
2. **Profile Role Tampering**: Regular user updating own `/users_public/{uid}` with `role: "admin"` or `status: "suspended"` -> MUST return `PERMISSION_DENIED`.
3. **Ghost Field Injection**: Creating a post with an undeclared field `isVerified: true` -> MUST return `PERMISSION_DENIED`.
4. **Author Spoofing**: Creating a post with `authorId: "other-uid"` -> MUST return `PERMISSION_DENIED`.
5. **PII Blanket Read**: Regular user reading another user's `/users_private/{otherUid}` -> MUST return `PERMISSION_DENIED`.
6. **Admin Registry Spoofing**: Regular user creating `/admins/{uid}` -> MUST return `PERMISSION_DENIED`.
7. **Unverified Admin Email Spoof**: Request with matching email string but `email_verified: false` -> MUST return `PERMISSION_DENIED`.
8. **ID Poisoning**: Creating a document with a 300-char or invalid-character document ID -> MUST return `PERMISSION_DENIED`.
9. **Unauthorized Post Moderation**: Regular user updating another user's post `moderationStatus: "hidden"` -> MUST return `PERMISSION_DENIED`.
10. **Unauthorized AppSettings Mutation**: Regular user writing to `/appSettings/global` -> MUST return `PERMISSION_DENIED`.
11. **Chat Eavesdropping**: Third-party user reading or writing `/conversations/{id}/messages/{msgId}` -> MUST return `PERMISSION_DENIED`.
12. **Audit Log Tampering**: Regular user creating or an admin deleting `/auditLogs/{logId}` -> MUST return `PERMISSION_DENIED`.
13. **Blocked Messaging Bypass**: Blocked user creating a conversation or sending a message when `/userBlocks/{blocker_blocked}` exists -> MUST return `PERMISSION_DENIED`.
14. **Receipt Content Tampering**: Recipient updating `text`, `mediaUrl`, or `senderId` while setting `seenBy`/`deliveredTo` on a message -> MUST return `PERMISSION_DENIED`.
15. **Block Spoofing**: Creating `/userBlocks/{id}` with `blockerId != request.auth.uid` or deleting another user's block -> MUST return `PERMISSION_DENIED`.
16. **Unauthorized Directory Mutation**: Regular user creating, updating, or deleting `/locations/{locationId}` or `/attractions/{attractionId}` -> MUST return `PERMISSION_DENIED`.
17. **Invalid Location Level / Ghost Field**: Admin writing `/locations/{locationId}` with `level: "country"` or undeclared fields -> MUST return `PERMISSION_DENIED`.
18. **Self-Approving or Self-Paying Ad**: Advertiser creating `/localAds/{adId}` with `status: "approved"` or `paymentStatus: "paid"`, or updating own ad to `paymentStatus: "paid"` -> MUST return `PERMISSION_DENIED`.
19. **Ad Price Tampering**: Advertiser creating `/localAds/{adId}` with `priceBdt: 1` that does not match `/adPackages/{packageId}` -> MUST return `PERMISSION_DENIED`.
20. **Unauthorized Package/Config Mutation**: Non-admin user creating or modifying `/adPackages/{id}` or `/monetizationConfig/global` -> MUST return `PERMISSION_DENIED`.
21. **Unapproved Ad Scraping**: Non-owner regular user listing or reading an unpaid/pending `/localAds/{adId}` -> MUST return `PERMISSION_DENIED`.
22. **Metric Inflation on Unapproved Ad**: Incrementing `clicksCount` on an ad whose `status != 'approved'` or `paymentStatus != 'paid'`, or incrementing by more than `+1` -> MUST return `PERMISSION_DENIED`.
